Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Xml.Serialization
Imports AW

Namespace TimeLordBot

    Public Partial Class TardisBot
        Private ReadOnly _log As Action(Of String)
        Private _sdk As AW.Instance
        Private _homeWorld As String = ""
        Private ReadOnly _sessions As New Dictionary(Of Integer, PlayerProfile)()
        Private ReadOnly _profiles As New Dictionary(Of String, PlayerProfile)(StringComparer.OrdinalIgnoreCase)
        Private ReadOnly _flights As New Dictionary(Of Integer, TardisFlightState)()
        Private ReadOnly _destinations As New Dictionary(Of String, TardisDestination)(StringComparer.OrdinalIgnoreCase)
        Private ReadOnly _rng As New Random()
        Private _profilesPath As String
        Private _destinationsPath As String
        Private _profilesDirty As Boolean = False
        Private _lastProfileWriteUtc As DateTime = DateTime.MinValue
        Private _nextGameTickUtc As DateTime = DateTime.MinValue
        Private Const ProfileSaveDebounceSeconds As Double = 2.0
        Private Const GameTickMilliseconds As Integer = 250
        Private ReadOnly _selectedAvatarBySession As New Dictionary(Of Integer, Integer)()
        Private ReadOnly _lastZoneBySession As New Dictionary(Of Integer, String)()
        Private ReadOnly _avatarPositions As New Dictionary(Of Integer, AvatarPosition)()
        Private ReadOnly _avatarBumpCooldowns As New Dictionary(Of String, DateTime)(StringComparer.OrdinalIgnoreCase)

        Public Property Connected As Boolean = False

        Public Sub New(logger As Action(Of String))
            _log = logger
            _profilesPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "TimeLordProfiles.xml")
            _destinationsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "TardisDestinations.txt")
            LoadProfiles()
            LoadDestinations()
            LoadInteractionTriggers()
        End Sub

        Public Sub Connect(citizen As Integer, privilegePassword As String, botName As String, homeWorld As String, Optional authHost As String = "auth.deltaworlds.com", Optional authPort As Integer = 6671)
            _homeWorld = homeWorld
            If String.IsNullOrWhiteSpace(authHost) Then authHost = "auth.deltaworlds.com"
            If authPort <= 0 OrElse authPort > 65535 Then authPort = 6671
            _sdk = New AW.Instance(authHost, authPort)

            AddHandler _sdk.EventAvatarAdd, AddressOf EventAvatarAdd
            AddHandler _sdk.EventAvatarDelete, AddressOf EventAvatarDelete
            AddHandler _sdk.EventObjectClick, AddressOf EventObjectClick
            AddHandler _sdk.EventObjectBump, AddressOf EventObjectBump
            AddHandler _sdk.EventAvatarClick, AddressOf EventAvatarClick
            AddHandler _sdk.EventAvatarChange, AddressOf EventAvatarChange
            AddHandler _sdk.EventHudClick, AddressOf EventHudClick
            AddHandler _sdk.EventChat, AddressOf EventChat

            _sdk.SetInt(Attributes.LoginOwner, citizen)
            _sdk.SetString(Attributes.LoginPrivilegePassword, privilegePassword)
            _sdk.SetString(Attributes.LoginName, botName)
            _sdk.Login()

            _sdk.SetBool(Attributes.EnterGlobal, True)
            _sdk.Enter(homeWorld)
            Try
                _sdk.SetBool(Attributes.WorldEnableBumpEvent, True)
            Catch
                ' Some worlds/SDK builds expose this as a read-only world setting.
            End Try

            _sdk.SetInt(Attributes.MyX, 0)
            _sdk.SetInt(Attributes.MyY, 0)
            _sdk.SetInt(Attributes.MyZ, 0)
            _sdk.SetInt(Attributes.MyYaw, 0)
            _sdk.StateChange()

            Connected = True
            _log("Connected as " & botName & " in " & homeWorld & ".")
            _log("Loaded " & _destinations.Count.ToString() & " TARDIS destination keys.")
        End Sub

        Public Sub Disconnect()
            If _sdk IsNot Nothing Then
                Try
                    _sdk.Exit()
                Catch
                End Try
            End If
            Connected = False
            SaveProfiles(True)
        End Sub

        Private Sub EventAvatarAdd(sender As AW.Instance)
            On Error Resume Next
            Dim name As String = sender.GetString(Attributes.AvatarName)
            Dim session As Integer = sender.GetInt(Attributes.AvatarSession)
            If String.IsNullOrWhiteSpace(name) OrElse session <= 0 Then Return

            Dim profile As PlayerProfile = Nothing
            If Not _profiles.TryGetValue(name, profile) Then
                profile = New PlayerProfile()
                profile.Name = name
                _profiles(name) = profile
                SaveProfiles()
            End If

            _sessions(session) = profile
            TrackAvatarLocation(sender, session, True)
            _log(name & " entered (session " & session.ToString() & ").")
        End Sub

        Private Sub EventAvatarDelete(sender As AW.Instance)
            On Error Resume Next
            Dim session As Integer = sender.GetInt(Attributes.AvatarSession)
            If _sessions.ContainsKey(session) Then
                _sessions.Remove(session)
            End If
            _flights.Remove(session)
            _selectedAvatarBySession.Remove(session)
            _lastZoneBySession.Remove(session)
            _avatarPositions.Remove(session)
            Dim stale As New List(Of Integer)()
            For Each kv As KeyValuePair(Of Integer, Integer) In _selectedAvatarBySession
                If kv.Value = session Then stale.Add(kv.Key)
            Next
            For Each k As Integer In stale
                _selectedAvatarBySession.Remove(k)
            Next
        End Sub

        Private Sub EventObjectClick(sender As AW.Instance)
            On Error Resume Next
            Dim session As Integer = sender.GetInt(Attributes.AvatarSession)
            If Not _sessions.ContainsKey(session) Then Return
            DispatchGameplayAction(session, sender, sender.GetString(Attributes.ObjectAction), "click")
        End Sub

        Private Sub EventObjectBump(sender As AW.Instance)
            On Error Resume Next
            Dim session As Integer = sender.GetInt(Attributes.AvatarSession)
            If Not _sessions.ContainsKey(session) Then Return
            DispatchGameplayAction(session, sender, sender.GetString(Attributes.ObjectAction), "bump")
        End Sub

        Private Sub EventAvatarClick(sender As AW.Instance)
            On Error Resume Next
            Dim actorSession As Integer = sender.GetInt(Attributes.AvatarSession)
            Dim targetSession As Integer = sender.GetInt(Attributes.ClickedSession)
            Dim targetName As String = sender.GetString(Attributes.ClickedName)
            If actorSession <= 0 OrElse targetSession <= 0 OrElse actorSession = targetSession Then Return
            If Not _sessions.ContainsKey(actorSession) Then Return
            _selectedAvatarBySession(actorSession) = targetSession
            If String.IsNullOrWhiteSpace(targetName) AndAlso _sessions.ContainsKey(targetSession) Then targetName = _sessions(targetSession).Name
            Console(actorSession, 80, 170, 220, "TARGET SELECTED: " & If(targetName, "another traveller") & ". Conversational target commands are now active.")
            FireAvatarInteractionTriggers("click", actorSession, targetSession, targetName, sender)
        End Sub

        Private Sub EventAvatarChange(sender As AW.Instance)
            On Error Resume Next
            Dim session As Integer = sender.GetInt(Attributes.AvatarSession)
            If session <= 0 Then Return
            TrackAvatarLocation(sender, session, False)
        End Sub

        Private Sub DispatchGameplayAction(session As Integer, sender As AW.Instance, action As String, source As String)
            If action Is Nothing Then action = ""
            If action.Trim() <> "" Then
                Dim actorName As String = If(_sessions.ContainsKey(session), _sessions(session).Name, "session " & session.ToString())
                _log("GAME [" & source & "] " & actorName & " -> " & action.Trim())
            End If
            If action.IndexOf("~tardiscontrol", StringComparison.OrdinalIgnoreCase) >= 0 Then
                HandleTardisControl(session, sender, action)
                Return
            End If
            If action.IndexOf("~tardisreturn", StringComparison.OrdinalIgnoreCase) >= 0 Then
                ReturnToInterior(session, sender)
                Return
            End If
            If action.IndexOf("~timelord", StringComparison.OrdinalIgnoreCase) >= 0 Then
                HandleTimeLordControl(session, sender, action)
                Return
            End If
            If action.IndexOf("~enemy", StringComparison.OrdinalIgnoreCase) >= 0 Then
                HandleEnemyAction(session, sender, action)
                RefreshRpgHud(session, True)
                Return
            End If
            If action.IndexOf("~rpg", StringComparison.OrdinalIgnoreCase) >= 0 Then
                HandleRpgAction(session, sender, action)
                Return
            End If
        End Sub

        Private Sub EventChat(sender As AW.Instance)
            On Error Resume Next

            Dim chat As String = sender.GetString(Attributes.ChatMessage)
            Dim session As Integer = sender.GetInt(Attributes.ChatSession)
            Dim avatarName As String = sender.GetString(Attributes.AvatarName)
            If String.IsNullOrWhiteSpace(chat) OrElse session <= 0 Then Return

            ' Chat can arrive before AvatarAdd has populated the session map.
            If Not _sessions.ContainsKey(session) AndAlso Not String.IsNullOrWhiteSpace(avatarName) Then
                Dim existing As PlayerProfile = Nothing
                If _profiles.TryGetValue(avatarName, existing) Then
                    _sessions(session) = existing
                Else
                    existing = New PlayerProfile With {.Name = avatarName}
                    _profiles(avatarName) = existing
                    _sessions(session) = existing
                    SaveProfiles()
                End If
            End If
            If Not _sessions.ContainsKey(session) Then Return

            HandleGameplayChat(session, sender, chat.Trim())
        End Sub

        Private Sub HandleGameplayChat(session As Integer, sender As AW.Instance, chat As String)
            If String.IsNullOrWhiteSpace(chat) Then Return
            Dim p As PlayerProfile = _sessions(session)
            Dim raw As String = chat.Trim()
            Dim lower As String = raw.ToLowerInvariant()

            ' Natural-language TARDIS triggers intentionally require the TARDIS prefix
            ' so ordinary roleplay chat is not accidentally interpreted as a command.
            If lower = "tardis show hud" OrElse lower = "tardis hud on" Then
                p.HudEnabled = True
                SaveProfiles()
                RefreshRpgHud(session, True)
                Console(session, 90, 190, 220, "TARDIS HUD LINK ONLINE.")
                Return
            ElseIf lower = "tardis hide hud" OrElse lower = "tardis hud off" Then
                p.HudEnabled = False
                ClearRpgHud(session)
                SaveProfiles()
                Console(session, 140, 140, 170, "TARDIS HUD LINK OFFLINE.")
                Return
            ElseIf lower = "tardis status" OrElse lower = "time lord status" Then
                ShowTimeLordStatus(session, p)
                Return
            ElseIf lower = "tardis destinations" Then
                ListDestinations(session, CurrentWorld(sender))
                Return
            ElseIf lower = "tardis distress" Then
                HandleTardisControl(session, sender, "~tardiscontrol type:distress")
                Return
            ElseIf lower = "tardis adventure" Then
                HandleTardisControl(session, sender, "~tardiscontrol type:adventure")
                Return
            End If

            If Not lower.StartsWith("/") Then
                If TryHandleConversationTrigger(session, sender, raw) Then Return
                If TryHandleSelectedAvatarConversation(session, sender, raw) Then Return
                Return
            End If

            Dim firstSpace As Integer = raw.IndexOf(" "c)
            Dim command As String = If(firstSpace < 0, lower, lower.Substring(0, firstSpace))
            Dim args As String = If(firstSpace < 0, "", raw.Substring(firstSpace + 1).Trim())

            Select Case command
                Case "/hud"
                    Dim mode As String = args.ToLowerInvariant()
                    If mode = "on" Then
                        p.HudEnabled = True
                    ElseIf mode = "off" Then
                        p.HudEnabled = False
                    Else
                        p.HudEnabled = Not p.HudEnabled
                    End If
                    SaveProfiles()
                    If p.HudEnabled Then
                        RefreshRpgHud(session, True)
                        Console(session, 90, 190, 220, "TARDIS HUD LINK ONLINE.")
                    Else
                        ClearRpgHud(session)
                        Console(session, 140, 140, 170, "TARDIS HUD LINK OFFLINE.")
                    End If

                Case "/status", "/tl", "/timelord"
                    ShowTimeLordStatus(session, p)
                Case "/skills"
                    ShowSkills(session, p)
                Case "/missions"
                    ShowActiveMissions(session, p)
                Case "/travel"
                    ShowTravelLog(session, p)
                Case "/achievements"
                    ShowAchievements(session, p)
                Case "/inventory", "/inv"
                    ShowInventory(session, p)
                Case "/academy"
                    ShowAcademy(session, p)
                Case "/companions", "/companion"
                    ShowCompanions(session, p)
                Case "/paradox"
                    ShowParadox(session, p)
                Case "/sonic"
                    ShowSonicProfile(session, p)
                Case "/rooms"
                    ShowTardisRooms(session, p)
                Case "/destinations", "/nav"
                    ListDestinations(session, CurrentWorld(sender))
                Case "/distress"
                    HandleTardisControl(session, sender, "~tardiscontrol type:distress")
                Case "/adventure"
                    HandleTardisControl(session, sender, "~tardiscontrol type:adventure")
                Case "/tardis"
                    HandleTardisChatCommand(session, sender, args)
                Case "/whohelp", "/tardishelp"
                    ShowChatHelp(session)
            End Select
        End Sub

        Private Sub HandleTardisChatCommand(session As Integer, sender As AW.Instance, args As String)
            Dim argText As String = If(args, "").Trim()
            Dim lower As String = argText.ToLowerInvariant()
            If lower = "" OrElse lower = "status" Then
                ShowTimeLordStatus(session, _sessions(session))
                Return
            End If
            If lower = "destinations" OrElse lower = "nav" Then
                ListDestinations(session, CurrentWorld(sender))
                Return
            End If
            If lower = "hud" Then
                HandleGameplayChat(session, sender, "/hud")
                Return
            End If
            If lower.StartsWith("hud ") Then
                HandleGameplayChat(session, sender, "/hud " & argText.Substring(4).Trim())
                Return
            End If
            If lower = "distress" OrElse lower = "adventure" OrElse lower = "helmic" OrElse lower = "architecture" OrElse lower = "lifesupport" OrElse lower = "telepathic" OrElse lower = "handbrake" OrElse lower = "dematerialise" OrElse lower = "dematerialize" Then
                Dim controlName As String = lower
                If controlName = "dematerialize" Then controlName = "dematerialise"
                HandleTardisControl(session, sender, "~tardiscontrol type:" & controlName)
                Return
            End If
            If lower.StartsWith("artron ") Then
                HandleTardisControl(session, sender, "~tardiscontrol type:artron,amount:" & argText.Substring(7).Trim())
                Return
            End If
            If lower.StartsWith("coordinates ") OrElse lower.StartsWith("destination ") Then
                Dim cut As Integer = argText.IndexOf(" "c)
                Dim destinationName As String = If(cut >= 0, argText.Substring(cut + 1).Trim(), "")
                If destinationName <> "" Then
                    HandleTardisControl(session, sender, "~tardiscontrol type:coordinates,destination:" & destinationName)
                End If
                Return
            End If
            Console(session, 150, 170, 210, "TARDIS chat command not recognized. Type /tardishelp.")
        End Sub

        Private Sub ShowChatHelp(session As Integer)
            Console(session, 90, 190, 220, "CHAT CONTROLS | /hud [on|off] | /status | /skills | /missions | /travel | /inventory | /academy | /companions | /paradox | /sonic | /rooms")
            Console(session, 110, 175, 225, "TARDIS | /destinations | /distress | /adventure | /tardis coordinates <name> | /tardis helmic | /tardis artron <amount> | /tardis architecture | /tardis lifesupport | /tardis telepathic | /tardis handbrake | /tardis dematerialise")
            Console(session, 170, 150, 220, "ROLEPLAY TRIGGERS | 'TARDIS show HUD', 'TARDIS hide HUD', 'TARDIS status', 'TARDIS destinations', 'TARDIS distress', 'TARDIS adventure'.")
        End Sub

        Private Function GetFlight(session As Integer) As TardisFlightState
            If Not _flights.ContainsKey(session) Then
                _flights(session) = New TardisFlightState()
            End If
            Return _flights(session)
        End Function

        Private Function CurrentWorld(sender As AW.Instance) As String
            Dim w As String = ""
            Try
                w = sender.GetString(Attributes.WorldName)
            Catch
            End Try
            If String.IsNullOrWhiteSpace(w) Then w = _homeWorld
            Return w.Trim()
        End Function

        Private Sub HandleTardisControl(session As Integer, sender As AW.Instance, action As String)
            Dim profile As PlayerProfile = _sessions(session)
            Dim state As TardisFlightState = GetFlight(session)
            Dim controlType As String = GetParam(action, "type")
            state.LastControl = controlType

            If HandleV4TardisControl(session, sender, action, controlType) Then
                SaveProfiles()
                RefreshRpgHud(session, True)
                Return
            End If
            If HandleV3TardisControl(session, sender, action, controlType) Then
                SaveProfiles()
                RefreshRpgHud(session, True)
                Return
            End If

            Select Case controlType.ToLowerInvariant()
                Case "coordinates"
                    Dim requested As String = GetParam(action, "destination")
                    If requested = "" Then requested = sender.GetString(Attributes.ObjectDescription)
                    Dim dest As TardisDestination = FindDestination(requested, CurrentWorld(sender))
                    If dest Is Nothing Then
                        state.CoordinatesReady = False
                        Console(session, 200, 70, 70, "Navigation database has no destination named '" & requested & "'.")
                        Return
                    End If
                    Dim navCheck As SkillCheckResult = PerformSkillCheck(profile, "Navigation", dest.NavigationDifficulty)
                    state.DestinationKey = dest.Name
                    state.CoordinatesReady = Not navCheck.CriticalFailure
                    If state.CoordinatesReady Then
                        Console(session, 70, 190, 220, "Coordinates locked: " & DestinationLabel(dest, CurrentWorld(sender)) & ".")
                    Else
                        Console(session, 220, 80, 80, "Navigation matrix rejects the solution after a critical calibration failure.")
                    End If
                    ReportSkillGain(session, "Navigation", navCheck)
                    Console(session, 120, 170, 210, "Artron requirement: " & dest.ArtronCost.ToString() & " | Navigation difficulty: " & dest.NavigationDifficulty.ToString() & ".")

                Case "destinations"
                    ListDestinations(session, CurrentWorld(sender))

                Case "reloadnav"
                    LoadDestinations()
                    Console(session, 80, 180, 220, "TARDIS navigation database reloaded.")
                    ListDestinations(session, CurrentWorld(sender))

                Case "helmic"
                    Dim engCheck As SkillCheckResult = PerformSkillCheck(profile, "Engineering", 30)
                    state.HelmicReady = Not engCheck.CriticalFailure
                    Console(session, 70, 190, 180, If(state.HelmicReady, "Helmic regulator stable. Temporal drift is within tolerance.", "Helmic calibration arcs violently and refuses to stabilize."))
                    ReportSkillGain(session, "Engineering", engCheck)

                Case "artron"
                    Dim amount As Integer = ParseInt(GetParam(action, "amount"), 10)
                    If amount < 1 Then amount = 10
                    If amount > 50 Then amount = 50
                    If profile.ArtronReserve < amount Then
                        Console(session, 200, 80, 80, "LOW ARTRON RESERVE. Personal reserve: " & profile.ArtronReserve.ToString() & ".")
                        Return
                    End If
                    profile.ArtronReserve -= amount
                    state.ArtronCharge += amount
                    state.ArtronReady = (state.ArtronCharge >= 10)
                    SaveProfiles()
                    Console(session, 205, 170, 70, amount.ToString() & " Artron transferred to the console. Stored: " & state.ArtronCharge.ToString() & ".")

                Case "setinterior"
                    profile.InteriorWorld = CurrentWorld(sender)
                    profile.InteriorX = sender.GetInt(Attributes.ObjectX)
                    profile.InteriorY = sender.GetInt(Attributes.ObjectY)
                    profile.InteriorZ = sender.GetInt(Attributes.ObjectZ)
                    profile.InteriorYaw = sender.GetInt(Attributes.ObjectYaw)
                    SaveProfiles()
                    Console(session, 160, 120, 220, "TARDIS interior anchor recorded in " & profile.InteriorWorld & ".")

                Case "anchor"
                    Dim temporalCheck As SkillCheckResult = PerformSkillCheck(profile, "Temporal Science", 25)
                    state.AnchorReady = profile.HasInteriorAnchor() AndAlso Not temporalCheck.CriticalFailure
                    If state.AnchorReady Then
                        Console(session, 150, 120, 220, "Architectural anchor locked to your TARDIS interior.")
                    ElseIf Not profile.HasInteriorAnchor() Then
                        Console(session, 190, 90, 110, "No TARDIS interior anchor exists. Use a console object with type:setinterior first.")
                    Else
                        Console(session, 210, 90, 110, "Architectural configuration slips out of phase. Recalibrate the anchor.")
                    End If
                    ReportSkillGain(session, "Temporal Science", temporalCheck)

                Case "lifesupport"
                    Dim lifeCheck As SkillCheckResult = PerformSkillCheck(profile, "Engineering", 20)
                    state.LifeSupportReady = Not lifeCheck.CriticalFailure
                    Console(session, 90, 190, 120, If(state.LifeSupportReady, "Life-support synchronized. Atmosphere and biological systems nominal.", "Life-support diagnostic returns conflicting atmospheric readings."))
                    ReportSkillGain(session, "Engineering", lifeCheck)

                Case "telepathic"
                    Dim psychic As SkillCheckResult = PerformSkillCheck(profile, "Psychic", 25)
                    Console(session, 160, 100, 220, "The telepathic circuits brush your mind. Psychic check " & If(psychic.Success, "SUCCEEDED", "FAILED") & " (" & psychic.Roll.ToString() & " vs " & psychic.Target.ToString() & ").")
                    If psychic.Gain > 0 Then Console(session, 120, 210, 150, "Psychic skill +" & psychic.Gain.ToString("0.00") & ".")
                    SaveProfiles()

                Case "landingmode"
                    Dim mode As String = GetParam(action, "mode").ToLowerInvariant()
                    If mode = "open" OrElse mode = "sealed" Then
                        state.LandingMode = mode
                        Console(session, 100, 170, 220, "Landing mode: " & mode.ToUpperInvariant() & ".")
                    Else
                        Console(session, 190, 80, 80, "Unknown landing mode. Use OPEN or SEALED.")
                    End If

                Case "handbrake"
                    state.HandbrakeOn = Not state.HandbrakeOn
                    Console(session, 210, 150, 70, "TARDIS handbrake " & If(state.HandbrakeOn, "ENGAGED", "RELEASED") & ".")

                Case "hads"
                    Dim mode As String = GetParam(action, "mode").ToLowerInvariant()
                    state.HADSArmed = (mode = "on" OrElse mode = "armed")
                    Console(session, 90, 180, 220, "HADS " & If(state.HADSArmed, "ARMED", "DISARMED") & ".")

                Case "cloisterbell"
                    state.CloisterBellActive = True
                    state.EmergencyReason = "Manual Cloister Bell test."
                    Console(session, 210, 80, 80, "THE CLOISTER BELL IS RINGING.")

                Case "stabilize"
                    If state.ArtronCharge < 5 Then
                        Console(session, 200, 80, 80, "Stabilization requires 5 stored Artron.")
                    Else
                        state.ArtronCharge -= 5
                        state.CloisterBellActive = False
                        state.EmergencyReason = ""
                        Console(session, 100, 180, 200, "Temporal systems stabilize. The Cloister Bell falls silent.")
                    End If

                Case "hadstest"
                    If state.HADSArmed Then
                        ExecuteHADS(session, sender, "Artificial hostile-action test.")
                    Else
                        Console(session, 190, 100, 70, "HADS test failed: system is not armed.")
                    End If

                Case "status"
                    ShowTardisStatus(session, CurrentWorld(sender))

                Case "reset"
                    ResetFlight(session, True)
                    Console(session, 100, 160, 200, "Console preparation cleared. Stored Artron retained.")

                Case "dematerialise"
                    Dematerialise(session, sender)

                Case Else
                    Console(session, 180, 80, 180, "That TARDIS control is not configured.")
            End Select
        End Sub

        Private Sub Dematerialise(session As Integer, sender As AW.Instance)
            Dim profile As PlayerProfile = _sessions(session)
            Dim state As TardisFlightState = GetFlight(session)
            Dim current As String = CurrentWorld(sender)
            If profile.TardisPower <= 0 OrElse profile.TardisTemporalIntegrity <= 0 Then
                Console(session, 235, 60, 60, "TARDIS FLIGHT LOCKED: power or temporal integrity has collapsed. Engineering repairs are required.")
                Return
            End If
            Dim dest As TardisDestination = FindDestination(state.DestinationKey, current)
            If dest Is Nothing OrElse Not state.CoordinatesReady Then
                Console(session, 210, 70, 70, "NO VALID TEMPORAL COORDINATES.")
                Return
            End If

            state.ArtronReady = (state.ArtronCharge >= dest.ArtronCost)
            Dim ready As Integer = ReadyCount(profile, state)
            If state.HandbrakeOn AndAlso ready = 5 Then ready = 4

            If Not state.ArtronReady Then
                Console(session, 210, 90, 70, "LOW ARTRON RESERVE. Required: " & dest.ArtronCost.ToString() & " | Stored: " & state.ArtronCharge.ToString() & ".")
                Return
            End If

            state.ArtronCharge -= dest.ArtronCost

            If ready <= 2 Then
                state.CloisterBellActive = True
                state.EmergencyReason = "Catastrophic temporal instability."
                Console(session, 230, 70, 70, "THE CLOISTER BELL IS RINGING. Catastrophic temporal instability.")
                If state.HADSArmed AndAlso ExecuteHADS(session, sender, state.EmergencyReason) Then
                    ResetFlight(session, True)
                    Return
                End If
            End If

            If ready = 5 Then
                Console(session, 60, 210, 220, "VWORP... VWORP... Clean dematerialisation.")
            ElseIf ready = 4 Then
                Console(session, 220, 170, 70, "VWORP... One system slips out of synchronization.")
                ApplyDamage(profile, 10, "temporal", session, "rough TARDIS flight")
                DamageTardis(profile, 5, "temporal", session)
            ElseIf ready = 3 Then
                Console(session, 220, 110, 80, "The TARDIS lurches sideways through Time. TEMPORAL DRIFT DETECTED.")
                ApplyDamage(profile, 25, "temporal", session, "severe TARDIS drift")
                DamageTardis(profile, 12, "temporal", session)
            Else
                Console(session, 230, 70, 70, "The TARDIS goes somewhere anyway.")
                ApplyDamage(profile, 50, "temporal", session, "catastrophic TARDIS flight")
                DamageTardis(profile, 25, "hull", session)
                DamageTardis(profile, 20, "temporal", session)
            End If

            MaterialiseTardis(session, sender, state, dest, ready, current)
            ResetFlight(session, True)
            SaveProfiles()
        End Sub

        Private Sub MaterialiseTardis(session As Integer, sender As AW.Instance, state As TardisFlightState, dest As TardisDestination, accuracy As Integer, currentWorld As String)
            Dim profile As PlayerProfile = _sessions(session)
            Dim targetX As Integer = dest.X
            Dim targetY As Integer = dest.Y
            Dim targetZ As Integer = dest.Z
            Dim targetYaw As Integer = dest.Yaw
            Dim r As New Random()

            If accuracy = 4 Then
                targetX += r.Next(-2000, 2001)
                targetZ += r.Next(-2000, 2001)
            ElseIf accuracy = 3 Then
                targetX += r.Next(-4500, 4501)
                targetZ += r.Next(-4500, 4501)
            ElseIf accuracy <= 2 Then
                targetX += r.Next(-10000, 10001)
                targetZ += r.Next(-10000, 10001)
            End If

            Dim targetWorld As String = If(String.IsNullOrWhiteSpace(dest.WorldName), currentWorld, dest.WorldName.Trim())
            Dim crossWorld As Boolean = Not String.Equals(targetWorld, currentWorld, StringComparison.OrdinalIgnoreCase)

            ' Critical standalone rule:
            ' local flight -> teleport + materialised return shell
            ' cross-world flight -> teleport only; never try ObjectAdd in the remote world
            _sdk.SetString(Attributes.TeleportWorld, If(crossWorld, targetWorld, ""))
            _sdk.SetInt(Attributes.TeleportX, targetX)
            _sdk.SetInt(Attributes.TeleportY, targetY)
            _sdk.SetInt(Attributes.TeleportZ, targetZ)
            _sdk.SetInt(Attributes.TeleportYaw, targetYaw)
            _sdk.SetBool(Attributes.TeleportWarp, False)
            _sdk.Teleport(session)

            If crossWorld Then
                Console(session, 100, 180, 240, "Cross-world materialisation: " & targetWorld & ". No return shell was created outside " & currentWorld & ".")
            Else
                SpawnTardisShell(dest, state.LandingMode)
            End If
            RecordTravel(session, profile, dest, targetWorld)
            OnTravelV4(session, profile, dest, currentWorld, targetWorld)
            RefreshRpgHud(session, True)
        End Sub

        Private Sub SpawnTardisShell(dest As TardisDestination, landingMode As String)
            On Error Resume Next
            _sdk.SetString(Attributes.ObjectModel, "rcl-tardisb.rwx")
            _sdk.SetString(Attributes.ObjectDescription, "TARDIS - Return to interior")
            If landingMode.ToLowerInvariant() = "open" Then
                _sdk.SetString(Attributes.ObjectAction, "create scale 2.5,solid no;activate ~tardisreturn")
            Else
                _sdk.SetString(Attributes.ObjectAction, "create scale 2.5;activate ~tardisreturn")
            End If
            _sdk.SetInt(Attributes.ObjectX, dest.X)
            _sdk.SetInt(Attributes.ObjectY, dest.Y)
            _sdk.SetInt(Attributes.ObjectZ, dest.Z)
            _sdk.SetInt(Attributes.ObjectYaw, dest.Yaw)
            _sdk.ObjectAdd()
        End Sub

        Private Sub ReturnToInterior(session As Integer, sender As AW.Instance)
            Dim profile As PlayerProfile = _sessions(session)
            If Not profile.HasInteriorAnchor() Then
                Console(session, 190, 70, 70, "The TARDIS cannot locate your interior anchor.")
                Return
            End If

            Dim current As String = CurrentWorld(sender)
            Dim crossWorld As Boolean = Not String.Equals(profile.InteriorWorld, current, StringComparison.OrdinalIgnoreCase)
            _sdk.SetString(Attributes.TeleportWorld, If(crossWorld, profile.InteriorWorld, ""))
            _sdk.SetInt(Attributes.TeleportX, profile.InteriorX)
            _sdk.SetInt(Attributes.TeleportY, profile.InteriorY)
            _sdk.SetInt(Attributes.TeleportZ, profile.InteriorZ)
            _sdk.SetInt(Attributes.TeleportYaw, profile.InteriorYaw)
            _sdk.SetBool(Attributes.TeleportWarp, False)
            _sdk.Teleport(session)
            Console(session, 120, 110, 220, "The doors close. The TARDIS returns you to its interior.")
        End Sub

        Private Function ExecuteHADS(session As Integer, sender As AW.Instance, reason As String) As Boolean
            Dim profile As PlayerProfile = _sessions(session)
            If Not profile.HasInteriorAnchor() Then
                Console(session, 210, 80, 80, "HADS cannot displace the TARDIS: no interior anchor is recorded.")
                Return False
            End If
            Console(session, 220, 120, 80, "HADS ENGAGED: " & reason)
            ReturnToInterior(session, sender)
            Return True
        End Function

        Private Sub ShowTardisStatus(session As Integer, currentWorld As String)
            Dim state As TardisFlightState = GetFlight(session)
            Dim profile As PlayerProfile = _sessions(session)
            Dim ready As Integer = ReadyCount(profile, state)
            Console(session, 40, 180, 220, "TARDIS FLIGHT SYSTEMS: " & ready.ToString() & "/5 READY")
            Console(session, 120, 180, 220, "Coordinates: " & If(state.CoordinatesReady, "LOCKED", "NOT SET") & " | Destination: " & state.DestinationKey)
            Console(session, 120, 180, 220, "Helmic: " & If(state.HelmicReady, "STABLE", "UNSTABLE") & " | Anchor: " & If(state.AnchorReady, "LOCKED", "UNLOCKED"))
            Console(session, 120, 180, 220, "Life Support: " & If(state.LifeSupportReady, "READY", "NOT READY") & " | Artron: " & state.ArtronCharge.ToString())
            Console(session, 120, 180, 220, "Handbrake: " & If(state.HandbrakeOn, "ON", "OFF") & " | HADS: " & If(state.HADSArmed, "ARMED", "OFF") & " | World: " & currentWorld)
        End Sub

        Private Function ReadyCount(profile As PlayerProfile, state As TardisFlightState) As Integer
            Dim ready As Integer = 0
            If state.CoordinatesReady Then ready += 1
            If state.HelmicReady Then ready += 1
            If state.ArtronReady Then ready += 1
            If state.AnchorReady Then ready += 1
            If state.LifeSupportReady Then ready += 1

            ' Five-way synchronization still has a piloting check, but it now uses
            ' a Doctor-Who-specific PilotingSkill instead of DWMyths Mind + Body.
            If ready = 5 Then
                Dim flightCheck As SkillCheckResult = PerformSkillCheck(profile, "Piloting", 45)
                If Not flightCheck.Success Then ready = 4
            End If
            Return ready
        End Function

        Private Sub ResetFlight(session As Integer, keepArtron As Boolean)
            Dim oldState As TardisFlightState = GetFlight(session)
            Dim stored As Integer = If(keepArtron, oldState.ArtronCharge, 0)
            Dim newState As New TardisFlightState()
            newState.ArtronCharge = stored
            newState.ArtronReady = (stored >= 10)
            _flights(session) = newState
        End Sub

        Private Sub HandleTimeLordControl(session As Integer, sender As AW.Instance, action As String)
            Dim p As PlayerProfile = _sessions(session)
            Dim timeLordType As String = GetParam(action, "type")
            If HandleV4TimeLordControl(session, sender, action, timeLordType) Then
                SaveProfiles()
                RefreshRpgHud(session, True)
                Return
            End If
            If HandleV3TimeLordControl(session, sender, action, timeLordType) Then
                SaveProfiles()
                RefreshRpgHud(session, True)
                Return
            End If
            Select Case timeLordType.ToLowerInvariant()
                Case "status"
                    ShowTimeLordStatus(session, p)

                Case "skills"
                    ShowSkills(session, p)

                Case "awaken"
                    p.IsTimeLord = True
                    p.Species = "Time Lord"
                    p.IsDead = False
                    If p.Incarnation <= 0 Then p.Incarnation = 1
                    If p.RegenerationsRemaining <= 0 Then p.RegenerationsRemaining = 12
                    p.RegenerationBlocked = False
                    If p.IncarnationHistory.Count = 0 Then
                        p.IncarnationHistory.Add(New IncarnationRecord With {.Number = p.Incarnation, .StartedUtc = DateTime.UtcNow})
                    End If
                    EnsureSkills(p)
                    If p.IncarnationTraits Is Nothing OrElse p.IncarnationTraits.Count = 0 Then RollIncarnationTraits(p)
                    If p.HeartOneHealth <= 0 Then p.HeartOneHealth = 100
                    If p.HeartTwoHealth <= 0 Then p.HeartTwoHealth = 100
                    SaveProfiles()
                    Console(session, 210, 160, 80, "Two hearts answer inside your chest. TIME LORD BIOLOGY AWAKENED.")

                Case "human"
                    p.IsTimeLord = False
                    p.Species = "Human"
                    SaveProfiles()
                    Console(session, 120, 120, 160, "The regeneration matrix falls silent.")

                Case "blockregen"
                    p.RegenerationBlocked = True
                    SaveProfiles()
                    Console(session, 200, 60, 60, "The regeneration matrix has been suppressed.")

                Case "unblockregen"
                    p.RegenerationBlocked = False
                    SaveProfiles()
                    Console(session, 180, 150, 80, "The regeneration matrix is functioning again.")

                Case "regenerate"
                    Regenerate(session, p, "voluntary regeneration")

                Case "damage"
                    Dim amount As Integer = ParseInt(GetParam(action, "amount"), 25)
                    Dim damageType As String = GetParam(action, "damagetype")
                    If damageType = "" Then damageType = "physical"
                    ApplyDamage(p, amount, damageType, session, "Time Lord control")
                    SaveProfiles()

                Case "heal"
                    Dim amount As Integer = ParseInt(GetParam(action, "amount"), 25)
                    ApplyHealing(p, amount, session, "cellular repair")
                    SaveProfiles()

                Case "artronheal"
                    Dim amount As Integer = ParseInt(GetParam(action, "amount"), 20)
                    amount = Math.Max(1, Math.Min(50, amount))
                    Dim cost As Integer = Math.Max(5, CInt(Math.Ceiling(amount * 0.75)))
                    If p.ArtronReserve < cost Then
                        Console(session, 210, 80, 80, "Insufficient Artron reserve for accelerated cellular repair. Need " & cost.ToString() & ".")
                    Else
                        p.ArtronReserve -= cost
                        ApplyHealing(p, amount, session, "Artron cellular repair")
                        Dim check As SkillCheckResult = PerformSkillCheck(p, "Medicine", 35)
                        If check.Gain > 0 Then Console(session, 100, 200, 130, "Medicine skill +" & check.Gain.ToString("0.00") & ".")
                        SaveProfiles()
                    End If

                Case Else
                    Console(session, 180, 80, 180, "Your biology does not respond to that command.")
            End Select
        End Sub

        Private Sub HandleRpgAction(session As Integer, sender As AW.Instance, action As String)
            Dim p As PlayerProfile = _sessions(session)
            Dim command As String = GetParam(action, "action").ToLowerInvariant()
            If command = "" Then command = GetParam(action, "type").ToLowerInvariant()

            If HandleV4RpgAction(session, sender, action, command) Then
                SaveProfiles()
                RefreshRpgHud(session, True)
                Return
            End If
            If HandleV3RpgAction(session, sender, action, command) Then
                SaveProfiles()
                RefreshRpgHud(session, True)
                Return
            End If

            Select Case command
                Case "damage"
                    Dim amount As Integer = Math.Max(0, ParseInt(GetParam(action, "amount"), 10))
                    Dim damageType As String = GetParam(action, "damagetype")
                    If damageType = "" Then damageType = "physical"
                    ApplyDamage(p, amount, damageType, session, sender.GetString(Attributes.ObjectDescription))

                Case "heal"
                    ApplyHealing(p, Math.Max(0, ParseInt(GetParam(action, "amount"), 10)), session, sender.GetString(Attributes.ObjectDescription))

                Case "status"
                    Dim statusName As String = GetParam(action, "name")
                    Dim duration As Integer = Math.Max(1, ParseInt(GetParam(action, "duration"), 60))
                    Dim potency As Integer = Math.Max(1, ParseInt(GetParam(action, "potency"), 1))
                    AddStatus(p, statusName, duration, potency, sender.GetString(Attributes.ObjectDescription), session)

                Case "cure"
                    RemoveStatus(p, GetParam(action, "name"), session)

                Case "skillcheck"
                    Dim skillName As String = GetParam(action, "skill")
                    Dim difficulty As Integer = RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 50), 1, 100)
                    Dim result As SkillCheckResult = PerformSkillCheck(p, skillName, difficulty)
                    ReportSkillCheck(session, skillName, difficulty, result)

                Case "artron"
                    Dim amount As Integer = ParseInt(GetParam(action, "amount"), 0)
                    p.ArtronReserve = RpgRules.Clamp(p.ArtronReserve + amount, 0, p.MaxArtronReserve)
                    Console(session, 170, 120, 220, "Artron reserve " & If(amount >= 0, "+", "") & amount.ToString() & ". Current reserve: " & p.ArtronReserve.ToString() & "/" & p.MaxArtronReserve.ToString() & ".")

                Case "tardisdamage"
                    Dim amount As Integer = Math.Max(0, ParseInt(GetParam(action, "amount"), 10))
                    DamageTardis(p, amount, GetParam(action, "system"), session)

                Case "repair"
                    RepairTardis(p, GetParam(action, "system"), RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 45), 1, 100), session)

                Case "medbay"
                    Dim difficulty As Integer = RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 30), 1, 100)
                    Dim result As SkillCheckResult = PerformSkillCheck(p, "Medicine", difficulty)
                    Dim healAmount As Integer = If(result.Success, 30, 10)
                    ApplyHealing(p, healAmount, session, "TARDIS medical bay")
                    If result.Success Then CureOneHarmfulStatus(p, session)
                    ReportSkillGain(session, "Medicine", result)

                Case "statusreport"
                    ShowTimeLordStatus(session, p)

                Case "skills"
                    ShowSkills(session, p)

                Case Else
                    Console(session, 180, 80, 180, "Unknown RPG action '" & command & "'.")
            End Select
            SaveProfiles()
        End Sub

        Public Sub Tick()
            If Not Connected Then Return
            Dim now As DateTime = DateTime.UtcNow

            ' Keep the AW event pump fast, but run game-state work at 4 Hz instead of
            ' 20 Hz. Status effects themselves are timed in seconds, so this remains
            ' far more responsive than the gameplay requires while reducing CPU churn.
            If _profilesDirty AndAlso (now - _lastProfileWriteUtc).TotalSeconds >= ProfileSaveDebounceSeconds Then
                SaveProfiles(True)
            End If
            If now < _nextGameTickUtc Then Return
            _nextGameTickUtc = now.AddMilliseconds(GameTickMilliseconds)

            Dim changed As Boolean = False
            For Each pair As KeyValuePair(Of Integer, PlayerProfile) In New Dictionary(Of Integer, PlayerProfile)(_sessions)
                Dim session As Integer = pair.Key
                Dim p As PlayerProfile = pair.Value
                For i As Integer = p.StatusEffects.Count - 1 To 0 Step -1
                    Dim status As ActiveStatus = p.StatusEffects(i)
                    If now >= status.ExpiresUtc Then
                        Console(session, 120, 180, 150, status.Name & " has worn off.")
                        p.StatusEffects.RemoveAt(i)
                        changed = True
                        Continue For
                    End If
                    If now >= status.NextTickUtc Then
                        status.NextTickUtc = now.AddSeconds(StatusTickSeconds(status.Name))
                        ApplyStatusTick(p, status, session)
                        changed = True
                    End If
                Next
            Next
            TickV3(now)
            TickV4(now)
            If changed Then SaveProfiles()
        End Sub

        Private Function StatusTickSeconds(statusName As String) As Integer
            Select Case statusName.Trim().ToLowerInvariant()
                Case "burning" : Return 5
                Case "bleeding" : Return 10
                Case "poisoned", "poison" : Return 10
                Case "irradiated", "radiation" : Return 15
                Case "artron starved", "artronstarved" : Return 20
                Case Else : Return 15
            End Select
        End Function

        Private Sub ApplyStatusTick(p As PlayerProfile, status As ActiveStatus, session As Integer)
            Select Case status.Name.Trim().ToLowerInvariant()
                Case "burning"
                    ApplyDamage(p, Math.Max(1, status.Potency * 2), "fire", session, status.Source, False)
                Case "bleeding"
                    ApplyDamage(p, Math.Max(1, status.Potency), "physical", session, status.Source, False)
                Case "poisoned", "poison"
                    ApplyDamage(p, Math.Max(1, status.Potency), "poison", session, status.Source, False)
                Case "irradiated", "radiation"
                    ApplyDamage(p, Math.Max(1, status.Potency), "radiation", session, status.Source, False)
                Case "artron starved", "artronstarved"
                    p.ArtronReserve = Math.Max(0, p.ArtronReserve - Math.Max(1, status.Potency))
                    Console(session, 190, 120, 220, "Artron starvation drains your reserve to " & p.ArtronReserve.ToString() & ".")
            End Select
        End Sub

        Private Sub ApplyDamage(p As PlayerProfile, amount As Integer, damageType As String, session As Integer, source As String, Optional allowStatus As Boolean = True)
            If amount <= 0 OrElse p.IsDead Then Return
            damageType = If(String.IsNullOrWhiteSpace(damageType), "physical", damageType.Trim().ToLowerInvariant())
            Dim finalAmount As Integer = Math.Max(0, amount)

            If p.IsTimeLord AndAlso damageType = "radiation" Then finalAmount = CInt(Math.Ceiling(finalAmount * 0.85))
            If HasIncarnationTrait(p, "Iron Constitution") Then finalAmount = CInt(Math.Ceiling(finalAmount * 0.9))
            If HasStatus(p, "regeneration sickness") Then finalAmount = CInt(Math.Ceiling(finalAmount * 1.15))

            p.Health = Math.Max(0, p.Health - finalAmount)
            Console(session, 220, 100, 90, damageType.ToUpperInvariant() & " damage: " & finalAmount.ToString() & ". Health: " & p.Health.ToString() & "/" & p.MaxHealth.ToString() & ".")

            If allowStatus AndAlso finalAmount >= 8 Then
                Select Case damageType
                    Case "fire"
                        If _rng.Next(1, 101) <= 35 Then AddStatus(p, "Burning", 30, Math.Max(1, finalAmount \ 10), source, session)
                    Case "radiation"
                        If _rng.Next(1, 101) <= 50 Then AddStatus(p, "Irradiated", 90, Math.Max(1, finalAmount \ 12), source, session)
                    Case "poison"
                        AddStatus(p, "Poisoned", 90, Math.Max(1, finalAmount \ 12), source, session)
                    Case "temporal"
                        p.ArtronReserve = Math.Max(0, p.ArtronReserve - Math.Max(1, finalAmount \ 2))
                        If _rng.Next(1, 101) <= 35 Then AddStatus(p, "Temporal Displaced", 60, 1, source, session)
                    Case "psychic"
                        If _rng.Next(1, 101) <= 35 Then AddStatus(p, "Psychically Overloaded", 60, 1, source, session)
                    Case "physical", "explosive"
                        If finalAmount >= 20 AndAlso _rng.Next(1, 101) <= 30 Then AddStatus(p, "Bleeding", 60, Math.Max(1, finalAmount \ 20), source, session)
                End Select
            End If

            If p.IsTimeLord AndAlso finalAmount >= 12 AndAlso (damageType = "physical" OrElse damageType = "explosive" OrElse damageType = "energy") Then
                ApplyHeartTrauma(p, finalAmount, session)
            End If

            If p.Health > 0 AndAlso p.Health <= Math.Max(8, CInt(Math.Round(p.MaxHealth * 0.15))) AndAlso Not HasStatus(p, "Unconscious") Then
                If _rng.Next(1, 101) <= 35 Then AddStatus(p, "Unconscious", 30, 1, source, session)
            End If

            If p.Health <= 0 Then HandleZeroHealth(session, p, damageType & If(source = "", "", " from " & source))
            RefreshRpgHud(session, True)
        End Sub

        Private Sub ApplyHealing(p As PlayerProfile, amount As Integer, session As Integer, source As String)
            If amount <= 0 Then Return
            If p.IsDead Then
                Console(session, 180, 70, 70, "Healing cannot restore a dead incarnation. Regeneration or revival is required.")
                Return
            End If
            Dim before As Integer = p.Health
            p.Health = Math.Min(p.MaxHealth, p.Health + amount)
            Dim healed As Integer = p.Health - before
            Console(session, 100, 190, 130, source & " restores " & healed.ToString() & " health. Health: " & p.Health.ToString() & "/" & p.MaxHealth.ToString() & ".")
            If p.Health > CInt(Math.Round(p.MaxHealth * 0.2)) Then RemoveStatusSilent(p, "Unconscious")
            RefreshRpgHud(session, True)
        End Sub

        Private Sub HandleZeroHealth(session As Integer, p As PlayerProfile, cause As String)
            If p.IsTimeLord AndAlso Not p.RegenerationBlocked AndAlso p.RegenerationsRemaining > 0 Then
                Regenerate(session, p, cause)
            Else
                p.IsDead = True
                p.Health = 0
                Console(session, 230, 60, 60, "BIOLOGICAL TERMINATION. " & If(p.IsTimeLord, "The regeneration matrix cannot respond.", "No regeneration matrix is present."))
            End If
        End Sub

        Private Sub Regenerate(session As Integer, p As PlayerProfile, cause As String)
            If Not p.IsTimeLord Then
                Console(session, 180, 70, 70, "Your biology contains no regeneration matrix.")
                Return
            End If
            If p.RegenerationBlocked Then
                Console(session, 210, 70, 70, "REGENERATION BLOCKED.")
                Return
            End If
            If p.RegenerationsRemaining <= 0 Then
                Console(session, 210, 70, 70, "The regeneration cycle is exhausted.")
                Return
            End If
            If p.Health > Math.Max(1, CInt(Math.Round(p.MaxHealth * 0.25))) Then
                Console(session, 180, 120, 70, "Your body refuses regeneration. You are not critically injured.")
                Return
            End If

            If p.IncarnationHistory.Count = 0 Then p.IncarnationHistory.Add(New IncarnationRecord With {.Number = p.Incarnation, .StartedUtc = DateTime.UtcNow})
            Dim previous As IncarnationRecord = p.IncarnationHistory(p.IncarnationHistory.Count - 1)
            previous.EndedUtc = DateTime.UtcNow
            previous.Cause = cause

            p.RegenerationsRemaining -= 1
            p.Incarnation += 1
            p.IsDead = False
            p.HeartOneHealth = 100
            p.HeartTwoHealth = 100
            RemoveStatusSilent(p, "Unconscious")
            RollIncarnationTraits(p)
            p.Health = p.MaxHealth
            p.ArtronReserve = Math.Min(p.MaxArtronReserve, p.ArtronReserve + 50)
            p.IncarnationHistory.Add(New IncarnationRecord With {.Number = p.Incarnation, .StartedUtc = DateTime.UtcNow})
            AddStatus(p, "Regeneration Sickness", 180, 1, "regeneration", session)

            Console(session, 240, 190, 80, "REGENERATION ENERGY ERUPTS. Incarnation " & p.Incarnation.ToString() & " begins.")
            Console(session, 170, 120, 220, "Regenerations remaining: " & p.RegenerationsRemaining.ToString() & ". Post-regeneration trauma will temporarily impair difficult checks.")
            SaveProfiles()
        End Sub

        Private Function PerformSkillCheck(p As PlayerProfile, rawSkillName As String, difficulty As Integer) As SkillCheckResult
            EnsureSkills(p)
            Dim skillName As String = RpgRules.NormalizeSkillName(rawSkillName)
            If skillName = "" Then skillName = "Investigation"
            Dim skill As SkillProgress = GetSkill(p, skillName)
            difficulty = RpgRules.Clamp(difficulty, 1, 100)

            Dim effective As Double = skill.Value + TraitSkillBonus(p, skillName) + V4SkillModifier(p, skillName)
            If HasStatus(p, "Unconscious") Then effective -= 80
            If HasStatus(p, "regeneration sickness") Then effective -= 15
            If HasStatus(p, "psychically overloaded") AndAlso skillName = "Psychic" Then effective -= 25
            If HasStatus(p, "temporal displaced") AndAlso (skillName = "Navigation" OrElse skillName = "Temporal Science" OrElse skillName = "Piloting") Then effective -= 20
            effective = RpgRules.Clamp(effective, 1.0, 100.0)

            Dim target As Integer = RpgRules.Clamp(CInt(Math.Round(50 + effective - difficulty)), 5, 95)
            Dim roll As Integer = _rng.Next(1, 101)
            Dim success As Boolean = roll <= target
            Dim criticalSuccess As Boolean = roll <= 5
            Dim criticalFailure As Boolean = roll >= 96
            If criticalSuccess Then success = True
            If criticalFailure Then success = False

            skill.Uses += 1
            If success Then skill.SuccessfulChecks += 1
            Dim gain As Double = CalculateSkillGain(skill.Value, difficulty)
            If gain > 0 Then skill.Value = RpgRules.Clamp(skill.Value + gain, 0.0, 100.0)
            If skillName = "Piloting" Then p.PilotingSkill = CInt(Math.Round(skill.Value))

            Return New SkillCheckResult With {
                .Success = success,
                .CriticalSuccess = criticalSuccess,
                .CriticalFailure = criticalFailure,
                .Roll = roll,
                .Target = target,
                .SkillValue = skill.Value,
                .Gain = gain
            }
        End Function

        Private Function CalculateSkillGain(currentSkill As Double, difficulty As Integer) As Double
            If difficulty + 20 < currentSkill Then Return 0
            Dim chance As Integer = RpgRules.Clamp(CInt(Math.Round(difficulty - currentSkill + 50)), 5, 90)
            If _rng.Next(1, 101) > chance Then Return 0
            Dim minimum As Double
            Dim maximum As Double
            If currentSkill < 25 Then
                minimum = 0.2 : maximum = 0.6
            ElseIf currentSkill < 60 Then
                minimum = 0.1 : maximum = 0.3
            ElseIf currentSkill < 85 Then
                minimum = 0.03 : maximum = 0.15
            Else
                minimum = 0.01 : maximum = 0.05
            End If
            Return Math.Round(minimum + (_rng.NextDouble() * (maximum - minimum)), 2)
        End Function

        Private Sub ReportSkillCheck(session As Integer, rawSkillName As String, difficulty As Integer, result As SkillCheckResult)
            Dim name As String = RpgRules.NormalizeSkillName(rawSkillName)
            If name = "" Then name = "Investigation"
            Dim verdict As String = If(result.CriticalSuccess, "CRITICAL SUCCESS", If(result.CriticalFailure, "CRITICAL FAILURE", If(result.Success, "SUCCESS", "FAILURE")))
            Console(session, If(result.Success, 100, 210), If(result.Success, 200, 90), 150, name & " check (difficulty " & difficulty.ToString() & "): " & verdict & " — roll " & result.Roll.ToString() & "/" & result.Target.ToString() & ".")
            ReportSkillGain(session, name, result)
        End Sub

        Private Sub ReportSkillGain(session As Integer, skillName As String, result As SkillCheckResult)
            If result.Gain > 0 Then Console(session, 100, 210, 150, skillName & " skill +" & result.Gain.ToString("0.00") & " (" & result.SkillValue.ToString("0.00") & ").")
            If _sessions.ContainsKey(session) Then OnSkillUseV4(session, _sessions(session), RpgRules.NormalizeSkillName(skillName), result)
        End Sub

        Private Sub EnsureSkills(p As PlayerProfile)
            If p.Skills Is Nothing Then p.Skills = New List(Of SkillProgress)()
            For Each skillName As String In RpgRules.SkillNames
                Dim existing As SkillProgress = Nothing
                For Each s As SkillProgress In p.Skills
                    If String.Equals(s.Name, skillName, StringComparison.OrdinalIgnoreCase) Then existing = s : Exit For
                Next
                If existing Is Nothing Then
                    Dim startValue As Double = 10
                    If skillName = "Piloting" AndAlso p.PilotingSkill > 0 Then startValue = p.PilotingSkill
                    p.Skills.Add(New SkillProgress With {.Name = skillName, .Value = startValue})
                End If
            Next
        End Sub

        Private Function GetSkill(p As PlayerProfile, rawSkillName As String) As SkillProgress
            EnsureSkills(p)
            Dim skillName As String = RpgRules.NormalizeSkillName(rawSkillName)
            If skillName = "" Then skillName = "Investigation"
            For Each s As SkillProgress In p.Skills
                If String.Equals(s.Name, skillName, StringComparison.OrdinalIgnoreCase) Then Return s
            Next
            Dim created As New SkillProgress With {.Name = skillName, .Value = 10}
            p.Skills.Add(created)
            Return created
        End Function

        Private Function GetSkillValue(p As PlayerProfile, skillName As String) As Double
            Return GetSkill(p, skillName).Value
        End Function

        Private Sub ShowSkills(session As Integer, p As PlayerProfile)
            EnsureSkills(p)
            Dim parts As New List(Of String)()
            For Each s As SkillProgress In p.Skills
                parts.Add(s.Name & " " & s.Value.ToString("0.0"))
            Next
            Console(session, 120, 190, 220, "SKILLS | " & String.Join(" | ", parts.ToArray()))
        End Sub

        Private Sub ShowTimeLordStatus(session As Integer, p As PlayerProfile)
            Console(session, 210, 160, 80, "TIME LORD STATUS | Incarnation " & p.Incarnation.ToString() & " | Regenerations: " & p.RegenerationsRemaining.ToString() & " | " & If(p.IsDead, "DEAD", "ALIVE"))
            Console(session, 170, 120, 200, "Health " & p.Health.ToString() & "/" & p.MaxHealth.ToString() & " | Artron " & p.ArtronReserve.ToString() & "/" & p.MaxArtronReserve.ToString() & " | Matrix " & If(p.RegenerationBlocked, "BLOCKED", "ACTIVE"))
            Console(session, 100, 170, 220, "TARDIS | Hull " & p.TardisHull.ToString() & "/100 | Temporal " & p.TardisTemporalIntegrity.ToString() & "/100 | Power " & p.TardisPower.ToString() & "/100")
            If p.StatusEffects.Count > 0 Then
                Dim names As New List(Of String)()
                For Each st As ActiveStatus In p.StatusEffects
                    names.Add(st.Name)
                Next
                Console(session, 210, 130, 90, "Status: " & String.Join(", ", names.ToArray()))
            Else
                Console(session, 110, 190, 140, "Status: stable.")
            End If
        End Sub

        Private Sub AddStatus(p As PlayerProfile, statusName As String, durationSeconds As Integer, potency As Integer, source As String, session As Integer)
            If String.IsNullOrWhiteSpace(statusName) Then Return
            If p.StatusEffects Is Nothing Then p.StatusEffects = New List(Of ActiveStatus)()
            Dim existing As ActiveStatus = Nothing
            For Each st As ActiveStatus In p.StatusEffects
                If String.Equals(st.Name, statusName, StringComparison.OrdinalIgnoreCase) Then existing = st : Exit For
            Next
            If existing Is Nothing Then
                existing = New ActiveStatus With {.Name = statusName.Trim()}
                p.StatusEffects.Add(existing)
            End If
            existing.Potency = Math.Max(existing.Potency, potency)
            existing.ExpiresUtc = DateTime.UtcNow.AddSeconds(durationSeconds)
            existing.NextTickUtc = DateTime.UtcNow.AddSeconds(StatusTickSeconds(statusName))
            existing.Source = source
            Console(session, 210, 130, 90, "STATUS ACQUIRED: " & existing.Name & " (" & durationSeconds.ToString() & "s).")
        End Sub

        Private Function HasStatus(p As PlayerProfile, statusName As String) As Boolean
            If p.StatusEffects Is Nothing Then Return False
            For Each st As ActiveStatus In p.StatusEffects
                If String.Equals(st.Name.Replace(" ", ""), statusName.Replace(" ", ""), StringComparison.OrdinalIgnoreCase) Then Return True
            Next
            Return False
        End Function

        Private Sub RemoveStatus(p As PlayerProfile, statusName As String, session As Integer)
            If String.IsNullOrWhiteSpace(statusName) Then Return
            For i As Integer = p.StatusEffects.Count - 1 To 0 Step -1
                If String.Equals(p.StatusEffects(i).Name.Replace(" ", ""), statusName.Replace(" ", ""), StringComparison.OrdinalIgnoreCase) Then
                    Console(session, 100, 190, 130, p.StatusEffects(i).Name & " has been cured.")
                    p.StatusEffects.RemoveAt(i)
                End If
            Next
        End Sub

        Private Sub CureOneHarmfulStatus(p As PlayerProfile, session As Integer)
            Dim harmful() As String = {"Burning", "Bleeding", "Poisoned", "Irradiated", "Psychically Overloaded", "Temporal Displaced"}
            For Each name As String In harmful
                If HasStatus(p, name) Then
                    RemoveStatus(p, name, session)
                    Return
                End If
            Next
        End Sub

        Private Sub DamageTardis(p As PlayerProfile, amount As Integer, systemName As String, session As Integer)
            systemName = If(String.IsNullOrWhiteSpace(systemName), "hull", systemName.Trim().ToLowerInvariant())
            Select Case systemName
                Case "temporal", "temporalintegrity"
                    p.TardisTemporalIntegrity = Math.Max(0, p.TardisTemporalIntegrity - amount)
                    Console(session, 230, 90, 80, "TARDIS temporal integrity suffers " & amount.ToString() & " damage. " & p.TardisTemporalIntegrity.ToString() & "/100.")
                Case "power"
                    p.TardisPower = Math.Max(0, p.TardisPower - amount)
                    Console(session, 230, 120, 70, "TARDIS power systems lose " & amount.ToString() & " points. " & p.TardisPower.ToString() & "/100.")
                Case Else
                    p.TardisHull = Math.Max(0, p.TardisHull - amount)
                    Console(session, 230, 90, 80, "TARDIS hull integrity suffers " & amount.ToString() & " damage. " & p.TardisHull.ToString() & "/100.")
            End Select
            If p.TardisHull <= 25 OrElse p.TardisTemporalIntegrity <= 25 OrElse p.TardisPower <= 15 Then Console(session, 240, 60, 60, "CLOISTER BELL: CRITICAL TARDIS DAMAGE.")
        End Sub

        Private Sub RepairTardis(p As PlayerProfile, systemName As String, difficulty As Integer, session As Integer)
            systemName = If(String.IsNullOrWhiteSpace(systemName), "hull", systemName.Trim().ToLowerInvariant())
            Dim check As SkillCheckResult = PerformSkillCheck(p, "Engineering", difficulty)
            If check.Success Then
                Dim repairAmount As Integer = If(check.CriticalSuccess, 30, 15)
                Select Case systemName
                    Case "temporal", "temporalintegrity" : p.TardisTemporalIntegrity = Math.Min(100, p.TardisTemporalIntegrity + repairAmount)
                    Case "power" : p.TardisPower = Math.Min(100, p.TardisPower + repairAmount)
                    Case Else : p.TardisHull = Math.Min(100, p.TardisHull + repairAmount)
                End Select
                Console(session, 90, 200, 160, "Engineering repair succeeds: " & systemName & " +" & repairAmount.ToString() & ".")
            Else
                Console(session, 220, 120, 80, "Engineering repair fails. The fault remains unresolved.")
                If check.CriticalFailure Then DamageTardis(p, 5, systemName, session)
            End If
            ReportSkillGain(session, "Engineering", check)
        End Sub

        Private Sub LoadDestinations()
            _destinations.Clear()
            If Not File.Exists(_destinationsPath) Then Return

            For Each raw As String In File.ReadAllLines(_destinationsPath)
                Dim line As String = raw.Trim()
                If line = "" OrElse line.StartsWith("#") OrElse line.StartsWith("'") Then Continue For
                Dim parts() As String = line.Split("|"c)
                Dim d As New TardisDestination()

                ' New format: Name|World|X|Y|Z|Yaw|ArtronCost|alias1,alias2
                ' Legacy format: Name|X|Y|Z|Yaw|ArtronCost
                If parts.Length >= 7 AndAlso Not IsNumeric(parts(1).Trim()) Then
                    d.Name = parts(0).Trim()
                    d.WorldName = parts(1).Trim()
                    d.X = ParseInt(parts(2), 0)
                    d.Y = ParseInt(parts(3), 0)
                    d.Z = ParseInt(parts(4), 0)
                    d.Yaw = ParseInt(parts(5), 0)
                    d.ArtronCost = Math.Max(1, ParseInt(parts(6), 10))
                    If parts.Length >= 8 Then d.Aliases = parts(7).Trim()
                    If parts.Length >= 9 Then d.NavigationDifficulty = RpgRules.Clamp(ParseInt(parts(8), 35), 1, 100)
                ElseIf parts.Length >= 5 Then
                    d.Name = parts(0).Trim()
                    d.WorldName = ""
                    d.X = ParseInt(parts(1), 0)
                    d.Y = ParseInt(parts(2), 0)
                    d.Z = ParseInt(parts(3), 0)
                    d.Yaw = ParseInt(parts(4), 0)
                    If parts.Length >= 6 Then d.ArtronCost = Math.Max(1, ParseInt(parts(5), 10))
                Else
                    Continue For
                End If

                If d.Name = "" Then Continue For
                _destinations(d.Name) = d
                If d.WorldName <> "" Then _destinations(d.WorldName & ":" & d.Name) = d
                If d.Aliases <> "" Then
                    For Each aliasName As String In d.Aliases.Split(","c)
                        If aliasName.Trim() <> "" Then _destinations(aliasName.Trim()) = d
                    Next
                End If
            Next
        End Sub

        Private Function FindDestination(name As String, currentWorld As String) As TardisDestination
            If String.IsNullOrWhiteSpace(name) Then Return Nothing
            Dim d As TardisDestination = Nothing
            If _destinations.TryGetValue(name.Trim(), d) Then Return d
            If _destinations.TryGetValue(currentWorld & ":" & name.Trim(), d) Then Return d
            Return Nothing
        End Function

        Private Sub ListDestinations(session As Integer, currentWorld As String)
            Dim seen As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
            Dim names As New List(Of String)()
            For Each d As TardisDestination In _destinations.Values
                Dim key As String = d.Name & "|" & d.WorldName
                If seen.Add(key) Then names.Add(DestinationLabel(d, currentWorld))
            Next
            names.Sort()
            Console(session, 70, 180, 220, "KNOWN TARDIS DESTINATIONS: " & String.Join(", ", names.ToArray()))
        End Sub

        Private Function DestinationLabel(d As TardisDestination, currentWorld As String) As String
            Dim w As String = If(String.IsNullOrWhiteSpace(d.WorldName), currentWorld, d.WorldName)
            Return d.Name & " [" & w & "]"
        End Function

        Private Sub Console(session As Integer, red As Integer, green As Integer, blue As Integer, message As String)
            If session <= 0 OrElse _sdk Is Nothing Then Return
            While message.Length > 0
                _sdk.SetInt(Attributes.ConsoleRed, red)
                _sdk.SetInt(Attributes.ConsoleGreen, green)
                _sdk.SetInt(Attributes.ConsoleBlue, blue)
                _sdk.SetBool(Attributes.ConsoleBold, False)
                _sdk.SetBool(Attributes.ConsoleItalics, False)
                Dim part As String = If(message.Length > 255, message.Substring(0, 255), message)
                _sdk.SetString(Attributes.ConsoleMessage, part)
                _sdk.ConsoleMessage(session)
                message = If(message.Length > 255, message.Substring(255), "")
            End While
        End Sub

        Private Function GetParam(action As String, key As String) As String
            If action Is Nothing Then Return ""
            Dim lower As String = action.ToLowerInvariant()
            Dim markers() As String = {key.ToLowerInvariant() & ":", key.ToLowerInvariant() & "="}
            For Each marker As String In markers
                Dim p As Integer = lower.IndexOf(marker, StringComparison.Ordinal)
                If p >= 0 Then
                    p += marker.Length
                    Dim q As Integer = action.IndexOf(","c, p)
                    If q < 0 Then q = action.Length
                    Return action.Substring(p, q - p).Trim().Trim("'"c, ChrW(34))
                End If
            Next
            Return ""
        End Function

        Private Function ParseInt(value As String, fallback As Integer) As Integer
            Dim n As Integer
            If Integer.TryParse(value.Trim(), n) Then Return n
            Return fallback
        End Function

        Private Sub LoadProfiles()
            Try
                If Not File.Exists(_profilesPath) Then Return
                Dim ser As New XmlSerializer(GetType(List(Of PlayerProfile)))
                Using fs As FileStream = File.OpenRead(_profilesPath)
                    Dim list As List(Of PlayerProfile) = DirectCast(ser.Deserialize(fs), List(Of PlayerProfile))
                    For Each p As PlayerProfile In list
                        If Not String.IsNullOrWhiteSpace(p.Name) Then _profiles(p.Name) = p
                    Next
                End Using
            Catch ex As Exception
                _log("Profile load warning: " & ex.Message)
            End Try
        End Sub

        Private Sub SaveProfiles(Optional force As Boolean = False)
            _profilesDirty = True
            Dim now As DateTime = DateTime.UtcNow
            If Not force AndAlso (now - _lastProfileWriteUtc).TotalSeconds < ProfileSaveDebounceSeconds Then Return

            Try
                Dim ser As New XmlSerializer(GetType(List(Of PlayerProfile)))
                Dim tempPath As String = _profilesPath & ".tmp"
                Using fs As FileStream = File.Create(tempPath)
                    ser.Serialize(fs, New List(Of PlayerProfile)(_profiles.Values))
                End Using

                ' Write via a temporary file so a crash during serialization is much
                ' less likely to leave the player's main profile file truncated.
                If File.Exists(_profilesPath) Then File.Delete(_profilesPath)
                File.Move(tempPath, _profilesPath)
                _profilesDirty = False
                _lastProfileWriteUtc = now
            Catch ex As Exception
                _log("Profile save warning: " & ex.Message)
            End Try
        End Sub
    End Class

    Public Class TardisDestination
        Public Property Name As String = ""
        Public Property WorldName As String = ""
        Public Property X As Integer
        Public Property Y As Integer
        Public Property Z As Integer
        Public Property Yaw As Integer
        Public Property ArtronCost As Integer = 10
        Public Property Aliases As String = ""
        Public Property NavigationDifficulty As Integer = 35
    End Class

    Public Class TardisFlightState
        Public Property CoordinatesReady As Boolean
        Public Property HelmicReady As Boolean
        Public Property ArtronReady As Boolean
        Public Property AnchorReady As Boolean
        Public Property LifeSupportReady As Boolean
        Public Property DestinationKey As String = "Unspecified"
        Public Property ArtronCharge As Integer
        Public Property LastControl As String = ""
        Public Property LandingMode As String = "sealed"
        Public Property HandbrakeOn As Boolean = True
        Public Property HADSArmed As Boolean
        Public Property CloisterBellActive As Boolean
        Public Property EmergencyReason As String = ""
    End Class

    Public Class PlayerProfile
        Public Property Name As String = ""
        Public Property IsTimeLord As Boolean
        Public Property IsDead As Boolean
        Public Property Incarnation As Integer = 1
        Public Property RegenerationsRemaining As Integer = 12
        Public Property RegenerationBlocked As Boolean
        Public Property Health As Integer = 100
        Public Property MaxHealth As Integer = 100
        Public Property ArtronReserve As Integer = 100
        Public Property MaxArtronReserve As Integer = 250

        ' Kept for backward compatibility with profiles created by the first standalone build.
        ' The real RPG now stores Piloting in Skills.
        Public Property PilotingSkill As Integer = 50

        Public Property Skills As New List(Of SkillProgress)()
        Public Property StatusEffects As New List(Of ActiveStatus)()
        Public Property IncarnationHistory As New List(Of IncarnationRecord)()

        Public Property TardisHull As Integer = 100
        Public Property TardisTemporalIntegrity As Integer = 100
        Public Property TardisPower As Integer = 100

        ' V3 RPG state
        Public Property HeartOneHealth As Integer = 100
        Public Property HeartTwoHealth As Integer = 100
        Public Property HudEnabled As Boolean = False
        Public Property SonicMode As String = "scan"
        Public Property IncarnationTraits As New List(Of String)()
        Public Property Discoveries As New List(Of DiscoveryRecord)()
        Public Property TravelLog As New List(Of TravelRecord)()
        Public Property Missions As New List(Of MissionProgress)()
        Public Property Factions As New List(Of FactionStanding)()
        Public Property Achievements As New List(Of String)()
        Public Property FlightsCompleted As Integer = 0
        Public Property PerfectLandings As Integer = 0
        Public Property EnemiesDefeated As Integer = 0
        Public Property MissionsCompleted As Integer = 0
        Public Property LivesSaved As Integer = 0

        ' V4 complete-RPG state
        Public Property Species As String = ""
        Public Property AcademyCredits As Integer = 0
        Public Property AcademyRank As String = "Initiate"
        Public Property Title As String = "Initiate"
        Public Property Inventory As New List(Of InventoryItem)()
        Public Property Companions As New List(Of CompanionRecord)()
        Public Property ParadoxLevel As Integer = 0
        Public Property TardisRooms As New List(Of String)()
        Public Property StoryFlags As New List(Of String)()
        Public Property SpeciesCatalog As New List(Of String)()
        Public Property SonicOwned As Boolean = True
        Public Property SonicName As String = "Sonic Screwdriver"
        Public Property SonicUpgradeLevel As Integer = 1
        Public Property SonicCasing As String = "silver"
        Public Property SonicEmitter As String = "standard"
        Public Property SonicCrystal As String = "artron"

        Public Property InteriorWorld As String = ""
        Public Property InteriorX As Integer
        Public Property InteriorY As Integer
        Public Property InteriorZ As Integer
        Public Property InteriorYaw As Integer

        Public Function HasInteriorAnchor() As Boolean
            Return Not String.IsNullOrWhiteSpace(InteriorWorld) OrElse InteriorX <> 0 OrElse InteriorY <> 0 OrElse InteriorZ <> 0
        End Function
    End Class
End Namespace
