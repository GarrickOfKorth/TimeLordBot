Imports System
Imports System.Collections.Generic
Imports System.Xml.Serialization

Namespace TimeLordBot

    Public Class SkillProgress
        Public Property Name As String = ""
        Public Property Value As Double = 10.0
        Public Property Uses As Integer = 0
        Public Property SuccessfulChecks As Integer = 0
    End Class

    Public Class ActiveStatus
        Public Property Name As String = ""
        Public Property Potency As Integer = 1
        Public Property ExpiresUtc As DateTime = DateTime.UtcNow
        Public Property NextTickUtc As DateTime = DateTime.UtcNow
        Public Property Source As String = ""
    End Class

    Public Class IncarnationRecord
        Public Property Number As Integer
        Public Property StartedUtc As DateTime = DateTime.UtcNow
        Public Property EndedUtc As DateTime = DateTime.MinValue
        Public Property Cause As String = ""
    End Class

    Public Class SkillCheckResult
        Public Property Success As Boolean
        Public Property CriticalSuccess As Boolean
        Public Property CriticalFailure As Boolean
        Public Property Roll As Integer
        Public Property Target As Integer
        Public Property SkillValue As Double
        Public Property Gain As Double
    End Class

    Public Module RpgRules
        Public ReadOnly SkillNames As String() = {
            "Piloting", "Navigation", "Engineering", "Temporal Science", "Medicine",
            "Sonic Technology", "Psychic", "Diplomacy", "Investigation", "Combat",
            "Stealth", "Archaeology", "Xenobiology"
        }

        Public Function NormalizeSkillName(value As String) As String
            If value Is Nothing Then Return ""
            Dim raw As String = value.Trim().Replace("_", " ")
            For Each skill As String In SkillNames
                If String.Equals(skill, raw, StringComparison.OrdinalIgnoreCase) Then Return skill
                If String.Equals(skill.Replace(" ", ""), raw.Replace(" ", ""), StringComparison.OrdinalIgnoreCase) Then Return skill
            Next
            Return ""
        End Function

        Public Function Clamp(value As Integer, minimum As Integer, maximum As Integer) As Integer
            Return Math.Max(minimum, Math.Min(maximum, value))
        End Function

        Public Function Clamp(value As Double, minimum As Double, maximum As Double) As Double
            Return Math.Max(minimum, Math.Min(maximum, value))
        End Function
    End Module

End Namespace
