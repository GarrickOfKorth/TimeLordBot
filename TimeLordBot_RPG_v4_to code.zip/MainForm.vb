﻿Imports System
Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.Windows.Forms
Imports AW

Namespace TimeLordBot
    Partial Public Class MainForm
        Private _bot As TardisBot
        Private _connectedSinceUtc As DateTime = DateTime.MinValue
        Private _nextOperatorRefreshUtc As DateTime = DateTime.MinValue

        Private GmTabs As TabControl
        Private GridDestinations As DataGridView
        Private GridConversation As DataGridView
        Private GridZones As DataGridView
        Private GridAvatars As DataGridView
        Private GridProfileEditor As DataGridView
        Private GridEnemies As DataGridView
        Private CmbProfileEditor As ComboBox
        Private CmbGmTarget As ComboBox
        Private CmbGmPreset As ComboBox
        Private TxtGmAction As TextBox
        Private LblGmResult As Label
        Private TxtConversationTest As TextBox
        Private TxtConversationZone As TextBox
        Private TxtConversationResult As TextBox
        Private CmbRawFile As ComboBox
        Private TxtRawEditor As TextBox

        Public Sub New()
            InitializeComponent()
            _bot = New TardisBot(AddressOf Log)
            EventTimer.Enabled = True
            UpdateOperatorUi(True)
            InitializeGameMasterWorkspace()
        End Sub

        Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
            If _bot IsNot Nothing AndAlso _bot.Connected Then
                _bot.Disconnect()
                _connectedSinceUtc = DateTime.MinValue
                BtnLogin.Text = "Connect"
                SetConnectionFieldsEnabled(True)
                Log("Disconnected.")
                UpdateOperatorUi(True)
                Return
            End If

            Dim citizen As Integer
            If Not Integer.TryParse(TxtCitizen.Text.Trim(), citizen) Then
                MessageBox.Show("Enter a valid citizen number.")
                Return
            End If

            Dim authPort As Integer
            If Not Integer.TryParse(TxtAuthPort.Text.Trim(), authPort) OrElse authPort <= 0 OrElse authPort > 65535 Then
                MessageBox.Show("Enter a valid authentication server port.")
                Return
            End If

            If TxtPrivilegePassword.Text = "" OrElse TxtBotName.Text.Trim() = "" OrElse CmbWorld.Text.Trim() = "" OrElse TxtAuthHost.Text.Trim() = "" Then
                MessageBox.Show("Citizen number, privilege password, bot name, home world, and authentication server are required.")
                Return
            End If

            Try
                _bot.Connect(citizen, TxtPrivilegePassword.Text, TxtBotName.Text.Trim(), CmbWorld.Text.Trim(), TxtAuthHost.Text.Trim(), authPort)
                _connectedSinceUtc = DateTime.UtcNow
                BtnLogin.Text = "Disconnect"
                SetConnectionFieldsEnabled(False)
                UpdateOperatorUi(True)
            Catch ex As Exception
                Log("CONNECT ERROR: " & ex.Message)
                SetConnectionFieldsEnabled(True)
            End Try
        End Sub

        Private Sub SetConnectionFieldsEnabled(enabled As Boolean)
            TxtCitizen.Enabled = enabled
            TxtPrivilegePassword.Enabled = enabled
            TxtBotName.Enabled = enabled
            CmbWorld.Enabled = enabled
            TxtAuthHost.Enabled = enabled
            TxtAuthPort.Enabled = enabled
        End Sub

        Private Sub EventTimer_Tick(sender As Object, e As EventArgs) Handles EventTimer.Tick
            Try
                If _bot IsNot Nothing AndAlso _bot.Connected Then
                    AW.Utility.Wait(0)
                    _bot.Tick()
                End If

                If DateTime.UtcNow >= _nextOperatorRefreshUtc Then
                    _nextOperatorRefreshUtc = DateTime.UtcNow.AddSeconds(1)
                    UpdateOperatorUi(False)
                End If
            Catch ex As Exception
                Log("EVENT ERROR: " & ex.Message)
            End Try
        End Sub

        Private Sub UpdateOperatorUi(refreshProfiles As Boolean)
            If _bot Is Nothing Then Return

            LblConnectionValue.Text = If(_bot.Connected, "CONNECTED", "OFFLINE")
            LblWorldValue.Text = If(String.IsNullOrWhiteSpace(_bot.OperatorHomeWorld), CmbWorld.Text.Trim(), _bot.OperatorHomeWorld)
            LblOnlineValue.Text = _bot.OnlinePlayerCount.ToString()
            LblProfilesValue.Text = _bot.StoredProfileCount.ToString()
            LblDestinationsValue.Text = _bot.DestinationCount.ToString()
            LblFlightsValue.Text = _bot.ActiveFlightCount.ToString()
            LblSaveValue.Text = If(_bot.ProfilesHavePendingSave, "Pending", "Saved")

            If _bot.Connected AndAlso _connectedSinceUtc <> DateTime.MinValue Then
                Dim span As TimeSpan = DateTime.UtcNow - _connectedSinceUtc
                LblUptimeValue.Text = String.Format("{0:00}:{1:00}:{2:00}", CInt(Math.Floor(span.TotalHours)), span.Minutes, span.Seconds)
            Else
                LblUptimeValue.Text = "--:--:--"
            End If

            Dim expectedProfileCount As Integer = If(ChkOnlineOnly.Checked, _bot.OnlinePlayerCount, _bot.StoredProfileCount)
            If refreshProfiles OrElse CmbProfile.Items.Count <> expectedProfileCount Then RefreshProfileList()

            Dim selected As String = TryCast(CmbProfile.SelectedItem, String)
            If CmbGmTarget IsNot Nothing AndAlso refreshProfiles Then RefreshGmTargets()
            If CmbProfileEditor IsNot Nothing AndAlso refreshProfiles Then RefreshProfileEditorList()

            If selected IsNot Nothing AndAlso selected <> "" Then
                TxtProfileSummary.Text = _bot.GetProfileSummary(selected)
            ElseIf CmbProfile.Text.Trim() <> "" Then
                TxtProfileSummary.Text = _bot.GetProfileSummary(CmbProfile.Text.Trim())
            End If
        End Sub

        Private Sub RefreshProfileList()
            If _bot Is Nothing Then Return
            Dim selected As String = CmbProfile.Text
            Dim names As List(Of String) = _bot.GetProfileNames(ChkOnlineOnly.Checked)

            CmbProfile.BeginUpdate()
            Try
                CmbProfile.Items.Clear()
                For Each name As String In names
                    CmbProfile.Items.Add(name)
                Next
            Finally
                CmbProfile.EndUpdate()
            End Try

            If selected <> "" AndAlso CmbProfile.Items.Contains(selected) Then
                CmbProfile.SelectedItem = selected
            ElseIf CmbProfile.Items.Count > 0 Then
                CmbProfile.SelectedIndex = 0
            Else
                TxtProfileSummary.Text = "No matching Time Lord profiles."
            End If
        End Sub

        Private Sub CmbProfile_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbProfile.SelectedIndexChanged
            If _bot Is Nothing Then Return
            Dim name As String = CmbProfile.Text.Trim()
            If name <> "" Then TxtProfileSummary.Text = _bot.GetProfileSummary(name)
        End Sub

        Private Sub ChkOnlineOnly_CheckedChanged(sender As Object, e As EventArgs) Handles ChkOnlineOnly.CheckedChanged
            RefreshProfileList()
        End Sub

        Private Sub BtnRefreshProfile_Click(sender As Object, e As EventArgs) Handles BtnRefreshProfile.Click
            UpdateOperatorUi(True)
        End Sub

        Private Sub BtnSaveNow_Click(sender As Object, e As EventArgs) Handles BtnSaveNow.Click
            If _bot Is Nothing Then Return
            _bot.ForceSaveProfilesForOperator()
            Log("Profiles saved by operator.")
            UpdateOperatorUi(False)
        End Sub

        Private Sub BtnReloadDestinations_Click(sender As Object, e As EventArgs) Handles BtnReloadDestinations.Click
            If _bot Is Nothing Then Return
            Dim count As Integer = _bot.ReloadDestinationsForOperator()
            Log("Reloaded TARDIS destinations: " & count.ToString() & " unique destinations.")
            UpdateOperatorUi(False)
        End Sub

        Private Sub BtnOpenDataFolder_Click(sender As Object, e As EventArgs) Handles BtnOpenDataFolder.Click
            If _bot Is Nothing Then Return
            Try
                Process.Start("explorer.exe", _bot.GetDataFolder())
            Catch ex As Exception
                Log("OPEN FOLDER ERROR: " & ex.Message)
            End Try
        End Sub

        Private Sub BtnClearLog_Click(sender As Object, e As EventArgs) Handles BtnClearLog.Click
            TxtLog.Clear()
        End Sub

        Private Sub BtnCopyProfile_Click(sender As Object, e As EventArgs) Handles BtnCopyProfile.Click
            If TxtProfileSummary.TextLength = 0 Then Return
            Try
                Clipboard.SetText(TxtProfileSummary.Text)
            Catch ex As Exception
                Log("COPY ERROR: " & ex.Message)
            End Try
        End Sub


        Private Sub InitializeGameMasterWorkspace()
            Me.ClientSize = New Drawing.Size(1100, 820)
            Me.MinimumSize = New Drawing.Size(1000, 760)

            GmTabs = New TabControl()
            GmTabs.Location = New Drawing.Point(12, 238)
            GmTabs.Size = New Drawing.Size(1076, 570)
            GmTabs.Anchor = CType(AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right, AnchorStyles)
            Me.Controls.Add(GmTabs)

            Dim overview As New TabPage("Overview")
            Dim destinations As New TabPage("Destinations")
            Dim conversation As New TabPage("Conversation")
            Dim zones As New TabPage("Zones")
            Dim avatars As New TabPage("Avatars")
            Dim profileEdit As New TabPage("Profile Editor")
            Dim enemies As New TabPage("Enemies")
            Dim gm As New TabPage("GM Action")
            Dim raw As New TabPage("Raw Files")
            GmTabs.TabPages.Add(overview)
            GmTabs.TabPages.Add(destinations)
            GmTabs.TabPages.Add(conversation)
            GmTabs.TabPages.Add(zones)
            GmTabs.TabPages.Add(avatars)
            GmTabs.TabPages.Add(profileEdit)
            GmTabs.TabPages.Add(enemies)
            GmTabs.TabPages.Add(gm)
            GmTabs.TabPages.Add(raw)

            overview.Controls.Add(GrpProfile)
            overview.Controls.Add(GrpLog)
            GrpLog.Text = "Live Bot / Gameplay / Trigger Event Log"
            GrpProfile.Location = New Drawing.Point(8, 8)
            GrpProfile.Size = New Drawing.Size(1048, 230)
            TxtProfileSummary.Size = New Drawing.Size(1014, 150)
            GrpLog.Location = New Drawing.Point(8, 246)
            GrpLog.Size = New Drawing.Size(1048, 282)
            TxtLog.Size = New Drawing.Size(1014, 210)
            BtnClearLog.Location = New Drawing.Point(930, 19)

            GridDestinations = CreateGrid(New String() {"Name", "World", "X", "Y", "Z", "Yaw", "Artron Cost", "Aliases", "Nav Difficulty"})
            AddEditorTab(destinations, GridDestinations, "TardisDestinations.txt", AddressOf SaveDestinationsGrid, AddressOf LoadDestinationsGrid)

            GridConversation = CreateGrid(New String() {"ID", "Mode", "Pattern", "Zone", "Required Flag", "Response", "Action"})
            AddEditorTab(conversation, GridConversation, "ConversationTriggers.txt", AddressOf SaveConversationGrid, AddressOf LoadConversationGrid)
            AddConversationTester(conversation)

            GridZones = CreateGrid(New String() {"Zone", "Event", "Response", "Action"})
            AddEditorTab(zones, GridZones, "ZoneTriggers.txt", AddressOf SaveZoneGrid, AddressOf LoadZoneGrid)

            GridAvatars = CreateGrid(New String() {"Event", "Target", "Response", "Action"})
            AddEditorTab(avatars, GridAvatars, "AvatarTriggers.txt", AddressOf SaveAvatarGrid, AddressOf LoadAvatarGrid)

            BuildProfileEditorTab(profileEdit)
            BuildEnemyEditorTab(enemies)
            BuildGmActionTab(gm)
            BuildRawEditorTab(raw)

            LoadDestinationsGrid()
            LoadConversationGrid()
            LoadZoneGrid()
            LoadAvatarGrid()
            RefreshGmTargets()
        End Sub

        Private Function CreateGrid(columns As String()) As DataGridView
            Dim grid As New DataGridView()
            grid.AllowUserToAddRows = True
            grid.AllowUserToDeleteRows = True

            ' Live GM tables can contain long responses/actions.  Do not squeeze every
            ' column into the visible width: keep useful column widths and let the
            ' operator scroll horizontally to the hidden fields.
            grid.ScrollBars = ScrollBars.Both
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
            grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            grid.DefaultCellStyle.WrapMode = DataGridViewTriState.False
            grid.AllowUserToResizeColumns = True
            grid.AllowUserToResizeRows = False

            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
            grid.MultiSelect = False
            grid.RowHeadersVisible = False
            grid.Anchor = CType(AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right, AnchorStyles)

            Dim columnName As String
            For Each columnName In columns
                Dim columnIndex As Integer = grid.Columns.Add(columnName.Replace(" ", ""), columnName)
                grid.Columns(columnIndex).Width = RecommendedGridColumnWidth(columnName)
                grid.Columns(columnIndex).MinimumWidth = 55
            Next

            Return grid
        End Function

        Private Function RecommendedGridColumnWidth(headerText As String) As Integer
            Select Case headerText.Trim().ToLowerInvariant()
                Case "id", "key"
                    Return 145
                Case "mode", "event"
                    Return 90
                Case "pattern"
                    Return 240
                Case "zone", "world", "target", "species", "damage type", "defeated by"
                    Return 175
                Case "required flag"
                    Return 180
                Case "response"
                    Return 380
                Case "action"
                    Return 500
                Case "name", "aliases"
                    Return 190
                Case "nav difficulty", "artron cost", "attack difficulty"
                    Return 115
                Case "defeated"
                    Return 90
                Case "health", "max health", "defense", "attack", "x", "y", "z", "yaw"
                    Return 85
                Case Else
                    Return 130
            End Select
        End Function

        Private Sub AddEditorTab(tab As TabPage, grid As DataGridView, fileName As String, saveHandler As EventHandler, reloadHandler As EventHandler)
            grid.Location = New Drawing.Point(8, 42)
            grid.Size = New Drawing.Size(1044, 480)
            tab.Controls.Add(grid)

            Dim lbl As New Label()
            lbl.Text = fileName & " — edit live game data, then Save + Reload."
            lbl.AutoSize = True
            lbl.Location = New Drawing.Point(8, 14)
            tab.Controls.Add(lbl)

            Dim btnAdd As New Button()
            btnAdd.Text = "Add Row"
            btnAdd.Location = New Drawing.Point(474, 8)
            btnAdd.Size = New Drawing.Size(90, 27)
            AddHandler btnAdd.Click, Sub(o As Object, e As EventArgs) grid.Rows.Add()
            tab.Controls.Add(btnAdd)

            Dim btnDuplicate As New Button()
            btnDuplicate.Text = "Duplicate"
            btnDuplicate.Location = New Drawing.Point(570, 8)
            btnDuplicate.Size = New Drawing.Size(90, 27)
            AddHandler btnDuplicate.Click, Sub(o As Object, e As EventArgs) DuplicateSelectedGridRow(grid)
            tab.Controls.Add(btnDuplicate)

            Dim btnDelete As New Button()
            btnDelete.Text = "Delete Row"
            btnDelete.Location = New Drawing.Point(666, 8)
            btnDelete.Size = New Drawing.Size(90, 27)
            AddHandler btnDelete.Click, Sub(o As Object, e As EventArgs) DeleteSelectedGridRow(grid)
            tab.Controls.Add(btnDelete)

            Dim btnReload As New Button()
            btnReload.Text = "Revert / Reload"
            btnReload.Location = New Drawing.Point(762, 8)
            btnReload.Size = New Drawing.Size(110, 27)
            AddHandler btnReload.Click, reloadHandler
            tab.Controls.Add(btnReload)

            Dim btnSave As New Button()
            btnSave.Text = "Save + Reload"
            btnSave.Location = New Drawing.Point(878, 8)
            btnSave.Size = New Drawing.Size(120, 27)
            AddHandler btnSave.Click, saveHandler
            tab.Controls.Add(btnSave)
        End Sub

        Private Sub DeleteSelectedGridRow(grid As DataGridView)
            If grid Is Nothing OrElse grid.CurrentRow Is Nothing OrElse grid.CurrentRow.IsNewRow Then Return
            grid.Rows.Remove(grid.CurrentRow)
        End Sub

        Private Sub DuplicateSelectedGridRow(grid As DataGridView)
            If grid Is Nothing OrElse grid.CurrentRow Is Nothing OrElse grid.CurrentRow.IsNewRow Then Return
            Dim values(grid.Columns.Count - 1) As Object
            Dim i As Integer
            For i = 0 To grid.Columns.Count - 1
                values(i) = grid.CurrentRow.Cells(i).Value
            Next
            grid.Rows.Add(values)
        End Sub

        Private Sub LoadPipeFileIntoGrid(fileName As String, grid As DataGridView, expectedColumns As Integer)
            If _bot Is Nothing Then Return
            grid.Rows.Clear()
            Dim text As String = _bot.ReadOperatorDataFile(fileName)
            Dim rawLines() As String = text.Replace(vbCrLf, vbLf).Split(ControlChars.Lf)
            Dim raw As String
            For Each raw In rawLines
                Dim line As String = raw.Trim()
                If line = "" OrElse line.StartsWith("#") Then Continue For
                Dim fields() As String = line.Split("|"c)
                If fields.Length < expectedColumns Then Continue For
                Dim values(expectedColumns - 1) As Object
                Dim i As Integer
                For i = 0 To expectedColumns - 1
                    values(i) = fields(i).Trim()
                Next
                grid.Rows.Add(values)
            Next
        End Sub

        Private Function GridToPipeText(grid As DataGridView, headerLines As String()) As String
            Dim lines As New List(Of String)()
            Dim header As String
            For Each header In headerLines
                lines.Add(header)
            Next
            Dim row As DataGridViewRow
            For Each row In grid.Rows
                If row.IsNewRow Then Continue For
                Dim parts As New List(Of String)()
                Dim i As Integer
                For i = 0 To grid.Columns.Count - 1
                    Dim value As String = ""
                    If row.Cells(i).Value IsNot Nothing Then value = row.Cells(i).Value.ToString().Trim()
                    If value.Contains("|") OrElse value.Contains(vbCr) OrElse value.Contains(vbLf) Then
                        Throw New InvalidOperationException("Cells cannot contain | or line breaks. Row " & (row.Index + 1).ToString() & ".")
                    End If
                    parts.Add(value)
                Next
                If String.Join("", parts.ToArray()).Trim() <> "" Then lines.Add(String.Join("|", parts.ToArray()))
            Next
            Return String.Join(Environment.NewLine, lines.ToArray()) & Environment.NewLine
        End Function

        Private Sub LoadDestinationsGrid()
            LoadPipeFileIntoGrid("TardisDestinations.txt", GridDestinations, 9)
        End Sub

        Private Sub LoadDestinationsGrid(sender As Object, e As EventArgs)
            LoadDestinationsGrid()
        End Sub

        Private Sub SaveDestinationsGrid(sender As Object, e As EventArgs)
            Try
                ValidateDestinationGrid()
                Dim headers As String() = {"# TARDIS NAVIGATION DATABASE", "# Name|World|X|Y|Z|Yaw|ArtronCost|aliases|NavigationDifficulty"}
                _bot.WriteOperatorDataFile("TardisDestinations.txt", GridToPipeText(GridDestinations, headers))
                Dim count As Integer = _bot.ReloadDestinationsForOperator()
                Log("GM saved destinations. Loaded " & count.ToString() & " unique destinations.")
                UpdateOperatorUi(False)
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Destination validation")
            End Try
        End Sub

        Private Sub ValidateDestinationGrid()
            Dim row As DataGridViewRow
            For Each row In GridDestinations.Rows
                If row.IsNewRow Then Continue For
                Dim name As String = CellText(row, 0)
                If name = "" Then Continue For
                Dim i As Integer
                For i = 2 To 6
                    Dim n As Integer
                    If Not Integer.TryParse(CellText(row, i), n) Then Throw New InvalidOperationException("Destination '" & name & "' has an invalid numeric value in column " & GridDestinations.Columns(i).HeaderText & ".")
                Next
                Dim difficulty As Integer
                If Not Integer.TryParse(CellText(row, 8), difficulty) Then Throw New InvalidOperationException("Destination '" & name & "' has an invalid navigation difficulty.")
            Next
        End Sub

        Private Function CellText(row As DataGridViewRow, index As Integer) As String
            If row.Cells(index).Value Is Nothing Then Return ""
            Return row.Cells(index).Value.ToString().Trim()
        End Function

        Private Sub LoadConversationGrid()
            LoadPipeFileIntoGrid("ConversationTriggers.txt", GridConversation, 7)
        End Sub

        Private Sub LoadConversationGrid(sender As Object, e As EventArgs)
            LoadConversationGrid()
        End Sub

        Private Sub SaveConversationGrid(sender As Object, e As EventArgs)
            Try
                ValidateConversationGrid()
                Dim headers As String() = {"# TimeLordBot conversational dialogue triggers", "# id|mode|pattern|zone|requireflag|response|action", "# mode = exact | contains | starts"}
                _bot.WriteOperatorDataFile("ConversationTriggers.txt", GridToPipeText(GridConversation, headers))
                Log("GM saved conversation triggers. " & _bot.ReloadInteractionsForOperator())
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Conversation validation")
            End Try
        End Sub

        Private Sub ValidateConversationGrid()
            Dim row As DataGridViewRow
            For Each row In GridConversation.Rows
                If row.IsNewRow Then Continue For
                If CellText(row, 0) = "" AndAlso CellText(row, 2) = "" Then Continue For
                If CellText(row, 0) = "" OrElse CellText(row, 2) = "" Then Throw New InvalidOperationException("Conversation rows require both ID and Pattern.")
                Dim mode As String = CellText(row, 1).ToLowerInvariant()
                If mode <> "exact" AndAlso mode <> "contains" AndAlso mode <> "starts" AndAlso mode <> "startswith" Then Throw New InvalidOperationException("Conversation mode must be exact, contains, or starts.")
            Next
        End Sub

        Private Sub LoadZoneGrid()
            LoadPipeFileIntoGrid("ZoneTriggers.txt", GridZones, 4)
        End Sub

        Private Sub LoadZoneGrid(sender As Object, e As EventArgs)
            LoadZoneGrid()
        End Sub

        Private Sub SaveZoneGrid(sender As Object, e As EventArgs)
            Try
                ValidateSimpleEventGrid(GridZones, 0, 1, "zone", New String() {"enter", "exit"})
                Dim headers As String() = {"# TimeLordBot zone enter/exit triggers", "# zone|event|response|action"}
                _bot.WriteOperatorDataFile("ZoneTriggers.txt", GridToPipeText(GridZones, headers))
                Log("GM saved zone triggers. " & _bot.ReloadInteractionsForOperator())
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Zone validation")
            End Try
        End Sub

        Private Sub LoadAvatarGrid()
            LoadPipeFileIntoGrid("AvatarTriggers.txt", GridAvatars, 4)
        End Sub

        Private Sub LoadAvatarGrid(sender As Object, e As EventArgs)
            LoadAvatarGrid()
        End Sub

        Private Sub SaveAvatarGrid(sender As Object, e As EventArgs)
            Try
                ValidateSimpleEventGrid(GridAvatars, 1, 0, "avatar", New String() {"click", "bump"})
                Dim headers As String() = {"# TimeLordBot avatar interaction triggers", "# event|target|response|action"}
                _bot.WriteOperatorDataFile("AvatarTriggers.txt", GridToPipeText(GridAvatars, headers))
                Log("GM saved avatar triggers. " & _bot.ReloadInteractionsForOperator())
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Avatar validation")
            End Try
        End Sub

        Private Sub ValidateSimpleEventGrid(grid As DataGridView, requiredColumn As Integer, eventColumn As Integer, kind As String, allowedEvents As String())
            Dim row As DataGridViewRow
            For Each row In grid.Rows
                If row.IsNewRow Then Continue For
                Dim requiredValue As String = CellText(row, requiredColumn)
                Dim eventValue As String = CellText(row, eventColumn).ToLowerInvariant()
                If requiredValue = "" AndAlso eventValue = "" Then Continue For
                If requiredValue = "" Then Throw New InvalidOperationException("Each " & kind & " row needs " & grid.Columns(requiredColumn).HeaderText & ".")
                Dim okay As Boolean = False
                Dim allowed As String
                For Each allowed In allowedEvents
                    If eventValue = allowed Then okay = True
                Next
                If Not okay Then Throw New InvalidOperationException("Invalid " & kind & " event '" & eventValue & "'.")
            Next
        End Sub

        Private Sub AddConversationTester(tab As TabPage)
            GridConversation.Size = New Drawing.Size(1044, 374)
            Dim lbl As New Label()
            lbl.Text = "Test dialogue:"
            lbl.AutoSize = True
            lbl.Location = New Drawing.Point(8, 426)
            tab.Controls.Add(lbl)

            TxtConversationTest = New TextBox()
            TxtConversationTest.Location = New Drawing.Point(86, 422)
            TxtConversationTest.Size = New Drawing.Size(310, 22)
            tab.Controls.Add(TxtConversationTest)

            TxtConversationZone = New TextBox()
            TxtConversationZone.Location = New Drawing.Point(402, 422)
            TxtConversationZone.Size = New Drawing.Size(180, 22)
            tab.Controls.Add(TxtConversationZone)

            Dim btn As New Button()
            btn.Text = "Test Trigger"
            btn.Location = New Drawing.Point(590, 419)
            btn.Size = New Drawing.Size(100, 27)
            AddHandler btn.Click, AddressOf TestConversationTrigger
            tab.Controls.Add(btn)

            TxtConversationResult = New TextBox()
            TxtConversationResult.Location = New Drawing.Point(8, 452)
            TxtConversationResult.Size = New Drawing.Size(1044, 68)
            TxtConversationResult.Multiline = True
            TxtConversationResult.ReadOnly = True
            TxtConversationResult.ScrollBars = ScrollBars.Vertical
            tab.Controls.Add(TxtConversationResult)
        End Sub

        Private Sub TestConversationTrigger(sender As Object, e As EventArgs)
            Dim profile As String = CmbProfile.Text.Trim()
            TxtConversationResult.Text = _bot.TestConversationForOperator(TxtConversationTest.Text, TxtConversationZone.Text.Trim(), profile)
        End Sub


        Private Sub BuildProfileEditorTab(tab As TabPage)
            Dim lbl As New Label()
            lbl.Text = "Profile:"
            lbl.AutoSize = True
            lbl.Location = New Drawing.Point(8, 15)
            tab.Controls.Add(lbl)

            CmbProfileEditor = New ComboBox()
            CmbProfileEditor.DropDownStyle = ComboBoxStyle.DropDownList
            CmbProfileEditor.Location = New Drawing.Point(60, 11)
            CmbProfileEditor.Size = New Drawing.Size(240, 21)
            AddHandler CmbProfileEditor.SelectedIndexChanged, AddressOf LoadProfileEditor
            tab.Controls.Add(CmbProfileEditor)

            Dim btnRefresh As New Button()
            btnRefresh.Text = "Refresh Profiles"
            btnRefresh.Location = New Drawing.Point(312, 8)
            btnRefresh.Size = New Drawing.Size(110, 27)
            AddHandler btnRefresh.Click, Sub(o As Object, e As EventArgs) RefreshProfileEditorList()
            tab.Controls.Add(btnRefresh)

            Dim btnSave As New Button()
            btnSave.Text = "Save Profile"
            btnSave.Location = New Drawing.Point(430, 8)
            btnSave.Size = New Drawing.Size(110, 27)
            AddHandler btnSave.Click, AddressOf SaveProfileEditor
            tab.Controls.Add(btnSave)

            Dim note As New Label()
            note.Text = "Scalar persistent fields only; complex missions/items/flags should use GM actions or the XML backup."
            note.AutoSize = True
            note.Location = New Drawing.Point(560, 15)
            tab.Controls.Add(note)

            GridProfileEditor = New DataGridView()
            GridProfileEditor.Location = New Drawing.Point(8, 42)
            GridProfileEditor.Size = New Drawing.Size(1044, 480)
            GridProfileEditor.Anchor = CType(AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right, AnchorStyles)
            GridProfileEditor.AllowUserToAddRows = False
            GridProfileEditor.AllowUserToDeleteRows = False
            GridProfileEditor.RowHeadersVisible = False
            GridProfileEditor.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            GridProfileEditor.Columns.Add("Field", "Field")
            GridProfileEditor.Columns.Add("Value", "Value")
            GridProfileEditor.Columns(0).ReadOnly = True
            tab.Controls.Add(GridProfileEditor)
            RefreshProfileEditorList()
        End Sub

        Private Sub RefreshProfileEditorList()
            If CmbProfileEditor Is Nothing OrElse _bot Is Nothing Then Return
            Dim current As String = CmbProfileEditor.Text
            CmbProfileEditor.Items.Clear()
            Dim names As List(Of String) = _bot.GetProfileNames(False)
            Dim name As String
            For Each name In names
                CmbProfileEditor.Items.Add(name)
            Next
            If current <> "" AndAlso CmbProfileEditor.Items.Contains(current) Then
                CmbProfileEditor.SelectedItem = current
            ElseIf CmbProfileEditor.Items.Count > 0 Then
                CmbProfileEditor.SelectedIndex = 0
            End If
        End Sub

        Private Sub LoadProfileEditor(sender As Object, e As EventArgs)
            If GridProfileEditor Is Nothing OrElse _bot Is Nothing OrElse CmbProfileEditor.Text = "" Then Return
            GridProfileEditor.Rows.Clear()
            Dim values As Dictionary(Of String, String) = _bot.GetEditableProfileFields(CmbProfileEditor.Text)
            Dim kv As KeyValuePair(Of String, String)
            For Each kv In values
                GridProfileEditor.Rows.Add(kv.Key, kv.Value)
            Next
        End Sub

        Private Sub SaveProfileEditor(sender As Object, e As EventArgs)
            If _bot Is Nothing OrElse CmbProfileEditor.Text = "" Then Return
            Dim values As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
            Dim row As DataGridViewRow
            For Each row In GridProfileEditor.Rows
                If row.IsNewRow Then Continue For
                Dim key As String = CellText(row, 0)
                If key <> "" Then values(key) = CellText(row, 1)
            Next
            Dim result As String = _bot.UpdateEditableProfileFields(CmbProfileEditor.Text, values)
            Log("GM PROFILE EDIT: " & result)
            MessageBox.Show(result, "Profile Editor")
            UpdateOperatorUi(True)
            LoadProfileEditor(Nothing, EventArgs.Empty)
        End Sub

        Private Sub BuildEnemyEditorTab(tab As TabPage)
            GridEnemies = CreateGrid(New String() {"Key", "ID", "Name", "Species", "World", "Health", "Max Health", "Defense", "Attack", "Attack Difficulty", "Damage Type", "Defeated", "Defeated By"})
            GridEnemies.Location = New Drawing.Point(8, 42)
            GridEnemies.Size = New Drawing.Size(1044, 480)
            tab.Controls.Add(GridEnemies)

            Dim lbl As New Label()
            lbl.Text = "Persistent encounter states (EnemyStates.xml)"
            lbl.AutoSize = True
            lbl.Location = New Drawing.Point(8, 14)
            tab.Controls.Add(lbl)

            Dim btnAdd As New Button()
            btnAdd.Text = "Add Row"
            btnAdd.Location = New Drawing.Point(620, 8)
            btnAdd.Size = New Drawing.Size(90, 27)
            AddHandler btnAdd.Click, Sub(o As Object, e As EventArgs) GridEnemies.Rows.Add()
            tab.Controls.Add(btnAdd)

            Dim btnReload As New Button()
            btnReload.Text = "Reload"
            btnReload.Location = New Drawing.Point(716, 8)
            btnReload.Size = New Drawing.Size(90, 27)
            AddHandler btnReload.Click, AddressOf LoadEnemyEditor
            tab.Controls.Add(btnReload)

            Dim btnSave As New Button()
            btnSave.Text = "Save States"
            btnSave.Location = New Drawing.Point(812, 8)
            btnSave.Size = New Drawing.Size(100, 27)
            AddHandler btnSave.Click, AddressOf SaveEnemyEditor
            tab.Controls.Add(btnSave)

            Dim btnDelete As New Button()
            btnDelete.Text = "Delete"
            btnDelete.Location = New Drawing.Point(918, 8)
            btnDelete.Size = New Drawing.Size(90, 27)
            AddHandler btnDelete.Click, Sub(o As Object, e As EventArgs) DeleteSelectedGridRow(GridEnemies)
            tab.Controls.Add(btnDelete)
            LoadEnemyEditor(Nothing, EventArgs.Empty)
        End Sub

        Private Sub LoadEnemyEditor(sender As Object, e As EventArgs)
            If _bot Is Nothing OrElse GridEnemies Is Nothing Then Return
            GridEnemies.Rows.Clear()
            Dim rows As List(Of String()) = _bot.GetEnemyRowsForOperator()
            Dim fields As String()
            For Each fields In rows
                GridEnemies.Rows.Add(fields)
            Next
        End Sub

        Private Sub SaveEnemyEditor(sender As Object, e As EventArgs)
            If _bot Is Nothing Then Return
            Dim rows As New List(Of String())()
            Dim row As DataGridViewRow
            For Each row In GridEnemies.Rows
                If row.IsNewRow Then Continue For
                Dim values(GridEnemies.Columns.Count - 1) As String
                Dim i As Integer
                For i = 0 To GridEnemies.Columns.Count - 1
                    values(i) = CellText(row, i)
                Next
                If values(0) <> "" Then rows.Add(values)
            Next
            Dim result As String = _bot.SaveEnemyRowsForOperator(rows)
            Log("GM ENEMY EDIT: " & result)
            MessageBox.Show(result, "Enemy Editor")
            LoadEnemyEditor(Nothing, EventArgs.Empty)
        End Sub

        Private Sub BuildGmActionTab(tab As TabPage)
            Dim lblTarget As New Label()
            lblTarget.Text = "Target profile:"
            lblTarget.AutoSize = True
            lblTarget.Location = New Drawing.Point(16, 22)
            tab.Controls.Add(lblTarget)

            CmbGmTarget = New ComboBox()
            CmbGmTarget.DropDownStyle = ComboBoxStyle.DropDownList
            CmbGmTarget.Location = New Drawing.Point(110, 18)
            CmbGmTarget.Size = New Drawing.Size(220, 21)
            tab.Controls.Add(CmbGmTarget)

            Dim lblPreset As New Label()
            lblPreset.Text = "Preset:"
            lblPreset.AutoSize = True
            lblPreset.Location = New Drawing.Point(350, 22)
            tab.Controls.Add(lblPreset)

            CmbGmPreset = New ComboBox()
            CmbGmPreset.DropDownStyle = ComboBoxStyle.DropDownList
            CmbGmPreset.Location = New Drawing.Point(402, 18)
            CmbGmPreset.Size = New Drawing.Size(260, 21)
            CmbGmPreset.Items.AddRange(New Object() {"Heal 25", "Damage 10 physical", "Artron +25", "Paradox +10", "Paradox -10", "Medbay", "Show status", "Show skills"})
            AddHandler CmbGmPreset.SelectedIndexChanged, AddressOf GmPresetChanged
            tab.Controls.Add(CmbGmPreset)

            Dim btnRefresh As New Button()
            btnRefresh.Text = "Refresh Targets"
            btnRefresh.Location = New Drawing.Point(680, 15)
            btnRefresh.Size = New Drawing.Size(120, 27)
            AddHandler btnRefresh.Click, Sub(o As Object, e As EventArgs) RefreshGmTargets()
            tab.Controls.Add(btnRefresh)

            Dim lblAction As New Label()
            lblAction.Text = "Gameplay action:"
            lblAction.AutoSize = True
            lblAction.Location = New Drawing.Point(16, 68)
            tab.Controls.Add(lblAction)

            TxtGmAction = New TextBox()
            TxtGmAction.Location = New Drawing.Point(110, 64)
            TxtGmAction.Size = New Drawing.Size(690, 22)
            TxtGmAction.Text = "~rpg action:heal,amount:25"
            tab.Controls.Add(TxtGmAction)

            Dim btnExecute As New Button()
            btnExecute.Text = "Execute"
            btnExecute.Location = New Drawing.Point(812, 61)
            btnExecute.Size = New Drawing.Size(100, 27)
            AddHandler btnExecute.Click, AddressOf ExecuteGmAction
            tab.Controls.Add(btnExecute)

            Dim help As New TextBox()
            help.Multiline = True
            help.ReadOnly = True
            help.ScrollBars = ScrollBars.Vertical
            help.Font = New Drawing.Font("Consolas", 9.0!)
            help.Location = New Drawing.Point(16, 112)
            help.Size = New Drawing.Size(1018, 360)
            help.Text = "GM actions use the SAME gameplay dispatcher as world objects." & Environment.NewLine & Environment.NewLine &
                        "Examples:" & Environment.NewLine &
                        "~rpg action:heal,amount:25" & Environment.NewLine &
                        "~rpg action:damage,amount:10,damagetype:physical" & Environment.NewLine &
                        "~rpg action:artron,amount:25" & Environment.NewLine &
                        "~rpg action:paradox,amount:15,source:GM event" & Environment.NewLine &
                        "~rpg action:itemgive,id:matrix_key,name:Matrix Key,type:artifact,qty:1" & Environment.NewLine &
                        "~timelord type:status" & Environment.NewLine &
                        "~tardiscontrol type:status" & Environment.NewLine & Environment.NewLine &
                        "For safety, direct GM actions currently require the selected player to be ONLINE."
            tab.Controls.Add(help)

            LblGmResult = New Label()
            LblGmResult.AutoSize = True
            LblGmResult.Location = New Drawing.Point(16, 490)
            LblGmResult.Text = "Ready."
            tab.Controls.Add(LblGmResult)
        End Sub

        Private Sub RefreshGmTargets()
            If CmbGmTarget Is Nothing OrElse _bot Is Nothing Then Return
            Dim current As String = CmbGmTarget.Text
            Dim names As List(Of String) = _bot.GetProfileNames(False)
            CmbGmTarget.Items.Clear()
            Dim name As String
            For Each name In names
                CmbGmTarget.Items.Add(name)
            Next
            If current <> "" AndAlso CmbGmTarget.Items.Contains(current) Then
                CmbGmTarget.SelectedItem = current
            ElseIf CmbGmTarget.Items.Count > 0 Then
                CmbGmTarget.SelectedIndex = 0
            End If
        End Sub

        Private Sub GmPresetChanged(sender As Object, e As EventArgs)
            Select Case CmbGmPreset.Text
                Case "Heal 25" : TxtGmAction.Text = "~rpg action:heal,amount:25"
                Case "Damage 10 physical" : TxtGmAction.Text = "~rpg action:damage,amount:10,damagetype:physical"
                Case "Artron +25" : TxtGmAction.Text = "~rpg action:artron,amount:25"
                Case "Paradox +10" : TxtGmAction.Text = "~rpg action:paradox,amount:10,source:GM event"
                Case "Paradox -10" : TxtGmAction.Text = "~rpg action:paradox,amount:-10,source:GM stabilization"
                Case "Medbay" : TxtGmAction.Text = "~rpg action:medbay,difficulty:30"
                Case "Show status" : TxtGmAction.Text = "~timelord type:status"
                Case "Show skills" : TxtGmAction.Text = "~timelord type:skills"
            End Select
        End Sub

        Private Sub ExecuteGmAction(sender As Object, e As EventArgs)
            If _bot Is Nothing Then Return
            Dim result As String = _bot.ExecuteOperatorAction(CmbGmTarget.Text, TxtGmAction.Text)
            LblGmResult.Text = result
            Log(result)
            UpdateOperatorUi(True)
        End Sub

        Private Sub BuildRawEditorTab(tab As TabPage)
            CmbRawFile = New ComboBox()
            CmbRawFile.DropDownStyle = ComboBoxStyle.DropDownList
            CmbRawFile.Location = New Drawing.Point(8, 10)
            CmbRawFile.Size = New Drawing.Size(240, 21)
            CmbRawFile.Items.AddRange(New Object() {"TardisDestinations.txt", "ConversationTriggers.txt", "ZoneTriggers.txt", "AvatarTriggers.txt"})
            CmbRawFile.SelectedIndex = 0
            tab.Controls.Add(CmbRawFile)

            Dim btnLoad As New Button()
            btnLoad.Text = "Load"
            btnLoad.Location = New Drawing.Point(258, 7)
            btnLoad.Size = New Drawing.Size(80, 27)
            AddHandler btnLoad.Click, AddressOf LoadRawFile
            tab.Controls.Add(btnLoad)

            Dim btnSave As New Button()
            btnSave.Text = "Save + Reload"
            btnSave.Location = New Drawing.Point(344, 7)
            btnSave.Size = New Drawing.Size(120, 27)
            AddHandler btnSave.Click, AddressOf SaveRawFile
            tab.Controls.Add(btnSave)

            TxtRawEditor = New TextBox()
            TxtRawEditor.Multiline = True
            TxtRawEditor.AcceptsTab = True
            TxtRawEditor.ScrollBars = ScrollBars.Both
            TxtRawEditor.WordWrap = False
            TxtRawEditor.Font = New Drawing.Font("Consolas", 9.0!)
            TxtRawEditor.Location = New Drawing.Point(8, 42)
            TxtRawEditor.Size = New Drawing.Size(1044, 480)
            TxtRawEditor.Anchor = CType(AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right, AnchorStyles)
            tab.Controls.Add(TxtRawEditor)
            LoadRawFile(Nothing, EventArgs.Empty)
        End Sub

        Private Sub LoadRawFile(sender As Object, e As EventArgs)
            If _bot Is Nothing OrElse CmbRawFile Is Nothing Then Return
            TxtRawEditor.Text = _bot.ReadOperatorDataFile(CmbRawFile.Text)
        End Sub

        Private Sub SaveRawFile(sender As Object, e As EventArgs)
            If _bot Is Nothing Then Return
            Try
                _bot.WriteOperatorDataFile(CmbRawFile.Text, TxtRawEditor.Text)
                If String.Equals(CmbRawFile.Text, "TardisDestinations.txt", StringComparison.OrdinalIgnoreCase) Then
                    _bot.ReloadDestinationsForOperator()
                    LoadDestinationsGrid()
                Else
                    _bot.ReloadInteractionsForOperator()
                    If String.Equals(CmbRawFile.Text, "ConversationTriggers.txt", StringComparison.OrdinalIgnoreCase) Then LoadConversationGrid()
                    If String.Equals(CmbRawFile.Text, "ZoneTriggers.txt", StringComparison.OrdinalIgnoreCase) Then LoadZoneGrid()
                    If String.Equals(CmbRawFile.Text, "AvatarTriggers.txt", StringComparison.OrdinalIgnoreCase) Then LoadAvatarGrid()
                End If
                Log("GM saved raw file: " & CmbRawFile.Text)
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Raw editor")
            End Try
        End Sub

        Private Sub MainForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
            If _bot IsNot Nothing AndAlso _bot.Connected Then
                Try
                    _bot.Disconnect()
                Catch
                End Try
            End If
        End Sub

        Private Sub Log(message As String)
            If Me.InvokeRequired Then
                Me.BeginInvoke(New Action(Of String)(AddressOf Log), message)
                Return
            End If

            If TxtLog.TextLength > 250000 Then
                TxtLog.Select(0, Math.Min(75000, TxtLog.TextLength))
                TxtLog.SelectedText = ""
            End If

            TxtLog.AppendText("[" & DateTime.Now.ToString("HH:mm:ss") & "] " & message & Environment.NewLine)
            If ChkAutoScroll.Checked Then
                TxtLog.SelectionStart = TxtLog.TextLength
                TxtLog.ScrollToCaret()
            End If
        End Sub
    End Class
End Namespace
