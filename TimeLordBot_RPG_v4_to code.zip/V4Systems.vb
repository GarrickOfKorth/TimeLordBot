﻿Imports System
Imports System.Collections.Generic
Imports AW

Namespace TimeLordBot

    Public Class InventoryItem
        Public Property Id As String = ""
        Public Property Name As String = ""
        Public Property ItemType As String = "artifact"
        Public Property Quantity As Integer = 1
        Public Property Equipped As Boolean = False
        Public Property SkillBonus As String = ""
        Public Property BonusAmount As Double = 0
        Public Property Description As String = ""
    End Class

    Public Class CompanionRecord
        Public Property Id As String = ""
        Public Property Name As String = ""
        Public Property Species As String = "Human"
        Public Property Role As String = "Companion"
        Public Property Loyalty As Integer = 50
        Public Property Active As Boolean = False
        Public Property SkillBonus As String = "Investigation"
        Public Property BonusAmount As Double = 3
    End Class

    Public Partial Class TardisBot
        Private ReadOnly _lastParadoxHazardCheck As New Dictionary(Of Integer, DateTime)()
        Private Const ParadoxHazardCheckSeconds As Double = 10.0
        Private ReadOnly _academyRanks As String() = {"Initiate", "Novice", "Academy Graduate", "Time Lord", "Senior Time Lord", "Cardinal", "High Councillor"}
        Private ReadOnly _defaultTardisRooms As String() = {"Console Room", "Medical Bay", "Workshop", "Library", "Wardrobe", "Cloister Room", "Zero Room"}

        Private Function HandleV4TardisControl(session As Integer, sender As AW.Instance, action As String, controlType As String) As Boolean
            Dim p As PlayerProfile = _sessions(session)
            EnsureV4Profile(p)
            Select Case controlType.Trim().ToLowerInvariant()
                Case "rooms", "roomlist"
                    ShowTardisRooms(session, p)
                    Return True
                Case "room"
                    UseTardisRoom(session, p, GetParam(action, "name"), RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 40), 1, 100))
                    Return True
                Case "paradox"
                    ShowParadox(session, p)
                    Return True
                Case "stabilizeparadox"
                    StabilizeParadox(session, p)
                    Return True
                Case "adventure", "randomadventure"
                    GenerateProceduralAdventure(session, p, CurrentWorld(sender))
                    Return True
                Case "inventory"
                    ShowInventory(session, p)
                    Return True
                Case "companion"
                    ShowCompanions(session, p)
                    Return True
                Case "academy"
                    ShowAcademy(session, p)
                    Return True
            End Select
            Return False
        End Function

        Private Function HandleV4TimeLordControl(session As Integer, sender As AW.Instance, action As String, controlType As String) As Boolean
            Dim p As PlayerProfile = _sessions(session)
            EnsureV4Profile(p)
            Select Case controlType.Trim().ToLowerInvariant()
                Case "profile", "identity"
                    ShowV4Profile(session, p)
                    Return True
                Case "inventory", "items"
                    ShowInventory(session, p)
                    Return True
                Case "equip"
                    EquipItem(session, p, GetParam(action, "id"))
                    Return True
                Case "unequip"
                    UnequipItem(session, p, GetParam(action, "id"))
                    Return True
                Case "academy", "rank"
                    ShowAcademy(session, p)
                    Return True
                Case "title", "titles"
                    RefreshTitle(p)
                    Console(session, 210, 180, 95, "GALLIFREYAN TITLE | " & p.Title)
                    Return True
                Case "companion", "companions"
                    ShowCompanions(session, p)
                    Return True
                Case "paradox"
                    ShowParadox(session, p)
                    Return True
                Case "rooms"
                    ShowTardisRooms(session, p)
                    Return True
                Case "sonicprofile"
                    ShowSonicProfile(session, p)
                    Return True
            End Select
            Return False
        End Function

        Private Function HandleV4RpgAction(session As Integer, sender As AW.Instance, action As String, command As String) As Boolean
            Dim p As PlayerProfile = _sessions(session)
            EnsureV4Profile(p)
            Select Case command
                Case "itemgive", "loot"
                    GiveItem(session, p, action)
                    Return True
                Case "itemtake"
                    TakeItem(session, p, GetParam(action, "id"), Math.Max(1, ParseInt(GetParam(action, "amount"), 1)))
                    Return True
                Case "itemuse"
                    UseItem(session, p, GetParam(action, "id"))
                    Return True
                Case "equip"
                    EquipItem(session, p, GetParam(action, "id"))
                    Return True
                Case "inventory"
                    ShowInventory(session, p)
                    Return True
                Case "sonicgrant"
                    p.SonicOwned = True
                    If GetParam(action, "name") <> "" Then p.SonicName = GetParam(action, "name")
                    Console(session, 100, 200, 225, "SONIC SCREWDRIVER LINKED TO BIODATA: " & p.SonicName & ".")
                    Return True
                Case "soniccustomize"
                    If Not p.SonicOwned Then
                        Console(session, 210, 100, 80, "No sonic screwdriver is registered to this biodata profile.")
                    Else
                        If GetParam(action, "name") <> "" Then p.SonicName = GetParam(action, "name")
                        If GetParam(action, "casing") <> "" Then p.SonicCasing = GetParam(action, "casing")
                        If GetParam(action, "emitter") <> "" Then p.SonicEmitter = GetParam(action, "emitter")
                        If GetParam(action, "crystal") <> "" Then p.SonicCrystal = GetParam(action, "crystal")
                        ShowSonicProfile(session, p)
                    End If
                    Return True
                Case "setspecies"
                    Dim newSpecies As String = GetParam(action, "species")
                    If newSpecies <> "" Then
                        p.Species = newSpecies
                        p.IsTimeLord = (newSpecies.IndexOf("time lord", StringComparison.OrdinalIgnoreCase) >= 0 OrElse newSpecies.IndexOf("gallifreyan", StringComparison.OrdinalIgnoreCase) >= 0)
                        Console(session, 170, 160, 210, "BIODATA SPECIES PROFILE: " & p.Species & ".")
                    End If
                    Return True
                Case "sonicupgrade"
                    If Not p.SonicOwned Then
                        Console(session, 210, 100, 80, "No sonic screwdriver is registered to this biodata profile.")
                    Else
                        p.SonicUpgradeLevel = RpgRules.Clamp(p.SonicUpgradeLevel + Math.Max(1, ParseInt(GetParam(action, "amount"), 1)), 1, 10)
                        Console(session, 110, 205, 230, "Sonic screwdriver upgraded to Mk " & p.SonicUpgradeLevel.ToString() & ".")
                    End If
                    Return True
                Case "academycredit"
                    AwardAcademyCredits(session, p, Math.Max(0, ParseInt(GetParam(action, "amount"), 1)), GetParam(action, "reason"))
                    Return True
                Case "academy"
                    ShowAcademy(session, p)
                    Return True
                Case "companionadd"
                    AddCompanion(session, p, action)
                    Return True
                Case "companionremove"
                    RemoveCompanion(session, p, GetParam(action, "id"))
                    Return True
                Case "companionactivate"
                    ActivateCompanion(session, p, GetParam(action, "id"))
                    Return True
                Case "companionloyalty"
                    ChangeCompanionLoyalty(session, p, GetParam(action, "id"), ParseInt(GetParam(action, "amount"), 0))
                    Return True
                Case "paradox"
                    ChangeParadox(session, p, ParseInt(GetParam(action, "amount"), 0), GetParam(action, "source"))
                    Return True
                Case "paradoxstabilize"
                    StabilizeParadox(session, p)
                    Return True
                Case "roomunlock"
                    UnlockTardisRoom(session, p, GetParam(action, "name"))
                    Return True
                Case "roomuse"
                    UseTardisRoom(session, p, GetParam(action, "name"), RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 40), 1, 100))
                    Return True
                Case "dialogue"
                    RunDialogueNode(session, p, action)
                    Return True
                Case "speciescatalog"
                    CatalogSpecies(session, p, GetParam(action, "species"), RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 35), 1, 100))
                    Return True
                Case "adventure"
                    GenerateProceduralAdventure(session, p, CurrentWorld(sender))
                    Return True
                Case "storyflag"
                    SetStoryFlag(session, p, GetParam(action, "id"), GetParam(action, "value"))
                    Return True
                Case "profile"
                    ShowV4Profile(session, p)
                    Return True
            End Select
            Return False
        End Function

        Private Sub EnsureV4Profile(p As PlayerProfile)
            If p.Inventory Is Nothing Then p.Inventory = New List(Of InventoryItem)()
            If p.Companions Is Nothing Then p.Companions = New List(Of CompanionRecord)()
            If p.TardisRooms Is Nothing Then p.TardisRooms = New List(Of String)()
            If p.StoryFlags Is Nothing Then p.StoryFlags = New List(Of String)()
            If p.SpeciesCatalog Is Nothing Then p.SpeciesCatalog = New List(Of String)()
            If String.IsNullOrWhiteSpace(p.Species) Then p.Species = If(p.IsTimeLord, "Time Lord", "Human")
            If String.IsNullOrWhiteSpace(p.SonicName) Then p.SonicName = "Sonic Screwdriver"
            If p.SonicUpgradeLevel < 1 Then p.SonicUpgradeLevel = 1
            If p.TardisRooms.Count = 0 Then
                p.TardisRooms.Add("Console Room")
                p.TardisRooms.Add("Medical Bay")
            End If
            RefreshAcademyRank(p)
            RefreshTitle(p)
        End Sub

        ' ============================================================
        ' SPECIES / ENCOUNTER TEMPLATES
        ' ============================================================
        Private Sub ApplySpeciesTemplate(enemy As EnemyState, action As String)
            Dim s As String = If(enemy.Species, "").Trim().ToLowerInvariant()
            Select Case s
                Case "dalek"
                    enemy.MaxHealth = Math.Max(enemy.MaxHealth, 75)
                    enemy.Health = Math.Min(enemy.MaxHealth, Math.Max(enemy.Health, 75))
                    enemy.Defense = Math.Max(enemy.Defense, 68)
                    enemy.Attack = Math.Max(enemy.Attack, 20)
                    enemy.AttackDifficulty = Math.Max(enemy.AttackDifficulty, 62)
                    enemy.DamageType = "energy"
                Case "cyberman", "cybermen"
                    enemy.MaxHealth = Math.Max(enemy.MaxHealth, 65)
                    enemy.Health = Math.Min(enemy.MaxHealth, Math.Max(enemy.Health, 65))
                    enemy.Defense = Math.Max(enemy.Defense, 58)
                    enemy.Attack = Math.Max(enemy.Attack, 15)
                    enemy.DamageType = "energy"
                Case "weeping angel", "weepingangel", "angel"
                    enemy.MaxHealth = Math.Max(enemy.MaxHealth, 100)
                    enemy.Health = Math.Min(enemy.MaxHealth, Math.Max(enemy.Health, 100))
                    enemy.Defense = Math.Max(enemy.Defense, 78)
                    enemy.Attack = Math.Max(enemy.Attack, 25)
                    enemy.DamageType = "temporal"
                Case "sontaran"
                    enemy.MaxHealth = Math.Max(enemy.MaxHealth, 60)
                    enemy.Health = Math.Min(enemy.MaxHealth, Math.Max(enemy.Health, 60))
                    enemy.Defense = Math.Max(enemy.Defense, 52)
                    enemy.Attack = Math.Max(enemy.Attack, 16)
                Case "judoon"
                    enemy.MaxHealth = Math.Max(enemy.MaxHealth, 55)
                    enemy.Health = Math.Min(enemy.MaxHealth, Math.Max(enemy.Health, 55))
                    enemy.Defense = Math.Max(enemy.Defense, 50)
                    enemy.Attack = Math.Max(enemy.Attack, 14)
                Case "auton"
                    enemy.MaxHealth = Math.Max(enemy.MaxHealth, 50)
                    enemy.Health = Math.Min(enemy.MaxHealth, Math.Max(enemy.Health, 50))
                    enemy.Defense = Math.Max(enemy.Defense, 48)
                Case "time lord", "timelord"
                    enemy.Defense = Math.Max(enemy.Defense, 60)
                    enemy.AttackDifficulty = Math.Max(enemy.AttackDifficulty, 55)
                    enemy.DamageType = "temporal"
            End Select
        End Sub

        Private Function SpeciesEncounterRule(session As Integer, p As PlayerProfile, enemy As EnemyState, approach As String, ByRef pressureMultiplier As Double, ByRef difficultyModifier As Integer) As Boolean
            pressureMultiplier = 1.0
            difficultyModifier = 0
            Dim s As String = If(enemy.Species, "").Trim().ToLowerInvariant()
            Select Case s
                Case "dalek"
                    If approach = "sonic" Then pressureMultiplier = 0.45
                    If approach = "diplomacy" Then difficultyModifier += 18
                    If approach = "investigate" Then difficultyModifier -= 8
                Case "cyberman", "cybermen"
                    If approach = "sonic" Then pressureMultiplier = 1.45
                    If approach = "psychic" Then pressureMultiplier = 0.5
                Case "weeping angel", "weepingangel", "angel"
                    If approach = "combat" Then
                        Console(session, 210, 110, 80, "Direct combat is useless while the Angel is quantum-locked. Observe, evade, or understand it instead.")
                        EnemyRetaliate(session, p, enemy)
                        Return False
                    End If
                    If approach = "investigate" OrElse approach = "stealth" Then difficultyModifier -= 12
                    If approach = "sonic" Then pressureMultiplier = 0.35
                Case "sontaran"
                    If approach = "combat" Then difficultyModifier -= 5
                    If approach = "diplomacy" Then difficultyModifier += 8
                Case "judoon"
                    If approach = "diplomacy" Then difficultyModifier -= 15
                Case "auton"
                    If approach = "sonic" Then difficultyModifier -= 12 : pressureMultiplier = 1.35
                Case "time lord", "timelord"
                    If approach = "psychic" OrElse approach = "diplomacy" Then difficultyModifier -= 8
            End Select
            Return True
        End Function

        Private Sub OnEnemyDefeatedV4(session As Integer, p As PlayerProfile, enemy As EnemyState, approach As String)
            EnsureV4Profile(p)
            CatalogSpeciesSilent(p, enemy.Species)
            Dim roll As Integer = _rng.Next(1, 101)
            If roll <= 30 Then
                Dim lootAction As String = "id:" & enemy.Species.Replace(" ", "_").ToLowerInvariant() & "_component,name:" & enemy.Species & " Component,type:artifact,qty:1,description:Recovered from " & enemy.Name
                GiveItem(session, p, lootAction)
            End If
            If approach <> "combat" Then AwardAcademyCredits(session, p, 2, "non-lethal encounter resolution") Else AwardAcademyCredits(session, p, 1, "field encounter")
        End Sub

        ' ============================================================
        ' INVENTORY / EQUIPMENT / ARTIFACTS
        ' ============================================================
        Private Sub GiveItem(session As Integer, p As PlayerProfile, action As String)
            Dim id As String = GetParam(action, "id")
            Dim name As String = GetParam(action, "name")
            If id = "" Then id = If(name = "", "artifact_" & DateTime.UtcNow.Ticks.ToString(), name.Replace(" ", "_").ToLowerInvariant())
            If name = "" Then name = id
            Dim qty As Integer = Math.Max(1, ParseInt(GetParam(action, "qty"), ParseInt(GetParam(action, "amount"), 1)))
            Dim existing As InventoryItem = FindItem(p, id)
            If existing Is Nothing Then
                existing = New InventoryItem With {
                    .Id = id,
                    .Name = name,
                    .ItemType = If(GetParam(action, "type") = "", "artifact", GetParam(action, "type")),
                    .Quantity = qty,
                    .SkillBonus = GetParam(action, "skill"),
                    .BonusAmount = ParseDouble(GetParam(action, "bonus"), 0),
                    .Description = GetParam(action, "description")
                }
                p.Inventory.Add(existing)
            Else
                existing.Quantity += qty
            End If
            Console(session, 230, 195, 90, "ACQUIRED: " & name & " x" & qty.ToString() & ".")
        End Sub

        Private Sub TakeItem(session As Integer, p As PlayerProfile, id As String, amount As Integer)
            Dim item As InventoryItem = FindItem(p, id)
            If item Is Nothing Then
                Console(session, 180, 100, 90, "Inventory does not contain '" & id & "'.")
                Return
            End If
            item.Quantity -= amount
            If item.Quantity <= 0 Then p.Inventory.Remove(item)
            Console(session, 170, 150, 110, "Removed " & amount.ToString() & " x " & item.Name & ".")
        End Sub

        Private Function FindItem(p As PlayerProfile, id As String) As InventoryItem
            EnsureV4Profile(p)
            For Each item As InventoryItem In p.Inventory
                If String.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase) OrElse String.Equals(item.Name, id, StringComparison.OrdinalIgnoreCase) Then Return item
            Next
            Return Nothing
        End Function

        Private Sub EquipItem(session As Integer, p As PlayerProfile, id As String)
            Dim item As InventoryItem = FindItem(p, id)
            If item Is Nothing Then
                Console(session, 190, 90, 90, "Cannot equip unknown item '" & id & "'.")
                Return
            End If
            item.Equipped = True
            Console(session, 100, 190, 180, "EQUIPPED: " & item.Name & If(item.SkillBonus <> "", " [" & item.SkillBonus & " +" & item.BonusAmount.ToString("0.#") & "]", "") & ".")
        End Sub

        Private Sub UnequipItem(session As Integer, p As PlayerProfile, id As String)
            Dim item As InventoryItem = FindItem(p, id)
            If item Is Nothing Then Return
            item.Equipped = False
            Console(session, 150, 150, 160, "UNEQUIPPED: " & item.Name & ".")
        End Sub

        Private Sub UseItem(session As Integer, p As PlayerProfile, id As String)
            Dim item As InventoryItem = FindItem(p, id)
            If item Is Nothing Then
                Console(session, 190, 90, 90, "You do not possess '" & id & "'.")
                Return
            End If
            Select Case item.ItemType.Trim().ToLowerInvariant()
                Case "medkit", "healing"
                    ApplyHealing(p, 25, session, item.Name)
                    TakeItem(session, p, item.Id, 1)
                Case "artroncell", "artron"
                    p.ArtronReserve = Math.Min(p.MaxArtronReserve, p.ArtronReserve + 35)
                    Console(session, 175, 120, 225, item.Name & " replenishes 35 Artron.")
                    TakeItem(session, p, item.Id, 1)
                Case Else
                    Console(session, 170, 160, 200, item.Name & " has no consumable use; equip it or use it in a scripted encounter.")
            End Select
        End Sub

        Private Function EquipmentSkillBonus(p As PlayerProfile, skillName As String) As Double
            EnsureV4Profile(p)
            Dim total As Double = 0
            For Each item As InventoryItem In p.Inventory
                If item.Equipped AndAlso String.Equals(RpgRules.NormalizeSkillName(item.SkillBonus), skillName, StringComparison.OrdinalIgnoreCase) Then total += item.BonusAmount
            Next
            Return Math.Min(20.0, total)
        End Function

        Private Sub ShowInventory(session As Integer, p As PlayerProfile)
            EnsureV4Profile(p)
            If p.Inventory.Count = 0 Then
                Console(session, 160, 150, 170, "INVENTORY | Empty.")
                Return
            End If
            Console(session, 230, 190, 90, "INVENTORY | " & p.Inventory.Count.ToString() & " item types.")
            For Each item As InventoryItem In p.Inventory
                Console(session, 170, 180, 210, If(item.Equipped, "[E] ", "") & item.Name & " x" & item.Quantity.ToString() & If(item.SkillBonus <> "", " | " & item.SkillBonus & " +" & item.BonusAmount.ToString("0.#"), ""))
            Next
        End Sub

        ' ============================================================
        ' SONIC OWNERSHIP / CUSTOMISATION
        ' ============================================================
        Private Sub ShowSonicProfile(session As Integer, p As PlayerProfile)
            EnsureV4Profile(p)
            If Not p.SonicOwned Then
                Console(session, 170, 120, 110, "No sonic screwdriver is currently registered to this incarnation.")
                Return
            End If
            Console(session, 100, 200, 230, "SONIC | " & p.SonicName & " | Mk " & p.SonicUpgradeLevel.ToString() & " | " & p.SonicCasing & " casing | " & p.SonicEmitter & " emitter | " & p.SonicCrystal & " crystal | Mode " & p.SonicMode.ToUpperInvariant() & ".")
        End Sub

        Private Function SonicUpgradeBonus(p As PlayerProfile) As Double
            If Not p.SonicOwned Then Return -100
            Return Math.Min(12.0, Math.Max(0, p.SonicUpgradeLevel - 1) * 1.5)
        End Function

        ' ============================================================
        ' GALLIFREYAN ACADEMY / TITLES
        ' ============================================================
        Private Sub AwardAcademyCredits(session As Integer, p As PlayerProfile, amount As Integer, reason As String)
            If amount <= 0 Then Return
            p.AcademyCredits += amount
            Dim oldRank As String = p.AcademyRank
            RefreshAcademyRank(p)
            RefreshTitle(p)
            Console(session, 205, 175, 100, "ACADEMY +" & amount.ToString() & " credit" & If(amount = 1, "", "s") & If(reason = "", "", " — " & reason) & ". Total: " & p.AcademyCredits.ToString() & ".")
            If Not String.Equals(oldRank, p.AcademyRank, StringComparison.OrdinalIgnoreCase) Then Console(session, 245, 205, 90, "ACADEMY PROMOTION: " & p.AcademyRank & ".")
        End Sub

        Private Sub RefreshAcademyRank(p As PlayerProfile)
            Dim c As Integer = Math.Max(0, p.AcademyCredits)
            Dim index As Integer = 0
            If c >= 20 Then index = 1
            If c >= 60 Then index = 2
            If c >= 140 Then index = 3
            If c >= 300 Then index = 4
            If c >= 600 Then index = 5
            If c >= 1000 Then index = 6
            p.AcademyRank = _academyRanks(index)
        End Sub

        Private Function AcademySkillBonus(p As PlayerProfile, skillName As String) As Double
            RefreshAcademyRank(p)
            Select Case p.AcademyRank
                Case "Academy Graduate" : Return 1
                Case "Time Lord" : Return 2
                Case "Senior Time Lord" : Return 3
                Case "Cardinal" : Return 4
                Case "High Councillor" : Return 5
            End Select
            Return 0
        End Function

        Private Sub RefreshTitle(p As PlayerProfile)
            RefreshAcademyRank(p)
            If p.AcademyRank = "Initiate" OrElse p.AcademyRank = "Novice" Then
                p.Title = p.AcademyRank
            ElseIf p.IsTimeLord Then
                p.Title = "The " & p.AcademyRank
            Else
                p.Title = p.AcademyRank
            End If
            If p.MissionsCompleted >= 25 Then p.Title &= " of the Long Road"
            If p.PerfectLandings >= 50 Then p.Title &= " • Vortex Ace"
        End Sub

        Private Sub ShowAcademy(session As Integer, p As PlayerProfile)
            EnsureV4Profile(p)
            Console(session, 235, 195, 95, "ACADEMY | " & p.AcademyRank & " | Credits " & p.AcademyCredits.ToString() & " | Title: " & p.Title & ".")
        End Sub

        ' ============================================================
        ' COMPANIONS
        ' ============================================================
        Private Sub AddCompanion(session As Integer, p As PlayerProfile, action As String)
            Dim id As String = GetParam(action, "id")
            Dim name As String = GetParam(action, "name")
            If id = "" Then id = If(name = "", "companion_" & DateTime.UtcNow.Ticks.ToString(), name.Replace(" ", "_").ToLowerInvariant())
            If name = "" Then name = id
            For Each c As CompanionRecord In p.Companions
                If String.Equals(c.Id, id, StringComparison.OrdinalIgnoreCase) Then
                    Console(session, 160, 150, 110, name & " is already travelling with you.")
                    Return
                End If
            Next
            Dim comp As New CompanionRecord With {
                .Id = id,
                .Name = name,
                .Species = If(GetParam(action, "species") = "", "Human", GetParam(action, "species")),
                .Role = If(GetParam(action, "role") = "", "Companion", GetParam(action, "role")),
                .Loyalty = RpgRules.Clamp(ParseInt(GetParam(action, "loyalty"), 50), 0, 100),
                .SkillBonus = If(GetParam(action, "skill") = "", "Investigation", RpgRules.NormalizeSkillName(GetParam(action, "skill"))),
                .BonusAmount = ParseDouble(GetParam(action, "bonus"), 3)
            }
            p.Companions.Add(comp)
            If p.Companions.Count = 1 Then comp.Active = True
            Console(session, 120, 200, 170, "COMPANION JOINED: " & comp.Name & " (" & comp.Species & ").")
        End Sub

        Private Sub RemoveCompanion(session As Integer, p As PlayerProfile, id As String)
            For i As Integer = p.Companions.Count - 1 To 0 Step -1
                If String.Equals(p.Companions(i).Id, id, StringComparison.OrdinalIgnoreCase) OrElse String.Equals(p.Companions(i).Name, id, StringComparison.OrdinalIgnoreCase) Then
                    Console(session, 180, 150, 120, p.Companions(i).Name & " leaves the TARDIS.")
                    p.Companions.RemoveAt(i)
                    Return
                End If
            Next
        End Sub

        Private Sub ActivateCompanion(session As Integer, p As PlayerProfile, id As String)
            Dim found As Boolean = False
            For Each c As CompanionRecord In p.Companions
                c.Active = String.Equals(c.Id, id, StringComparison.OrdinalIgnoreCase) OrElse String.Equals(c.Name, id, StringComparison.OrdinalIgnoreCase)
                If c.Active Then found = True : Console(session, 120, 200, 170, c.Name & " is now your active companion.")
            Next
            If Not found Then Console(session, 180, 100, 100, "No companion named '" & id & "'.")
        End Sub

        Private Sub ChangeCompanionLoyalty(session As Integer, p As PlayerProfile, id As String, amount As Integer)
            For Each c As CompanionRecord In p.Companions
                If String.Equals(c.Id, id, StringComparison.OrdinalIgnoreCase) OrElse String.Equals(c.Name, id, StringComparison.OrdinalIgnoreCase) Then
                    c.Loyalty = RpgRules.Clamp(c.Loyalty + amount, 0, 100)
                    Console(session, 180, 170, 120, c.Name & " loyalty: " & c.Loyalty.ToString() & "/100.")
                    Return
                End If
            Next
        End Sub

        Private Function CompanionSkillBonus(p As PlayerProfile, skillName As String) As Double
            EnsureV4Profile(p)
            For Each c As CompanionRecord In p.Companions
                If c.Active AndAlso c.Loyalty >= 20 AndAlso String.Equals(RpgRules.NormalizeSkillName(c.SkillBonus), skillName, StringComparison.OrdinalIgnoreCase) Then
                    Return c.BonusAmount * Math.Max(0.25, c.Loyalty / 100.0)
                End If
            Next
            Return 0
        End Function

        Private Sub ShowCompanions(session As Integer, p As PlayerProfile)
            EnsureV4Profile(p)
            If p.Companions.Count = 0 Then
                Console(session, 160, 150, 170, "COMPANIONS | None currently aboard.")
                Return
            End If
            For Each c As CompanionRecord In p.Companions
                Console(session, 130, 190, 170, If(c.Active, "[ACTIVE] ", "") & c.Name & " | " & c.Species & " | Loyalty " & c.Loyalty.ToString() & " | " & c.SkillBonus & " +" & c.BonusAmount.ToString("0.#"))
            Next
        End Sub

        ' ============================================================
        ' PARADOX / TEMPORAL CONSEQUENCES
        ' ============================================================
        Private Sub ChangeParadox(session As Integer, p As PlayerProfile, amount As Integer, source As String)
            p.ParadoxLevel = RpgRules.Clamp(p.ParadoxLevel + amount, 0, 100)
            Console(session, 185, 120, 225, "PARADOX " & If(amount >= 0, "+", "") & amount.ToString() & " => " & p.ParadoxLevel.ToString() & "/100" & If(source = "", "", " (" & source & ")") & ".")
            If p.ParadoxLevel >= 75 Then AddStatus(p, "Temporal Displaced", 120, 1, "paradox saturation", session)
        End Sub

        Private Function ParadoxSkillPenalty(p As PlayerProfile, skillName As String) As Double
            If p.ParadoxLevel < 25 Then Return 0
            If skillName <> "Piloting" AndAlso skillName <> "Navigation" AndAlso skillName <> "Temporal Science" Then Return 0
            Return Math.Min(20, Math.Floor(p.ParadoxLevel / 10.0) * 2)
        End Function

        Private Sub StabilizeParadox(session As Integer, p As PlayerProfile)
            If p.ParadoxLevel <= 0 Then
                Console(session, 120, 180, 180, "Timeline readings are stable. No paradox requires correction.")
                Return
            End If
            If p.ArtronReserve < 10 Then
                Console(session, 210, 90, 90, "Paradox stabilization requires at least 10 Artron.")
                Return
            End If
            Dim check As SkillCheckResult = PerformSkillCheck(p, "Temporal Science", Math.Min(90, 30 + p.ParadoxLevel \ 2))
            p.ArtronReserve -= 10
            If check.Success Then
                Dim amount As Integer = If(check.CriticalSuccess, 30, 15)
                p.ParadoxLevel = Math.Max(0, p.ParadoxLevel - amount)
                Console(session, 100, 200, 200, "Temporal lattice stabilized. Paradox reduced by " & amount.ToString() & " to " & p.ParadoxLevel.ToString() & ".")
            Else
                Console(session, 220, 100, 90, "Temporal stabilization fails. The timeline continues to grind against itself.")
                If check.CriticalFailure Then p.ParadoxLevel = Math.Min(100, p.ParadoxLevel + 5)
            End If
            ReportSkillGain(session, "Temporal Science", check)
        End Sub

        Private Sub ShowParadox(session As Integer, p As PlayerProfile)
            Dim descriptor As String = "Stable"
            If p.ParadoxLevel >= 25 Then descriptor = "Strained"
            If p.ParadoxLevel >= 50 Then descriptor = "Unstable"
            If p.ParadoxLevel >= 75 Then descriptor = "Critical"
            Console(session, 180, 120, 225, "PARADOX INDEX | " & p.ParadoxLevel.ToString() & "/100 — " & descriptor & ".")
        End Sub

        ' ============================================================
        ' TARDIS ROOMS
        ' ============================================================
        Private Sub UnlockTardisRoom(session As Integer, p As PlayerProfile, roomName As String)
            If String.IsNullOrWhiteSpace(roomName) Then Return
            For Each room As String In p.TardisRooms
                If String.Equals(room, roomName, StringComparison.OrdinalIgnoreCase) Then
                    Console(session, 150, 150, 165, roomName & " is already part of the current architectural configuration.")
                    Return
                End If
            Next
            p.TardisRooms.Add(roomName)
            Console(session, 105, 195, 220, "ARCHITECTURAL CONFIGURATION EXPANDED: " & roomName & ".")
        End Sub

        Private Function HasTardisRoom(p As PlayerProfile, roomName As String) As Boolean
            EnsureV4Profile(p)
            For Each room As String In p.TardisRooms
                If String.Equals(room, roomName, StringComparison.OrdinalIgnoreCase) Then Return True
            Next
            Return False
        End Function

        Private Sub UseTardisRoom(session As Integer, p As PlayerProfile, roomName As String, difficulty As Integer)
            If String.IsNullOrWhiteSpace(roomName) Then roomName = "Console Room"
            If Not HasTardisRoom(p, roomName) Then
                Console(session, 190, 90, 100, "The TARDIS has not configured a " & roomName & ".")
                Return
            End If
            Select Case roomName.Trim().ToLowerInvariant()
                Case "medical bay", "medbay"
                    Dim check As SkillCheckResult = PerformSkillCheck(p, "Medicine", difficulty)
                    ApplyHealing(p, If(check.Success, 35, 12), session, "TARDIS medical bay")
                    If check.Success Then HealHearts(p, 20, session) : CureOneHarmfulStatus(p, session)
                    ReportSkillGain(session, "Medicine", check)
                Case "workshop"
                    RepairTardis(p, "hull", difficulty, session)
                    If p.SonicOwned AndAlso p.SonicUpgradeLevel < 10 AndAlso _rng.Next(1, 101) <= 15 Then
                        p.SonicUpgradeLevel += 1
                        Console(session, 100, 200, 225, "Workshop calibration improves the sonic screwdriver to Mk " & p.SonicUpgradeLevel.ToString() & ".")
                    End If
                Case "library"
                    Dim check As SkillCheckResult = PerformSkillCheck(p, "Investigation", difficulty)
                    If check.Success Then AwardAcademyCredits(session, p, 2, "TARDIS library research")
                    ReportSkillGain(session, "Investigation", check)
                Case "wardrobe"
                    Console(session, 210, 160, 220, "The wardrobe hums open. Entire civilizations appear to have donated coats.")
                Case "cloister room"
                    p.ArtronReserve = Math.Min(p.MaxArtronReserve, p.ArtronReserve + 20)
                    p.ParadoxLevel = Math.Max(0, p.ParadoxLevel - 5)
                    Console(session, 150, 120, 220, "The Cloister Room settles your biodata: +20 Artron, -5 paradox.")
                Case "zero room"
                    RemoveStatusSilent(p, "Psychically Overloaded")
                    RemoveStatusSilent(p, "Temporal Displaced")
                    p.ParadoxLevel = Math.Max(0, p.ParadoxLevel - 10)
                    Console(session, 150, 190, 190, "The Zero Room isolates you from the universe. Temporal and psychic stress recedes.")
                Case Else
                    Console(session, 150, 170, 210, roomName & " is accessible, but has no special gameplay function configured yet.")
            End Select
        End Sub

        Private Sub ShowTardisRooms(session As Integer, p As PlayerProfile)
            EnsureV4Profile(p)
            Console(session, 100, 190, 220, "TARDIS ROOMS | " & String.Join(" | ", p.TardisRooms.ToArray()))
        End Sub

        ' ============================================================
        ' SPECIES CATALOGUE / XENOBIOLOGY
        ' ============================================================
        Private Sub CatalogSpecies(session As Integer, p As PlayerProfile, species As String, difficulty As Integer)
            If String.IsNullOrWhiteSpace(species) Then species = "Unknown"
            Dim check As SkillCheckResult = PerformSkillCheck(p, "Xenobiology", difficulty)
            If check.Success Then
                If CatalogSpeciesSilent(p, species) Then Console(session, 100, 200, 170, "SPECIES CATALOGUED: " & species & ".") Else Console(session, 150, 170, 170, species & " is already present in your xenobiology catalogue.")
                AwardAcademyCredits(session, p, 1, "xenobiology fieldwork")
            Else
                Console(session, 210, 120, 90, "Unable to classify the lifeform with confidence.")
            End If
            ReportSkillGain(session, "Xenobiology", check)
        End Sub

        Private Function CatalogSpeciesSilent(p As PlayerProfile, species As String) As Boolean
            EnsureV4Profile(p)
            If String.IsNullOrWhiteSpace(species) Then Return False
            For Each s As String In p.SpeciesCatalog
                If String.Equals(s, species, StringComparison.OrdinalIgnoreCase) Then Return False
            Next
            p.SpeciesCatalog.Add(species)
            Return True
        End Function

        ' ============================================================
        ' PROCEDURAL ADVENTURES
        ' ============================================================
        Private Sub GenerateProceduralAdventure(session As Integer, p As PlayerProfile, currentWorld As String)
            Dim unique As New List(Of TardisDestination)()
            Dim seen As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
            For Each d As TardisDestination In _destinations.Values
                Dim key As String = d.WorldName & ":" & d.Name
                If seen.Add(key) Then unique.Add(d)
            Next
            If unique.Count = 0 Then
                Console(session, 190, 100, 100, "The TARDIS cannot generate an adventure without navigation destinations.")
                Return
            End If
            Dim dsel As TardisDestination = unique(_rng.Next(0, unique.Count))
            Dim hooks As String() = {"A vanished research team", "A temporal echo", "An impossible distress signal", "A locked Gallifreyan relic", "A species behaving out of time", "A damaged refugee ship", "A paradox spreading through local history", "A machine asking for help"}
            Dim hook As String = hooks(_rng.Next(0, hooks.Length))
            Dim id As String = "adventure_" & DateTime.UtcNow.ToString("yyyyMMddHHmmss")
            Dim worldName As String = If(String.IsNullOrWhiteSpace(dsel.WorldName), currentWorld, dsel.WorldName)
            p.Missions.Add(New MissionProgress With {
                .Id = id,
                .Title = "Adventure: " & dsel.Name,
                .Objective = hook & " has been detected at " & dsel.Name & ". Reach the location and resolve the situation by any viable method.",
                .Required = 2,
                .Destination = dsel.Name & " [" & worldName & "]"
            })
            Console(session, 245, 175, 75, "THE TARDIS HAS FOUND SOMETHING: " & hook & ".")
            Console(session, 150, 190, 230, "Destination: " & dsel.Name & " [" & worldName & "]. Mission ID: " & id & ".")
        End Sub

        ' ============================================================
        ' DIALOGUE TREES / STORY FLAGS
        ' ============================================================
        Private Sub RunDialogueNode(session As Integer, p As PlayerProfile, action As String)
            Dim requireFlag As String = GetParam(action, "requireflag")
            If requireFlag <> "" AndAlso Not HasStoryFlag(p, requireFlag) Then
                Console(session, 150, 140, 150, If(GetParam(action, "lockedtext") = "", "The conversation has nothing more to reveal yet.", GetParam(action, "lockedtext")))
                Return
            End If
            Dim text As String = GetParam(action, "text")
            If text <> "" Then Console(session, 190, 190, 210, text)
            Dim skill As String = GetParam(action, "skill")
            Dim success As Boolean = True
            If skill <> "" Then
                Dim check As SkillCheckResult = PerformSkillCheck(p, skill, RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 45), 1, 100))
                success = check.Success
                ReportSkillGain(session, skill, check)
            End If
            If success Then
                If GetParam(action, "successtext") <> "" Then Console(session, 110, 200, 160, GetParam(action, "successtext"))
                If GetParam(action, "setflag") <> "" Then SetStoryFlag(session, p, GetParam(action, "setflag"), "1")
                If GetParam(action, "missionid") <> "" Then ProgressMission(session, p, GetParam(action, "missionid"), Math.Max(1, ParseInt(GetParam(action, "progress"), 1)))
                If GetParam(action, "faction") <> "" Then ChangeReputation(session, p, GetParam(action, "faction"), ParseInt(GetParam(action, "reputation"), 1))
                If GetParam(action, "item") <> "" Then GiveItem(session, p, "id:" & GetParam(action, "item") & ",name:" & GetParam(action, "item"))
            Else
                If GetParam(action, "failtext") <> "" Then Console(session, 220, 120, 100, GetParam(action, "failtext"))
            End If
        End Sub

        Private Function HasStoryFlag(p As PlayerProfile, id As String) As Boolean
            EnsureV4Profile(p)
            For Each f As String In p.StoryFlags
                If f.StartsWith(id & "=", StringComparison.OrdinalIgnoreCase) OrElse String.Equals(f, id, StringComparison.OrdinalIgnoreCase) Then Return True
            Next
            Return False
        End Function

        Private Sub SetStoryFlag(session As Integer, p As PlayerProfile, id As String, value As String)
            If String.IsNullOrWhiteSpace(id) Then Return
            For i As Integer = p.StoryFlags.Count - 1 To 0 Step -1
                If p.StoryFlags(i).StartsWith(id & "=", StringComparison.OrdinalIgnoreCase) OrElse String.Equals(p.StoryFlags(i), id, StringComparison.OrdinalIgnoreCase) Then p.StoryFlags.RemoveAt(i)
            Next
            p.StoryFlags.Add(id & "=" & If(value = "", "1", value))
            Console(session, 150, 150, 190, "STORY STATE UPDATED: " & id & ".")
        End Sub

        ' ============================================================
        ' SHARED V4 BONUSES / PROFILE / TICK
        ' ============================================================
        Private Function V4SkillModifier(p As PlayerProfile, skillName As String) As Double
            EnsureV4Profile(p)
            Return EquipmentSkillBonus(p, skillName) + CompanionSkillBonus(p, skillName) + AcademySkillBonus(p, skillName) + If(skillName = "Sonic Technology", SonicUpgradeBonus(p), 0) - ParadoxSkillPenalty(p, skillName)
        End Function

        Private Sub OnSkillUseV4(session As Integer, p As PlayerProfile, skillName As String, result As SkillCheckResult)
            If result.Success AndAlso result.Gain > 0 Then
                Dim credits As Integer = If(result.CriticalSuccess, 2, 1)
                If _rng.Next(1, 101) <= 18 Then AwardAcademyCredits(session, p, credits, skillName & " practical")
            End If
        End Sub

        Private Sub OnTravelV4(session As Integer, p As PlayerProfile, dest As TardisDestination, currentWorld As String, targetWorld As String)
            EnsureV4Profile(p)
            If Not String.Equals(currentWorld, targetWorld, StringComparison.OrdinalIgnoreCase) Then
                ChangeParadox(session, p, 1, "cross-world transit")
            End If
            AwardAcademyCredits(session, p, 1, "TARDIS navigation")
        End Sub

        Private Sub TickV4(now As DateTime)
            For Each pair As KeyValuePair(Of Integer, PlayerProfile) In New Dictionary(Of Integer, PlayerProfile)(_sessions)
                Dim session As Integer = pair.Key
                Dim p As PlayerProfile = pair.Value
                EnsureV4Profile(p)
                If p.ParadoxLevel >= 85 Then
                    Dim due As Boolean = Not _lastParadoxHazardCheck.ContainsKey(session) OrElse (now - _lastParadoxHazardCheck(session)).TotalSeconds >= ParadoxHazardCheckSeconds
                    If due Then
                        _lastParadoxHazardCheck(session) = now
                        If _rng.Next(1, 101) <= 3 Then
                            AddStatus(p, "Temporal Displaced", 60, 1, "critical paradox", session)
                            ApplyDamage(p, 3, "temporal", session, "timeline recoil", False)
                        End If
                    End If
                End If
            Next
        End Sub

        Private Sub ShowV4Profile(session As Integer, p As PlayerProfile)
            EnsureV4Profile(p)
            Console(session, 235, 195, 95, p.Title & " | Species " & p.Species & " | Incarnation " & p.Incarnation.ToString() & " | Academy " & p.AcademyRank & " (" & p.AcademyCredits.ToString() & ").")
            Console(session, 130, 190, 220, "HP " & p.Health.ToString() & "/" & p.MaxHealth.ToString() & " | Artron " & p.ArtronReserve.ToString() & "/" & p.MaxArtronReserve.ToString() & " | Paradox " & p.ParadoxLevel.ToString() & "/100 | Species catalogued " & p.SpeciesCatalog.Count.ToString() & ".")
            Console(session, 170, 160, 210, "Inventory " & p.Inventory.Count.ToString() & " | Companions " & p.Companions.Count.ToString() & " | TARDIS rooms " & p.TardisRooms.Count.ToString() & " | Sonic " & If(p.SonicOwned, "Mk " & p.SonicUpgradeLevel.ToString(), "none") & ".")
        End Sub

        Private Function ParseDouble(value As String, fallback As Double) As Double
            Dim d As Double
            If Double.TryParse(value, Globalization.NumberStyles.Any, Globalization.CultureInfo.InvariantCulture, d) Then Return d
            Return fallback
        End Function
    End Class
End Namespace
