TIME LORD BOT — REGENERATION APPEARANCES (BUILD FIX 12)
=======================================================

There are now TWO separate appearance systems.

1. NORMAL REGENERATION
Normal regeneration remains random. It draws from RandomRegenerationCavs.txt, backed by
240 complete .awcav definitions in RandomCAVs\. These were generated from valid choices
present in the supplied DeltaWorlds CAV template database.

2. CONTROLLED REGENERATION
The 30 named Doctor variants in RegenerationCavs.txt are reserved for deliberate control.
They are complete live definitions under ControlledCAVs\ and are not used by ordinary
random regeneration.

Useful commands:
  activate ~timelord type:cavstatus
  activate ~timelord type:cavreroll
  activate ~timelord type:cavapply
  activate ~timelord type:reloadcavs
  activate ~timelord type:cavlist
  activate ~timelord type:cavchoose,name:The Velvet Doctor
  activate ~timelord type:controlregen,name:The Velvet Doctor
  activate ~timelord type:cavclear

Expected cavstatus after startup:
  Controlled 30/30 | Random 240/240

Every successful regeneration broadcasts the new incarnation and appearance to current
world sessions tracked by the bot.
