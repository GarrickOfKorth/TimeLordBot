﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports AW

Namespace TimeLordBot

    Public Class AvatarPosition
        Public X As Integer
        Public Y As Integer
        Public Z As Integer
        Public Zone As String = ""
    End Class

    Public Class ConversationTrigger
        Public Id As String = ""
        Public Mode As String = "exact"
        Public Pattern As String = ""
        Public Zone As String = ""
        Public RequireFlag As String = ""
        Public Response As String = ""
        Public Action As String = ""
    End Class

    Public Class ZoneTrigger
        Public Zone As String = ""
        Public EventName As String = "enter"
        Public Response As String = ""
        Public Action As String = ""
    End Class

    Public Class AvatarInteractionTrigger
        Public EventName As String = "click"
        Public Target As String = "*"
        Public Response As String = ""
        Public Action As String = ""
    End Class

    Public Partial Class TardisBot
        Private ReadOnly _conversationTriggers As New List(Of ConversationTrigger)()
        Private ReadOnly _zoneTriggers As New List(Of ZoneTrigger)()
        Private ReadOnly _avatarInteractionTriggers As New List(Of AvatarInteractionTrigger)()
        Private _conversationTriggersPath As String
        Private _zoneTriggersPath As String
        Private _avatarTriggersPath As String
        Private Const AvatarBumpDistance As Integer = 120
        Private Const AvatarBumpCooldownSeconds As Double = 3.0

        Private Sub LoadInteractionTriggers()
            _conversationTriggersPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ConversationTriggers.txt")
            _zoneTriggersPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ZoneTriggers.txt")
            _avatarTriggersPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "AvatarTriggers.txt")
            LoadConversationTriggers()
            LoadZoneTriggers()
            LoadAvatarInteractionTriggers()
        End Sub

        Private Sub LoadConversationTriggers()
            _conversationTriggers.Clear()
            If Not File.Exists(_conversationTriggersPath) Then Return
            Try
                For Each raw As String In File.ReadAllLines(_conversationTriggersPath)
                    Dim line As String = raw.Trim()
                    If line = "" OrElse line.StartsWith("#") Then Continue For
                    Dim f() As String = line.Split("|"c)
                    If f.Length < 7 Then Continue For
                    _conversationTriggers.Add(New ConversationTrigger With {
                        .Id = f(0).Trim(), .Mode = f(1).Trim().ToLowerInvariant(), .Pattern = f(2).Trim(),
                        .Zone = f(3).Trim(), .RequireFlag = f(4).Trim(), .Response = f(5).Trim(), .Action = f(6).Trim()
                    })
                Next
                _log("Loaded " & _conversationTriggers.Count.ToString() & " conversational triggers.")
            Catch ex As Exception
                _log("Conversation trigger load warning: " & ex.Message)
            End Try
        End Sub

        Private Sub LoadZoneTriggers()
            _zoneTriggers.Clear()
            If Not File.Exists(_zoneTriggersPath) Then Return
            Try
                For Each raw As String In File.ReadAllLines(_zoneTriggersPath)
                    Dim line As String = raw.Trim()
                    If line = "" OrElse line.StartsWith("#") Then Continue For
                    Dim f() As String = line.Split("|"c)
                    If f.Length < 4 Then Continue For
                    _zoneTriggers.Add(New ZoneTrigger With {.Zone = f(0).Trim(), .EventName = f(1).Trim().ToLowerInvariant(), .Response = f(2).Trim(), .Action = f(3).Trim()})
                Next
                _log("Loaded " & _zoneTriggers.Count.ToString() & " zone triggers.")
            Catch ex As Exception
                _log("Zone trigger load warning: " & ex.Message)
            End Try
        End Sub

        Private Sub LoadAvatarInteractionTriggers()
            _avatarInteractionTriggers.Clear()
            If Not File.Exists(_avatarTriggersPath) Then Return
            Try
                For Each raw As String In File.ReadAllLines(_avatarTriggersPath)
                    Dim line As String = raw.Trim()
                    If line = "" OrElse line.StartsWith("#") Then Continue For
                    Dim f() As String = line.Split("|"c)
                    If f.Length < 4 Then Continue For
                    _avatarInteractionTriggers.Add(New AvatarInteractionTrigger With {.EventName = f(0).Trim().ToLowerInvariant(), .Target = f(1).Trim(), .Response = f(2).Trim(), .Action = f(3).Trim()})
                Next
                _log("Loaded " & _avatarInteractionTriggers.Count.ToString() & " avatar interaction triggers.")
            Catch ex As Exception
                _log("Avatar trigger load warning: " & ex.Message)
            End Try
        End Sub

        Private Function TryHandleConversationTrigger(session As Integer, sender As AW.Instance, raw As String) As Boolean
            If Not _sessions.ContainsKey(session) Then Return False
            Dim p As PlayerProfile = _sessions(session)
            Dim spoken As String = raw.Trim()
            Dim zone As String = ""
            If _lastZoneBySession.ContainsKey(session) Then zone = _lastZoneBySession(session)

            For Each t As ConversationTrigger In _conversationTriggers
                If t.Pattern = "" Then Continue For
                If t.Zone <> "" AndAlso Not String.Equals(t.Zone, zone, StringComparison.OrdinalIgnoreCase) Then Continue For
                If t.RequireFlag <> "" AndAlso Not HasStoryFlag(p, t.RequireFlag) Then Continue For

                Dim matched As Boolean = False
                Select Case t.Mode
                    Case "contains"
                        matched = spoken.IndexOf(t.Pattern, StringComparison.OrdinalIgnoreCase) >= 0
                    Case "starts", "startswith"
                        matched = spoken.StartsWith(t.Pattern, StringComparison.OrdinalIgnoreCase)
                    Case Else
                        matched = String.Equals(spoken, t.Pattern, StringComparison.OrdinalIgnoreCase)
                End Select
                If Not matched Then Continue For

                _log("CHAT TRIGGER [" & t.Id & "] " & p.Name & ": "" & spoken & """)
                If t.Response <> "" Then Console(session, 100, 185, 220, ExpandInteractionText(t.Response, session, 0, zone))
                If t.Action <> "" Then DispatchGameplayAction(session, sender, t.Action, "chat")
                Return True
            Next
            Return False
        End Function

        Private Function TryHandleSelectedAvatarConversation(session As Integer, sender As AW.Instance, raw As String) As Boolean
            If Not _selectedAvatarBySession.ContainsKey(session) Then Return False
            Dim targetSession As Integer = _selectedAvatarBySession(session)
            If Not _sessions.ContainsKey(targetSession) Then Return False
            Dim target As PlayerProfile = _sessions(targetSession)
            Dim actor As PlayerProfile = _sessions(session)
            Dim lower As String = raw.Trim().ToLowerInvariant()

            If lower = "scan target" OrElse lower = "scan them" OrElse lower = "scan" Then
                Dim line As String = target.Name & " — " & target.Species & "; health " & target.Health.ToString() & "/" & target.MaxHealth.ToString()
                If target.IsTimeLord Then line &= "; hearts " & target.HeartOneHealth.ToString() & "/" & target.HeartTwoHealth.ToString()
                Console(session, 80, 190, 220, "LIFE-SIGN SCAN: " & line & ".")
                Dim check As SkillCheckResult = PerformSkillCheck(actor, "Medicine", 25)
                If check.Gain > 0 Then Console(session, 100, 200, 130, "Medicine skill +" & check.Gain.ToString("0.00") & ".")
                SaveProfiles()
                Return True
            End If

            If lower = "heal target" OrElse lower = "help target" OrElse lower = "stabilize target" OrElse lower = "stabilise target" Then
                Dim check As SkillCheckResult = PerformSkillCheck(actor, "Medicine", 45)
                If check.Success Then
                    Dim amount As Integer = If(check.CriticalSuccess, 25, 15)
                    ApplyHealing(target, amount, targetSession, actor.Name & " medical assistance")
                    Console(session, 100, 210, 140, "You stabilize " & target.Name & " for " & amount.ToString() & " health.")
                    Console(targetSession, 100, 210, 140, actor.Name & " stabilizes you for " & amount.ToString() & " health.")
                Else
                    Console(session, 210, 120, 80, "You cannot stabilize " & target.Name & ".")
                End If
                SaveProfiles()
                RefreshRpgHud(targetSession, True)
                Return True
            End If

            Return False
        End Function

        Private Sub TrackAvatarLocation(sender As AW.Instance, session As Integer, initial As Boolean)
            Dim pos As New AvatarPosition()
            pos.X = sender.GetInt(Attributes.AvatarX)
            pos.Y = sender.GetInt(Attributes.AvatarY)
            pos.Z = sender.GetInt(Attributes.AvatarZ)
            pos.Zone = sender.GetString(Attributes.AvatarZone)
            If pos.Zone Is Nothing Then pos.Zone = ""

            Dim oldZone As String = ""
            If _lastZoneBySession.ContainsKey(session) Then oldZone = _lastZoneBySession(session)
            _lastZoneBySession(session) = pos.Zone
            _avatarPositions(session) = pos

            If Not initial AndAlso Not String.Equals(oldZone, pos.Zone, StringComparison.OrdinalIgnoreCase) Then
                If oldZone <> "" Then FireZoneTriggers(oldZone, "exit", session, sender)
                If pos.Zone <> "" Then FireZoneTriggers(pos.Zone, "enter", session, sender)
            End If

            CheckAvatarProximityBumps(session, pos, sender)
        End Sub

        Private Sub FireZoneTriggers(zone As String, eventName As String, session As Integer, sender As AW.Instance)
            For Each t As ZoneTrigger In _zoneTriggers
                If Not String.Equals(t.Zone, zone, StringComparison.OrdinalIgnoreCase) Then Continue For
                If Not String.Equals(t.EventName, eventName, StringComparison.OrdinalIgnoreCase) Then Continue For
                _log("ZONE " & eventName.ToUpperInvariant() & " [" & zone & "] -> " & _sessions(session).Name)
                If t.Response <> "" Then Console(session, 110, 180, 220, ExpandInteractionText(t.Response, session, 0, zone))
                If t.Action <> "" Then DispatchGameplayAction(session, sender, t.Action, "zone-" & eventName)
            Next
        End Sub

        Private Sub CheckAvatarProximityBumps(session As Integer, pos As AvatarPosition, sender As AW.Instance)
            For Each kv As KeyValuePair(Of Integer, AvatarPosition) In New List(Of KeyValuePair(Of Integer, AvatarPosition))(_avatarPositions)
                Dim otherSession As Integer = kv.Key
                If otherSession = session OrElse Not _sessions.ContainsKey(otherSession) Then Continue For
                Dim other As AvatarPosition = kv.Value
                Dim dx As Long = CLng(pos.X) - CLng(other.X)
                Dim dy As Long = CLng(pos.Y) - CLng(other.Y)
                Dim dz As Long = CLng(pos.Z) - CLng(other.Z)
                If dx * dx + dy * dy + dz * dz > CLng(AvatarBumpDistance) * CLng(AvatarBumpDistance) Then Continue For

                Dim a As Integer = Math.Min(session, otherSession)
                Dim b As Integer = Math.Max(session, otherSession)
                Dim key As String = a.ToString() & ":" & b.ToString()
                Dim last As DateTime = DateTime.MinValue
                If _avatarBumpCooldowns.TryGetValue(key, last) AndAlso (DateTime.UtcNow - last).TotalSeconds < AvatarBumpCooldownSeconds Then Continue For
                _avatarBumpCooldowns(key) = DateTime.UtcNow

                Dim otherName As String = _sessions(otherSession).Name
                FireAvatarInteractionTriggers("bump", session, otherSession, otherName, sender)
                Exit For
            Next
        End Sub

        Private Sub FireAvatarInteractionTriggers(eventName As String, actorSession As Integer, targetSession As Integer, targetName As String, sender As AW.Instance)
            For Each t As AvatarInteractionTrigger In _avatarInteractionTriggers
                If Not String.Equals(t.EventName, eventName, StringComparison.OrdinalIgnoreCase) Then Continue For
                If t.Target <> "" AndAlso t.Target <> "*" AndAlso Not String.Equals(t.Target, targetName, StringComparison.OrdinalIgnoreCase) Then Continue For
                _log("AVATAR " & eventName.ToUpperInvariant() & " " & _sessions(actorSession).Name & " -> " & targetName)
                If t.Response <> "" Then Console(actorSession, 120, 180, 220, ExpandInteractionText(t.Response, actorSession, targetSession, If(_lastZoneBySession.ContainsKey(actorSession), _lastZoneBySession(actorSession), "")))
                If t.Action <> "" Then DispatchGameplayAction(actorSession, sender, t.Action, "avatar-" & eventName)
            Next
        End Sub

        Private Function ExpandInteractionText(text As String, actorSession As Integer, targetSession As Integer, zone As String) As String
            Dim actorName As String = If(_sessions.ContainsKey(actorSession), _sessions(actorSession).Name, "traveller")
            Dim targetName As String = If(_sessions.ContainsKey(targetSession), _sessions(targetSession).Name, "traveller")
            Return text.Replace("{player}", actorName).Replace("{target}", targetName).Replace("{zone}", zone)
        End Function
    End Class
End Namespace
