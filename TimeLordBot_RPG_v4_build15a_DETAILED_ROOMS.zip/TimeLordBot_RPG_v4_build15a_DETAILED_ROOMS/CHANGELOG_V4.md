﻿# TimeLordBot V4 — Final Complete-RPG Layer

V4 is designed as the final major systems release: new future work should mostly be content, balance and world-building rather than another foundational rewrite.

## Added

- Persistent player species/biodata field.
- Gallifreyan Academy credits, seven ranks, automatic promotions and generated titles.
- Inventory with quantities, consumables, equippable artifacts and skill modifiers.
- Persistent sonic ownership, custom name, casing, emitter, crystal and Mk I-X upgrades.
- Companion roster, active companion, loyalty and skill support.
- Persistent Paradox Index with cross-world travel consequences and stabilization checks.
- Persistent TARDIS room catalogue with functional Medical Bay, Workshop, Library, Cloister Room and Zero Room.
- Xenobiology species catalogue.
- Species templates and special encounter rules for Daleks, Cybermen, Weeping Angels, Sontarans, Judoon, Autons and Time Lords.
- Random encounter loot/components.
- Procedural adventure generator using the existing navigation database.
- Scriptable dialogue nodes, story flags, skill-gated dialogue, reputation changes, mission progress and item rewards.
- Expanded HUD buttons and V4 profile information.

## Integrated

- Equipment, companions, Academy rank, sonic Mk level and paradox now modify the shared V2/V3 skill-check engine.
- Non-lethal enemy resolution receives better Academy progression.
- Cross-world TARDIS travel increments paradox while retaining the V1/V2 no-return-object rule.
- Field encounters automatically catalogue encountered species.
- V4 remains compatible with V3 profiles: missing V4 collections and defaults are initialized lazily.

## Build Fix 3 - HUD contrast + runtime efficiency
- Changed HUD text/buttons to dark ink tones for reliable contrast against the bright parchment texture.
- Increased parchment opacity slightly now that text is rendered above it in dark ink.
- Kept the Active Worlds event pump at 50 ms for responsive SDK events, while throttling RPG state processing to 250 ms (4 Hz).
- Debounced profile serialization to at most once every 2 seconds during active play; disconnect still forces an immediate save.
- Profile writes now serialize to a temporary file before replacing the live XML.
- High-paradox random hazard checks now occur once per 10 seconds rather than once per engine/game tick.
- Operator log automatically trims old text after extended runtimes to keep the Windows Forms UI responsive.


## Build Fix 4 - Correct HUD depth ordering
DeltaWorlds/AW renders lower HUD Z values closer to the viewer. The parchment artwork now uses Z=100, ordinary text Z=5, and clickable labels Z=1. This fixes the parchment washing over otherwise-dark text.

## Build Fix 5 — Final HUD + Operator Console
- Extended the parchment HUD so CLOSE HUD is contained within the scroll.
- Added a full Windows operator dashboard with live connection state, world, uptime, online-player count, stored profiles, unique destinations, active flights, and save state.
- Added an offline/online Time Lord profile inspector with health, hearts, Artron, paradox, Academy rank, TARDIS condition, missions, skills, traits, companions, achievements, and travel totals.
- Added operator buttons for force-save, destination reload, opening the data folder, profile refresh/copy, and clearing the log.
- Added an online-only profile filter and optional log auto-scroll.
- Exposed editable DeltaWorlds authentication host/port fields (defaults remain auth.deltaworlds.com:6671).

## Build Fix 11 - Controlled regeneration and world announcements
- Added 30-entry Doctor regeneration CAV catalog (15 male / 15 female designs).
- Extended RegenerationCavs.txt schema with pool, gender, and design metadata.
- Added one-shot controlled-regeneration selection while preserving random regeneration as the default.
- Added world-wide regeneration console announcement to all tracked player sessions.
- Added cavlist, cavchoose/controlcav, cavclear, controlledregenerate/controlregen commands.
- Added profile persistence for controlled-regeneration state.
- Placeholder CAV definitions are safely rejected until replaced by valid AW_CAV_DEFINITION strings from the browser.

## Build Fix 12 — Live CAV database regeneration
- Replaced all 30 `<CAPTURE_REQUIRED>` controlled Doctor appearances with complete `.awcav` files.
- Added 15 male + 15 female controlled Doctor variants.
- Added a separate 240-entry random regeneration CAV pool so controlled variants do not replace normal random regeneration.
- Added `FILE:` CAV catalog loading, allowing full XML definitions to live in `.awcav` files instead of one-line text records.
- `cavstatus` now reports controlled and random pool readiness separately.
- `reloadcavs` reloads both controlled and random appearance banks.
- Preserved world-wide regeneration announcements with incarnation number and new appearance name.
- CAV components are selected from the supplied DeltaWorlds CAV template data rather than guessed numeric IDs.

## Build Fix 12B - CAV deployment/path resolver
- Fixed random/controlled CAV catalogs reporting Ready 0 when Visual Studio did not copy .awcav subfolders exactly beside the executable.
- FILE: CAV references now resolve beside the catalog, beside the EXE, up through development project parents, and from a flattened output folder as a last resort.
- Adds detailed log output only if a referenced CAV file still cannot be located.
