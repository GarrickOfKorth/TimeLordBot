﻿Imports System
Imports System.Collections.Generic
Imports System.IO

Namespace TimeLordBot
    Public Partial Class TardisBot
        Public ReadOnly Property OperatorHomeWorld As String
            Get
                Return _homeWorld
            End Get
        End Property

        Public ReadOnly Property OnlinePlayerCount As Integer
            Get
                Return _sessions.Count
            End Get
        End Property

        Public ReadOnly Property StoredProfileCount As Integer
            Get
                Return _profiles.Count
            End Get
        End Property

        Public ReadOnly Property ActiveFlightCount As Integer
            Get
                Return _flights.Count
            End Get
        End Property

        Public ReadOnly Property ProfilesHavePendingSave As Boolean
            Get
                Return _profilesDirty
            End Get
        End Property

        Public ReadOnly Property LastProfileSaveUtc As DateTime
            Get
                Return _lastProfileWriteUtc
            End Get
        End Property

        Public ReadOnly Property DestinationCount As Integer
            Get
                Dim seen As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
                For Each d As TardisDestination In _destinations.Values
                    seen.Add(d.Name & "|" & d.WorldName)
                Next
                Return seen.Count
            End Get
        End Property

        Public Function GetProfileNames(Optional onlineOnly As Boolean = False) As List(Of String)
            Dim names As New List(Of String)()
            If onlineOnly Then
                Dim seen As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
                For Each p As PlayerProfile In _sessions.Values
                    If p IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(p.Name) AndAlso seen.Add(p.Name) Then
                        names.Add(p.Name)
                    End If
                Next
            Else
                For Each p As PlayerProfile In _profiles.Values
                    If p IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(p.Name) Then names.Add(p.Name)
                Next
            End If
            names.Sort(StringComparer.OrdinalIgnoreCase)
            Return names
        End Function

        Public Function IsProfileOnline(profileName As String) As Boolean
            If String.IsNullOrWhiteSpace(profileName) Then Return False
            For Each p As PlayerProfile In _sessions.Values
                If p IsNot Nothing AndAlso String.Equals(p.Name, profileName, StringComparison.OrdinalIgnoreCase) Then Return True
            Next
            Return False
        End Function

        Public Function GetProfileSummary(profileName As String) As String
            If String.IsNullOrWhiteSpace(profileName) Then Return "Select a Time Lord profile to inspect."

            Dim p As PlayerProfile = Nothing
            If Not _profiles.TryGetValue(profileName.Trim(), p) OrElse p Is Nothing Then Return "Profile not found."
            EnsureV4Profile(p)

            Dim lines As New List(Of String)()
            lines.Add(p.Name & If(IsProfileOnline(p.Name), "  [ONLINE]", "  [OFFLINE]"))
            lines.Add(New String("="c, Math.Max(12, p.Name.Length + 10)))
            Dim identityLabel As String = p.Species
            If String.IsNullOrWhiteSpace(identityLabel) Then
                If p.IsTimeLord Then
                    identityLabel = "Time Lord"
                Else
                    identityLabel = "Unknown"
                End If
            End If
            lines.Add("Identity: " & identityLabel & " | " & p.Title)
            lines.Add("Incarnation: " & p.Incarnation.ToString() & " | Regenerations remaining: " & p.RegenerationsRemaining.ToString())
            lines.Add("Health: " & p.Health.ToString() & "/" & p.MaxHealth.ToString() & " | Hearts: " & p.HeartOneHealth.ToString() & "/" & p.HeartTwoHealth.ToString())
            lines.Add("Artron: " & p.ArtronReserve.ToString() & "/" & p.MaxArtronReserve.ToString() & " | Paradox: " & p.ParadoxLevel.ToString() & "/100")
            lines.Add("Academy: " & p.AcademyRank & " (" & p.AcademyCredits.ToString() & " credits)")
            lines.Add("TARDIS: Hull " & p.TardisHull.ToString() & " | Temporal " & p.TardisTemporalIntegrity.ToString() & " | Power " & p.TardisPower.ToString())
            lines.Add("Flights: " & p.FlightsCompleted.ToString() & " | Perfect landings: " & p.PerfectLandings.ToString() & " | Missions: " & p.MissionsCompleted.ToString())
            lines.Add("Enemies neutralized: " & p.EnemiesDefeated.ToString() & " | Lives saved: " & p.LivesSaved.ToString())
            lines.Add("Discoveries: " & If(p.Discoveries Is Nothing, 0, p.Discoveries.Count).ToString() & " | Achievements: " & If(p.Achievements Is Nothing, 0, p.Achievements.Count).ToString())
            lines.Add("HUD: " & If(p.HudEnabled, "ON", "OFF") & " | Sonic: " & p.SonicName & " Mk " & p.SonicUpgradeLevel.ToString() & " [" & p.SonicMode & "]")

            Dim activeStatuses As New List(Of String)()
            If p.StatusEffects IsNot Nothing Then
                For Each s As ActiveStatus In p.StatusEffects
                    activeStatuses.Add(s.Name & " (" & Math.Max(0, CInt(Math.Ceiling((s.ExpiresUtc - DateTime.UtcNow).TotalSeconds))).ToString() & "s)")
                Next
            End If
            lines.Add("Status effects: " & If(activeStatuses.Count = 0, "None", String.Join(", ", activeStatuses.ToArray())))

            Dim activeMissions As New List(Of String)()
            If p.Missions IsNot Nothing Then
                For Each m As MissionProgress In p.Missions
                    If String.Equals(m.Status, "active", StringComparison.OrdinalIgnoreCase) Then
                        activeMissions.Add(m.Title & " " & m.Current.ToString() & "/" & m.Required.ToString())
                    End If
                Next
            End If
            lines.Add("Active missions: " & If(activeMissions.Count = 0, "None", String.Join("; ", activeMissions.ToArray())))

            Dim skillParts As New List(Of String)()
            If p.Skills IsNot Nothing Then
                For Each s As SkillProgress In p.Skills
                    skillParts.Add(s.Name & " " & Math.Round(s.Value, 1).ToString("0.0"))
                Next
            End If
            lines.Add("")
            lines.Add("SKILLS")
            lines.Add(If(skillParts.Count = 0, "No skill data yet.", String.Join(" | ", skillParts.ToArray())))

            Dim traits As String = If(p.IncarnationTraits Is Nothing OrElse p.IncarnationTraits.Count = 0, "None", String.Join(", ", p.IncarnationTraits.ToArray()))
            lines.Add("")
            lines.Add("Incarnation traits: " & traits)

            Dim companionNames As New List(Of String)()
            If p.Companions IsNot Nothing Then
                For Each c As CompanionRecord In p.Companions
                    companionNames.Add(c.Name & If(c.Active, " *", ""))
                Next
            End If
            lines.Add("Companions: " & If(companionNames.Count = 0, "None", String.Join(", ", companionNames.ToArray())))

            Return String.Join(Environment.NewLine, lines.ToArray())
        End Function

        Public Sub ForceSaveProfilesForOperator()
            SaveProfiles(True)
        End Sub

        Public Function ReloadDestinationsForOperator() As Integer
            LoadDestinations()
            Return DestinationCount
        End Function

        Public Function GetDataFolder() As String
            Return AppDomain.CurrentDomain.BaseDirectory
        End Function


        Public Function GetEditableProfileFields(profileName As String) As Dictionary(Of String, String)
            Dim result As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)
            Dim p As PlayerProfile = Nothing
            If String.IsNullOrWhiteSpace(profileName) OrElse Not _profiles.TryGetValue(profileName.Trim(), p) OrElse p Is Nothing Then Return result
            EnsureV4Profile(p)
            result("Name") = p.Name
            result("Species") = p.Species
            result("Title") = p.Title
            result("IsTimeLord") = p.IsTimeLord.ToString()
            result("IsDead") = p.IsDead.ToString()
            result("Incarnation") = p.Incarnation.ToString()
            result("RegenerationsRemaining") = p.RegenerationsRemaining.ToString()
            result("RegenerationBlocked") = p.RegenerationBlocked.ToString()
            result("Health") = p.Health.ToString()
            result("MaxHealth") = p.MaxHealth.ToString()
            result("HeartOneHealth") = p.HeartOneHealth.ToString()
            result("HeartTwoHealth") = p.HeartTwoHealth.ToString()
            result("ArtronReserve") = p.ArtronReserve.ToString()
            result("MaxArtronReserve") = p.MaxArtronReserve.ToString()
            result("ParadoxLevel") = p.ParadoxLevel.ToString()
            result("AcademyCredits") = p.AcademyCredits.ToString()
            result("AcademyRank") = p.AcademyRank
            result("TardisHull") = p.TardisHull.ToString()
            result("TardisTemporalIntegrity") = p.TardisTemporalIntegrity.ToString()
            result("TardisPower") = p.TardisPower.ToString()
            result("HudEnabled") = p.HudEnabled.ToString()
            result("SonicOwned") = p.SonicOwned.ToString()
            result("SonicName") = p.SonicName
            result("SonicMode") = p.SonicMode
            result("SonicUpgradeLevel") = p.SonicUpgradeLevel.ToString()
            result("SonicCasing") = p.SonicCasing
            result("SonicEmitter") = p.SonicEmitter
            result("SonicCrystal") = p.SonicCrystal
            result("FlightsCompleted") = p.FlightsCompleted.ToString()
            result("PerfectLandings") = p.PerfectLandings.ToString()
            result("EnemiesDefeated") = p.EnemiesDefeated.ToString()
            result("MissionsCompleted") = p.MissionsCompleted.ToString()
            result("LivesSaved") = p.LivesSaved.ToString()
            Return result
        End Function

        Public Function UpdateEditableProfileFields(profileName As String, values As Dictionary(Of String, String)) As String
            Dim p As PlayerProfile = Nothing
            If String.IsNullOrWhiteSpace(profileName) OrElse Not _profiles.TryGetValue(profileName.Trim(), p) OrElse p Is Nothing Then Return "Profile not found."
            EnsureV4Profile(p)
            Dim value As String = ""
            For Each kv As KeyValuePair(Of String, String) In values
                value = If(kv.Value, "").Trim()
                Select Case kv.Key
                    Case "Species" : p.Species = value
                    Case "Title" : p.Title = value
                    Case "IsTimeLord" : p.IsTimeLord = ParseOperatorBool(value, p.IsTimeLord)
                    Case "IsDead" : p.IsDead = ParseOperatorBool(value, p.IsDead)
                    Case "Incarnation" : p.Incarnation = ParseOperatorInt(value, p.Incarnation, 1, 999)
                    Case "RegenerationsRemaining" : p.RegenerationsRemaining = ParseOperatorInt(value, p.RegenerationsRemaining, 0, 999)
                    Case "RegenerationBlocked" : p.RegenerationBlocked = ParseOperatorBool(value, p.RegenerationBlocked)
                    Case "Health" : p.Health = ParseOperatorInt(value, p.Health, 0, Math.Max(1, p.MaxHealth))
                    Case "MaxHealth" : p.MaxHealth = ParseOperatorInt(value, p.MaxHealth, 1, 10000)
                    Case "HeartOneHealth" : p.HeartOneHealth = ParseOperatorInt(value, p.HeartOneHealth, 0, 100)
                    Case "HeartTwoHealth" : p.HeartTwoHealth = ParseOperatorInt(value, p.HeartTwoHealth, 0, 100)
                    Case "ArtronReserve" : p.ArtronReserve = ParseOperatorInt(value, p.ArtronReserve, 0, Math.Max(1, p.MaxArtronReserve))
                    Case "MaxArtronReserve" : p.MaxArtronReserve = ParseOperatorInt(value, p.MaxArtronReserve, 1, 100000)
                    Case "ParadoxLevel" : p.ParadoxLevel = ParseOperatorInt(value, p.ParadoxLevel, 0, 100)
                    Case "AcademyCredits" : p.AcademyCredits = ParseOperatorInt(value, p.AcademyCredits, 0, 1000000)
                    Case "AcademyRank" : p.AcademyRank = value
                    Case "TardisHull" : p.TardisHull = ParseOperatorInt(value, p.TardisHull, 0, 100)
                    Case "TardisTemporalIntegrity" : p.TardisTemporalIntegrity = ParseOperatorInt(value, p.TardisTemporalIntegrity, 0, 100)
                    Case "TardisPower" : p.TardisPower = ParseOperatorInt(value, p.TardisPower, 0, 100)
                    Case "HudEnabled" : p.HudEnabled = ParseOperatorBool(value, p.HudEnabled)
                    Case "SonicOwned" : p.SonicOwned = ParseOperatorBool(value, p.SonicOwned)
                    Case "SonicName" : p.SonicName = value
                    Case "SonicMode" : p.SonicMode = value
                    Case "SonicUpgradeLevel" : p.SonicUpgradeLevel = ParseOperatorInt(value, p.SonicUpgradeLevel, 1, 10)
                    Case "SonicCasing" : p.SonicCasing = value
                    Case "SonicEmitter" : p.SonicEmitter = value
                    Case "SonicCrystal" : p.SonicCrystal = value
                    Case "FlightsCompleted" : p.FlightsCompleted = ParseOperatorInt(value, p.FlightsCompleted, 0, Integer.MaxValue)
                    Case "PerfectLandings" : p.PerfectLandings = ParseOperatorInt(value, p.PerfectLandings, 0, Integer.MaxValue)
                    Case "EnemiesDefeated" : p.EnemiesDefeated = ParseOperatorInt(value, p.EnemiesDefeated, 0, Integer.MaxValue)
                    Case "MissionsCompleted" : p.MissionsCompleted = ParseOperatorInt(value, p.MissionsCompleted, 0, Integer.MaxValue)
                    Case "LivesSaved" : p.LivesSaved = ParseOperatorInt(value, p.LivesSaved, 0, Integer.MaxValue)
                End Select
            Next
            If p.Health > p.MaxHealth Then p.Health = p.MaxHealth
            If p.ArtronReserve > p.MaxArtronReserve Then p.ArtronReserve = p.MaxArtronReserve
            SaveProfiles(True)
            Return "Saved profile " & p.Name & "."
        End Function

        Private Function ParseOperatorInt(text As String, fallback As Integer, minimum As Integer, maximum As Integer) As Integer
            Dim value As Integer
            If Not Integer.TryParse(text, value) Then Return fallback
            Return Math.Max(minimum, Math.Min(maximum, value))
        End Function

        Private Function ParseOperatorBool(text As String, fallback As Boolean) As Boolean
            Dim value As Boolean
            If Boolean.TryParse(text, value) Then Return value
            If text = "1" OrElse String.Equals(text, "yes", StringComparison.OrdinalIgnoreCase) OrElse String.Equals(text, "on", StringComparison.OrdinalIgnoreCase) Then Return True
            If text = "0" OrElse String.Equals(text, "no", StringComparison.OrdinalIgnoreCase) OrElse String.Equals(text, "off", StringComparison.OrdinalIgnoreCase) Then Return False
            Return fallback
        End Function

        Public Function GetEnemyRowsForOperator() As List(Of String())
            EnsureV3Initialized()
            Dim result As New List(Of String())()
            For Each e As EnemyState In _enemies.Values
                result.Add(New String() {e.Key, e.Id, e.Name, e.Species, e.WorldName, e.Health.ToString(), e.MaxHealth.ToString(), e.Defense.ToString(), e.Attack.ToString(), e.AttackDifficulty.ToString(), e.DamageType, e.IsDefeated.ToString(), e.DefeatedBy})
            Next
            Return result
        End Function

        Public Function SaveEnemyRowsForOperator(rows As List(Of String())) As String
            EnsureV3Initialized()
            _enemies.Clear()
            For Each f As String() In rows
                If f Is Nothing OrElse f.Length < 13 OrElse String.IsNullOrWhiteSpace(f(0)) Then Continue For
                Dim e As New EnemyState()
                e.Key = f(0).Trim()
                e.Id = f(1).Trim()
                e.Name = f(2).Trim()
                e.Species = f(3).Trim()
                e.WorldName = f(4).Trim()
                e.Health = ParseOperatorInt(f(5), 40, 0, 100000)
                e.MaxHealth = ParseOperatorInt(f(6), Math.Max(1, e.Health), 1, 100000)
                e.Defense = ParseOperatorInt(f(7), 45, 0, 1000)
                e.Attack = ParseOperatorInt(f(8), 10, 0, 100000)
                e.AttackDifficulty = ParseOperatorInt(f(9), 45, 0, 1000)
                e.DamageType = f(10).Trim()
                e.IsDefeated = ParseOperatorBool(f(11), False)
                e.DefeatedBy = f(12).Trim()
                If e.Health > e.MaxHealth Then e.Health = e.MaxHealth
                _enemies(e.Key) = e
            Next
            SaveEnemyStates()
            Return "Saved " & _enemies.Count.ToString() & " enemy states."
        End Function

        Public Function ReloadInteractionsForOperator() As String
            If String.IsNullOrWhiteSpace(_conversationTriggersPath) Then
                _conversationTriggersPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ConversationTriggers.txt")
                _zoneTriggersPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ZoneTriggers.txt")
                _avatarTriggersPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "AvatarTriggers.txt")
            End If
            LoadConversationTriggers()
            LoadZoneTriggers()
            LoadAvatarInteractionTriggers()
            Return "Conversation " & _conversationTriggers.Count.ToString() & ", zones " & _zoneTriggers.Count.ToString() & ", avatars " & _avatarInteractionTriggers.Count.ToString()
        End Function

        Public Function ReadOperatorDataFile(fileName As String) As String
            Dim safeName As String = System.IO.Path.GetFileName(fileName)
            Dim fullPath As String = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, safeName)
            If Not File.Exists(fullPath) Then Return ""
            Return File.ReadAllText(fullPath)
        End Function

        Public Sub WriteOperatorDataFile(fileName As String, contents As String)
            Dim safeName As String = System.IO.Path.GetFileName(fileName)
            Dim fullPath As String = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, safeName)
            Dim tempPath As String = fullPath & ".tmp"
            File.WriteAllText(tempPath, If(contents, ""))
            If File.Exists(fullPath) Then
                File.Delete(fullPath)
            End If
            File.Move(tempPath, fullPath)
        End Sub

        Public Function ExecuteOperatorAction(profileName As String, action As String) As String
            If String.IsNullOrWhiteSpace(profileName) Then Return "Choose a profile."
            If String.IsNullOrWhiteSpace(action) Then Return "Enter a gameplay action."

            Dim session As Integer = 0
            For Each kv As KeyValuePair(Of Integer, PlayerProfile) In _sessions
                If kv.Value IsNot Nothing AndAlso String.Equals(kv.Value.Name, profileName.Trim(), StringComparison.OrdinalIgnoreCase) Then
                    session = kv.Key
                    Exit For
                End If
            Next
            If session <= 0 Then Return "That profile is offline. GM gameplay actions currently require an online player."

            DispatchGameplayAction(session, _sdk, action.Trim(), "GM")
            _log("GM ACTION -> " & profileName.Trim() & ": " & action.Trim())
            Return "Executed for " & profileName.Trim() & "."
        End Function

        Public Function TestConversationForOperator(spoken As String, zone As String, profileName As String) As String
            If String.IsNullOrWhiteSpace(spoken) Then Return "Enter sample dialogue."
            Dim p As PlayerProfile = Nothing
            If Not String.IsNullOrWhiteSpace(profileName) Then _profiles.TryGetValue(profileName.Trim(), p)

            For Each t As ConversationTrigger In _conversationTriggers
                If t.Pattern = "" Then Continue For
                If t.Zone <> "" AndAlso Not String.Equals(t.Zone, If(zone, ""), StringComparison.OrdinalIgnoreCase) Then Continue For
                If t.RequireFlag <> "" AndAlso (p Is Nothing OrElse Not HasStoryFlag(p, t.RequireFlag)) Then Continue For

                Dim matched As Boolean = False
                Select Case t.Mode
                    Case "contains"
                        matched = spoken.IndexOf(t.Pattern, StringComparison.OrdinalIgnoreCase) >= 0
                    Case "starts", "startswith"
                        matched = spoken.StartsWith(t.Pattern, StringComparison.OrdinalIgnoreCase)
                    Case Else
                        matched = String.Equals(spoken.Trim(), t.Pattern, StringComparison.OrdinalIgnoreCase)
                End Select
                If matched Then
                    Return "MATCH: " & t.Id & Environment.NewLine &
                           "Mode: " & t.Mode & Environment.NewLine &
                           "Pattern: " & t.Pattern & Environment.NewLine &
                           "Zone: " & If(t.Zone = "", "(any)", t.Zone) & Environment.NewLine &
                           "Required flag: " & If(t.RequireFlag = "", "(none)", t.RequireFlag) & Environment.NewLine &
                           "Response: " & t.Response & Environment.NewLine &
                           "Action: " & t.Action
                End If
            Next
            Return "No conversational trigger matched."
        End Function

    End Class
End Namespace
