@echo off
setlocal
cd /d "%~dp0"
title TimeLordBot Watchdog

echo ============================================================
echo TimeLordBot external watchdog
echo ============================================================
echo This launcher restarts TimeLordBot.exe if the process crashes.
echo Press Ctrl+C to stop the watchdog intentionally.
echo.

:loop
if exist STOP_WATCHDOG goto stopped
if not exist TimeLordBot.exe (
  echo [%date% %time%] TimeLordBot.exe was not found in this folder.
  pause
  exit /b 1
)

echo [%date% %time%] Starting TimeLordBot.exe...
start "TimeLordBot" /wait "%~dp0TimeLordBot.exe"
set EXITCODE=%ERRORLEVEL%

echo [%date% %time%] TimeLordBot exited with code %EXITCODE%.
if exist STOP_WATCHDOG goto stopped

echo Restarting in 5 seconds. Press Ctrl+C if you intended to close it.
timeout /t 5 /nobreak >nul
goto loop

:stopped
echo [%date% %time%] STOP_WATCHDOG detected. Watchdog exiting.
del STOP_WATCHDOG >nul 2>&1
endlocal
