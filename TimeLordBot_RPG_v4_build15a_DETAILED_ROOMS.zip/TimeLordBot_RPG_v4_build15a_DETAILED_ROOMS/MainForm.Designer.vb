Namespace TimeLordBot
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
    Partial Class MainForm
        Inherits System.Windows.Forms.Form

        Private components As System.ComponentModel.IContainer
        Friend WithEvents TxtCitizen As System.Windows.Forms.TextBox
        Friend WithEvents TxtPrivilegePassword As System.Windows.Forms.TextBox
        Friend WithEvents TxtBotName As System.Windows.Forms.TextBox
        Friend WithEvents CmbWorld As System.Windows.Forms.ComboBox
        Friend WithEvents TxtAuthHost As System.Windows.Forms.TextBox
        Friend WithEvents TxtAuthPort As System.Windows.Forms.TextBox
        Friend WithEvents BtnLogin As System.Windows.Forms.Button
        Friend WithEvents TxtLog As System.Windows.Forms.TextBox
        Friend WithEvents EventTimer As System.Windows.Forms.Timer
        Friend WithEvents GrpConnection As System.Windows.Forms.GroupBox
        Friend WithEvents GrpRuntime As System.Windows.Forms.GroupBox
        Friend WithEvents GrpProfile As System.Windows.Forms.GroupBox
        Friend WithEvents GrpLog As System.Windows.Forms.GroupBox
        Friend WithEvents CmbProfile As System.Windows.Forms.ComboBox
        Friend WithEvents ChkOnlineOnly As System.Windows.Forms.CheckBox
        Friend WithEvents TxtProfileSummary As System.Windows.Forms.TextBox
        Friend WithEvents BtnRefreshProfile As System.Windows.Forms.Button
        Friend WithEvents BtnCopyProfile As System.Windows.Forms.Button
        Friend WithEvents BtnSaveNow As System.Windows.Forms.Button
        Friend WithEvents BtnReloadDestinations As System.Windows.Forms.Button
        Friend WithEvents BtnOpenDataFolder As System.Windows.Forms.Button
        Friend WithEvents BtnClearLog As System.Windows.Forms.Button
        Friend WithEvents ChkAutoScroll As System.Windows.Forms.CheckBox
        Friend WithEvents LblConnectionValue As System.Windows.Forms.Label
        Friend WithEvents LblWorldValue As System.Windows.Forms.Label
        Friend WithEvents LblUptimeValue As System.Windows.Forms.Label
        Friend WithEvents LblOnlineValue As System.Windows.Forms.Label
        Friend WithEvents LblProfilesValue As System.Windows.Forms.Label
        Friend WithEvents LblDestinationsValue As System.Windows.Forms.Label
        Friend WithEvents LblFlightsValue As System.Windows.Forms.Label
        Friend WithEvents LblSaveValue As System.Windows.Forms.Label

        <System.Diagnostics.DebuggerStepThrough()>
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Me.GrpConnection = New System.Windows.Forms.GroupBox()
            Me.GrpRuntime = New System.Windows.Forms.GroupBox()
            Me.GrpProfile = New System.Windows.Forms.GroupBox()
            Me.GrpLog = New System.Windows.Forms.GroupBox()
            Me.TxtCitizen = New System.Windows.Forms.TextBox()
            Me.TxtPrivilegePassword = New System.Windows.Forms.TextBox()
            Me.TxtBotName = New System.Windows.Forms.TextBox()
            Me.CmbWorld = New System.Windows.Forms.ComboBox()
            Me.TxtAuthHost = New System.Windows.Forms.TextBox()
            Me.TxtAuthPort = New System.Windows.Forms.TextBox()
            Me.BtnLogin = New System.Windows.Forms.Button()
            Me.TxtLog = New System.Windows.Forms.TextBox()
            Me.EventTimer = New System.Windows.Forms.Timer(Me.components)
            Me.CmbProfile = New System.Windows.Forms.ComboBox()
            Me.ChkOnlineOnly = New System.Windows.Forms.CheckBox()
            Me.TxtProfileSummary = New System.Windows.Forms.TextBox()
            Me.BtnRefreshProfile = New System.Windows.Forms.Button()
            Me.BtnCopyProfile = New System.Windows.Forms.Button()
            Me.BtnSaveNow = New System.Windows.Forms.Button()
            Me.BtnReloadDestinations = New System.Windows.Forms.Button()
            Me.BtnOpenDataFolder = New System.Windows.Forms.Button()
            Me.BtnClearLog = New System.Windows.Forms.Button()
            Me.ChkAutoScroll = New System.Windows.Forms.CheckBox()
            Me.LblConnectionValue = New System.Windows.Forms.Label()
            Me.LblWorldValue = New System.Windows.Forms.Label()
            Me.LblUptimeValue = New System.Windows.Forms.Label()
            Me.LblOnlineValue = New System.Windows.Forms.Label()
            Me.LblProfilesValue = New System.Windows.Forms.Label()
            Me.LblDestinationsValue = New System.Windows.Forms.Label()
            Me.LblFlightsValue = New System.Windows.Forms.Label()
            Me.LblSaveValue = New System.Windows.Forms.Label()
            Me.SuspendLayout()

            ' Connection
            Me.GrpConnection.Location = New System.Drawing.Point(12, 12)
            Me.GrpConnection.Size = New System.Drawing.Size(404, 218)
            Me.GrpConnection.Text = "DeltaWorlds Connection"
            AddLabeledControl(Me.GrpConnection, "Citizen Number:", Me.TxtCitizen, 16, 28, 122, 185)
            AddLabeledControl(Me.GrpConnection, "Privilege Password:", Me.TxtPrivilegePassword, 16, 56, 122, 185)
            Me.TxtPrivilegePassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
            AddLabeledControl(Me.GrpConnection, "Bot Name:", Me.TxtBotName, 16, 84, 122, 185)
            Me.TxtBotName.Text = "TimeLord"

            Dim lblWorld As New System.Windows.Forms.Label()
            lblWorld.AutoSize = True : lblWorld.Location = New System.Drawing.Point(16, 115) : lblWorld.Text = "Home World:"
            Me.GrpConnection.Controls.Add(lblWorld)
            Me.CmbWorld.Location = New System.Drawing.Point(138, 111)
            Me.CmbWorld.Size = New System.Drawing.Size(185, 21)
            Me.CmbWorld.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown
            Me.CmbWorld.Items.AddRange(New Object() {"DWMyths"})
            Me.CmbWorld.Text = "DWMyths"
            Me.GrpConnection.Controls.Add(Me.CmbWorld)

            AddLabeledControl(Me.GrpConnection, "Auth Server:", Me.TxtAuthHost, 16, 143, 122, 185)
            Me.TxtAuthHost.Text = "auth.deltaworlds.com"
            AddLabeledControl(Me.GrpConnection, "Auth Port:", Me.TxtAuthPort, 16, 171, 122, 90)
            Me.TxtAuthPort.Text = "6671"
            Me.BtnLogin.Location = New System.Drawing.Point(236, 168)
            Me.BtnLogin.Size = New System.Drawing.Size(150, 27)
            Me.BtnLogin.Text = "Connect"
            Me.BtnLogin.UseVisualStyleBackColor = True
            Me.GrpConnection.Controls.Add(Me.BtnLogin)

            ' Runtime dashboard
            Me.GrpRuntime.Location = New System.Drawing.Point(428, 12)
            Me.GrpRuntime.Size = New System.Drawing.Size(420, 218)
            Me.GrpRuntime.Text = "Live Bot / TARDIS Runtime"
            AddStat(Me.GrpRuntime, "Connection:", Me.LblConnectionValue, 16, 30, "OFFLINE")
            AddStat(Me.GrpRuntime, "World:", Me.LblWorldValue, 216, 30, "DWMyths")
            AddStat(Me.GrpRuntime, "Uptime:", Me.LblUptimeValue, 16, 58, "--:--:--")
            AddStat(Me.GrpRuntime, "Players online:", Me.LblOnlineValue, 216, 58, "0")
            AddStat(Me.GrpRuntime, "Profiles:", Me.LblProfilesValue, 16, 86, "0")
            AddStat(Me.GrpRuntime, "Destinations:", Me.LblDestinationsValue, 216, 86, "0")
            AddStat(Me.GrpRuntime, "Active flights:", Me.LblFlightsValue, 16, 114, "0")
            AddStat(Me.GrpRuntime, "Profile save:", Me.LblSaveValue, 216, 114, "Saved")

            Me.BtnSaveNow.Location = New System.Drawing.Point(16, 157)
            Me.BtnSaveNow.Size = New System.Drawing.Size(118, 27)
            Me.BtnSaveNow.Text = "Save Profiles Now"
            Me.BtnSaveNow.UseVisualStyleBackColor = True
            Me.GrpRuntime.Controls.Add(Me.BtnSaveNow)
            Me.BtnReloadDestinations.Location = New System.Drawing.Point(140, 157)
            Me.BtnReloadDestinations.Size = New System.Drawing.Size(132, 27)
            Me.BtnReloadDestinations.Text = "Reload Destinations"
            Me.BtnReloadDestinations.UseVisualStyleBackColor = True
            Me.GrpRuntime.Controls.Add(Me.BtnReloadDestinations)
            Me.BtnOpenDataFolder.Location = New System.Drawing.Point(278, 157)
            Me.BtnOpenDataFolder.Size = New System.Drawing.Size(124, 27)
            Me.BtnOpenDataFolder.Text = "Open Data Folder"
            Me.BtnOpenDataFolder.UseVisualStyleBackColor = True
            Me.GrpRuntime.Controls.Add(Me.BtnOpenDataFolder)

            ' Profile inspector
            Me.GrpProfile.Location = New System.Drawing.Point(12, 238)
            Me.GrpProfile.Size = New System.Drawing.Size(836, 226)
            Me.GrpProfile.Text = "Time Lord Profile Inspector"
            Dim lblProfile As New System.Windows.Forms.Label()
            lblProfile.AutoSize = True : lblProfile.Location = New System.Drawing.Point(16, 29) : lblProfile.Text = "Profile:"
            Me.GrpProfile.Controls.Add(lblProfile)
            Me.CmbProfile.Location = New System.Drawing.Point(66, 25)
            Me.CmbProfile.Size = New System.Drawing.Size(220, 21)
            Me.CmbProfile.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.GrpProfile.Controls.Add(Me.CmbProfile)
            Me.ChkOnlineOnly.AutoSize = True
            Me.ChkOnlineOnly.Location = New System.Drawing.Point(300, 27)
            Me.ChkOnlineOnly.Text = "Online only"
            Me.GrpProfile.Controls.Add(Me.ChkOnlineOnly)
            Me.BtnRefreshProfile.Location = New System.Drawing.Point(400, 22)
            Me.BtnRefreshProfile.Size = New System.Drawing.Size(92, 27)
            Me.BtnRefreshProfile.Text = "Refresh"
            Me.BtnRefreshProfile.UseVisualStyleBackColor = True
            Me.GrpProfile.Controls.Add(Me.BtnRefreshProfile)
            Me.BtnCopyProfile.Location = New System.Drawing.Point(498, 22)
            Me.BtnCopyProfile.Size = New System.Drawing.Size(106, 27)
            Me.BtnCopyProfile.Text = "Copy Summary"
            Me.BtnCopyProfile.UseVisualStyleBackColor = True
            Me.GrpProfile.Controls.Add(Me.BtnCopyProfile)
            Me.TxtProfileSummary.Location = New System.Drawing.Point(16, 58)
            Me.TxtProfileSummary.Multiline = True
            Me.TxtProfileSummary.ReadOnly = True
            Me.TxtProfileSummary.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
            Me.TxtProfileSummary.Font = New System.Drawing.Font("Consolas", 9.0!)
            Me.TxtProfileSummary.Size = New System.Drawing.Size(802, 150)
            Me.TxtProfileSummary.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.GrpProfile.Controls.Add(Me.TxtProfileSummary)

            ' Log
            Me.GrpLog.Location = New System.Drawing.Point(12, 472)
            Me.GrpLog.Size = New System.Drawing.Size(836, 210)
            Me.GrpLog.Text = "Bot Event Log"
            Me.ChkAutoScroll.AutoSize = True
            Me.ChkAutoScroll.Checked = True
            Me.ChkAutoScroll.CheckState = System.Windows.Forms.CheckState.Checked
            Me.ChkAutoScroll.Location = New System.Drawing.Point(16, 25)
            Me.ChkAutoScroll.Text = "Auto-scroll"
            Me.GrpLog.Controls.Add(Me.ChkAutoScroll)
            Me.BtnClearLog.Location = New System.Drawing.Point(718, 19)
            Me.BtnClearLog.Size = New System.Drawing.Size(100, 27)
            Me.BtnClearLog.Text = "Clear Log"
            Me.BtnClearLog.UseVisualStyleBackColor = True
            Me.GrpLog.Controls.Add(Me.BtnClearLog)
            Me.TxtLog.Location = New System.Drawing.Point(16, 52)
            Me.TxtLog.Multiline = True
            Me.TxtLog.ReadOnly = True
            Me.TxtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
            Me.TxtLog.Size = New System.Drawing.Size(802, 140)
            Me.TxtLog.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) Or System.Windows.Forms.AnchorStyles.Left) Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.GrpLog.Controls.Add(Me.TxtLog)

            Me.EventTimer.Interval = 50

            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(860, 694)
            Me.MinimumSize = New System.Drawing.Size(876, 733)
            Me.Controls.Add(Me.GrpConnection)
            Me.Controls.Add(Me.GrpRuntime)
            Me.Controls.Add(Me.GrpProfile)
            Me.Controls.Add(Me.GrpLog)
            Me.Name = "MainForm"
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.Text = "Time Lord / TARDIS Bot — Operator Console"
            Me.ResumeLayout(False)
        End Sub

        Private Sub AddLabeledControl(parent As System.Windows.Forms.Control, labelText As String, control As System.Windows.Forms.Control, labelX As Integer, y As Integer, controlX As Integer, controlWidth As Integer)
            Dim lbl As New System.Windows.Forms.Label()
            lbl.AutoSize = True
            lbl.Location = New System.Drawing.Point(labelX, y + 4)
            lbl.Text = labelText
            parent.Controls.Add(lbl)
            control.Location = New System.Drawing.Point(controlX, y)
            control.Size = New System.Drawing.Size(controlWidth, 20)
            parent.Controls.Add(control)
        End Sub

        Private Sub AddStat(parent As System.Windows.Forms.Control, labelText As String, valueLabel As System.Windows.Forms.Label, x As Integer, y As Integer, initialValue As String)
            Dim lbl As New System.Windows.Forms.Label()
            lbl.AutoSize = True
            lbl.Location = New System.Drawing.Point(x, y)
            lbl.Text = labelText
            parent.Controls.Add(lbl)
            valueLabel.AutoSize = True
            valueLabel.Location = New System.Drawing.Point(x + 92, y)
            valueLabel.Font = New System.Drawing.Font(valueLabel.Font, System.Drawing.FontStyle.Bold)
            valueLabel.Text = initialValue
            parent.Controls.Add(valueLabel)
        End Sub
    End Class
End Namespace
