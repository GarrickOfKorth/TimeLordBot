﻿Imports System
Imports System.Collections.Generic
Imports System.Threading.Tasks
Imports AW

Namespace TimeLordBot

    Public Class ReadingAnnotation
        Public Property BookId As String = ""
        Public Property Note As String = ""
        Public Property UpdatedUtc As DateTime = DateTime.UtcNow
    End Class

    Public Partial Class TardisBot

        Private _quietReadingEventEndsUtc As DateTime = DateTime.MinValue
        Private _quietReadingMultiplier As Integer = 2

        Private Sub ConfigureAdvancedReading(entry As ReadingEntry)
            entry.Rarity = "Common"
            entry.Series = ""
            entry.SeriesIndex = 0
            entry.RequiresFlag = ""
            entry.KnowledgeFlag = ""
            entry.Reliability = "ordinary"
            entry.Dangerous = False
            entry.HasChoice = False

            Select Case entry.Id.ToLowerInvariant()
                Case "dw001"
                    entry.Rarity = "Uncommon" : entry.Series = "Doctor's Ethics" : entry.SeriesIndex = 1
                    entry.KnowledgeFlag = "KNOW_MERCY_PROTOCOL" : entry.HasChoice = True
                Case "dw002"
                    entry.Rarity = "Common" : entry.Series = "Doctor's Ethics" : entry.SeriesIndex = 2
                    entry.KnowledgeFlag = "KNOW_COMPANION_PERSPECTIVE"
                Case "dw003"
                    entry.Rarity = "Rare" : entry.Series = "Doctor's Ethics" : entry.SeriesIndex = 3
                    entry.KnowledgeFlag = "KNOW_FIXED_POINT_ETHICS"
                Case "dw004"
                    entry.Rarity = "Uncommon" : entry.KnowledgeFlag = "KNOW_MONSTER_NAMING"
                    entry.Reliability = "contested"
                Case "dw005"
                    entry.Rarity = "Rare" : entry.KnowledgeFlag = "KNOW_DOCTORS_PROMISE"
                    entry.RequiresFlag = "KNOW_MERCY_PROTOCOL"

                Case "td001"
                    entry.Rarity = "Uncommon" : entry.Series = "TARDIS Architecture" : entry.SeriesIndex = 1
                    entry.KnowledgeFlag = "KNOW_DIMENSIONAL_ARCHITECTURE"
                Case "td002"
                    entry.Rarity = "Common" : entry.Series = "TARDIS Architecture" : entry.SeriesIndex = 2
                    entry.KnowledgeFlag = "KNOW_DEMATERIALISATION_RHYTHM"
                Case "td003"
                    entry.Rarity = "Rare" : entry.Series = "TARDIS Architecture" : entry.SeriesIndex = 3
                    entry.KnowledgeFlag = "KNOW_TELEPATHIC_CIRCUITS"
                Case "td004"
                    entry.Rarity = "Rare" : entry.Series = "TARDIS Architecture" : entry.SeriesIndex = 4
                    entry.KnowledgeFlag = "KNOW_CLOISTER_PROTOCOL"
                Case "td005"
                    entry.Rarity = "Uncommon" : entry.Series = "TARDIS Architecture" : entry.SeriesIndex = 5
                    entry.KnowledgeFlag = "KNOW_ZERO_ROOM"

                Case "ga001"
                    entry.Rarity = "Uncommon" : entry.Series = "Gallifreyan Physiology" : entry.SeriesIndex = 1
                    entry.KnowledgeFlag = "KNOW_TWO_HEARTS"
                Case "ga002"
                    entry.Rarity = "Rare" : entry.Series = "Gallifreyan Physiology" : entry.SeriesIndex = 2
                    entry.KnowledgeFlag = "KNOW_REGEN_IDENTITY" : entry.HasChoice = True
                Case "ga003"
                    entry.Rarity = "Forbidden" : entry.Series = "Matrix Documents" : entry.SeriesIndex = 1
                    entry.KnowledgeFlag = "SCHISM_ECHO" : entry.Dangerous = True : entry.HasChoice = True
                Case "ga004"
                    entry.Rarity = "Rare" : entry.Series = "Matrix Documents" : entry.SeriesIndex = 2
                    entry.KnowledgeFlag = "KNOW_ARCHIVAL_POWER"
                Case "ga005"
                    entry.Rarity = "Forbidden" : entry.Series = "Matrix Documents" : entry.SeriesIndex = 3
                    entry.KnowledgeFlag = "KNOW_MATRIX_HOME"
                    entry.RequiresFlag = "SCHISM_ECHO"

                Case "my001"
                    entry.Rarity = "Rare" : entry.Series = "Impossible Geography" : entry.SeriesIndex = 1
                    entry.KnowledgeFlag = "KNOW_SECOND_MOON"
                Case "my002"
                    entry.Rarity = "Uncommon" : entry.KnowledgeFlag = "KNOW_UNNAMED_LIGHT"
                Case "my003"
                    entry.Rarity = "Rare" : entry.Series = "Impossible Geography" : entry.SeriesIndex = 2
                    entry.KnowledgeFlag = "KNOW_UNTAKEN_ROADS" : entry.HasChoice = True
                Case "my004"
                    entry.Rarity = "Uncommon" : entry.KnowledgeFlag = "KNOW_UNFINISHED_BRIDGES"
                Case "my005"
                    entry.Rarity = "Rare" : entry.Series = "Impossible Geography" : entry.SeriesIndex = 3
                    entry.KnowledgeFlag = "KNOW_SLEEPING_MAP"

                Case "ko001"
                    entry.Rarity = "Common" : entry.Series = "Korth Histories" : entry.SeriesIndex = 1
                    entry.KnowledgeFlag = "KNOW_OLD_KORTH"
                Case "ko002"
                    entry.Rarity = "Uncommon" : entry.Series = "Korth Histories" : entry.SeriesIndex = 2
                    entry.KnowledgeFlag = "KNOW_WAITING_RUNE"
                Case "ko003"
                    entry.Rarity = "Uncommon" : entry.KnowledgeFlag = "KNOW_SMALL_MIRACLES"
                Case "ko004"
                    entry.Rarity = "Rare" : entry.Series = "Korth Histories" : entry.SeriesIndex = 3
                    entry.KnowledgeFlag = "KNOW_FOREST_RELATION"
                Case "ko005"
                    entry.Rarity = "Rare" : entry.Series = "Korth Histories" : entry.SeriesIndex = 4
                    entry.KnowledgeFlag = "KNOW_REPEATING_DISASTER"

                Case "lu001"
                    entry.Rarity = "Uncommon" : entry.Series = "Lumina Codex" : entry.SeriesIndex = 1
                    entry.KnowledgeFlag = "LUMINA_LIGHT"
                Case "lu002"
                    entry.Rarity = "Rare" : entry.Series = "Lumina Codex" : entry.SeriesIndex = 2
                    entry.RequiresFlag = "LUMINA_LIGHT" : entry.KnowledgeFlag = "LUMINA_SILENCE" : entry.HasChoice = True
                Case "lu003"
                    entry.Rarity = "Rare" : entry.Series = "Lumina Codex" : entry.SeriesIndex = 3
                    entry.RequiresFlag = "LUMINA_SILENCE" : entry.KnowledgeFlag = "LUMINA_VESSEL"
                Case "lu004"
                    entry.Rarity = "Rare" : entry.Series = "Lumina Codex" : entry.SeriesIndex = 4
                    entry.RequiresFlag = "LUMINA_VESSEL" : entry.KnowledgeFlag = "LUMINA_STAR"
                Case "lu005"
                    entry.Rarity = "Forbidden" : entry.Series = "Lumina Codex" : entry.SeriesIndex = 5
                    entry.RequiresFlag = "LUMINA_STAR" : entry.KnowledgeFlag = "LUMINA_RETURNING"

                Case "sh001"
                    entry.Rarity = "Common" : entry.KnowledgeFlag = "KNOW_FIVE_MINUTES"
                Case "sh002"
                    entry.Rarity = "Common" : entry.KnowledgeFlag = "KNOW_BOUNDARY_DOOR" : entry.HasChoice = True
                Case "sh003"
                    entry.Rarity = "Uncommon" : entry.KnowledgeFlag = "KNOW_INNER_PROSECUTOR"
                Case "sh004"
                    entry.Rarity = "Common" : entry.KnowledgeFlag = "KNOW_REST_MAINTENANCE"
                Case "sh005"
                    entry.Rarity = "Uncommon" : entry.KnowledgeFlag = "KNOW_SOLITUDE_LANGUAGE"

                Case "lost001"
                    entry.Rarity = "Impossible" : entry.Series = "Fragment Archive" : entry.SeriesIndex = 1
                    entry.RequiresFlag = "LOST_TEXT_UNLOCKED"
                    entry.KnowledgeFlag = "KNOW_CREVICE_BETWEEN_STORIES"
                    entry.Dangerous = True : entry.HasChoice = True
            End Select
        End Sub

        Private Function HasReadingKnowledge(p As PlayerProfile, flag As String) As Boolean
            EnsureContemplationProfile(p)
            If String.IsNullOrWhiteSpace(flag) Then Return True
            For Each s As String In p.ReadingKnowledge
                If String.Equals(s, flag, StringComparison.OrdinalIgnoreCase) Then Return True
            Next
            Return False
        End Function

        Private Sub GrantReadingKnowledge(session As Integer, p As PlayerProfile, entry As ReadingEntry)
            If String.IsNullOrWhiteSpace(entry.KnowledgeFlag) Then Return
            If HasReadingKnowledge(p, entry.KnowledgeFlag) Then Return
            p.ReadingKnowledge.Add(entry.KnowledgeFlag)
            Console(session, 155, 110, 210,
                    "KNOWLEDGE ACQUIRED | " & entry.KnowledgeFlag.Replace("_", " "))
            Console(session, 110, 120, 170,
                    "Something from the text has entered the way you understand the world.")
        End Sub

        Private Function CanOpenAdvancedReading(p As PlayerProfile, entry As ReadingEntry, ByRef reason As String) As Boolean
            reason = ""
            If entry Is Nothing Then Return False

            If entry.RequiresFlag <> "" AndAlso Not HasReadingKnowledge(p, entry.RequiresFlag) Then
                reason = "The text will not fully resolve for you yet. Required insight: " &
                         entry.RequiresFlag.Replace("_", " ")
                Return False
            End If

            If entry.Id.Equals("lost001", StringComparison.OrdinalIgnoreCase) AndAlso
               Not HasReadingKnowledge(p, "LOST_TEXT_UNLOCKED") Then
                reason = "Only three fragments and a very bad idea can make this text exist."
                Return False
            End If

            Return True
        End Function

        Private Function ReadingRarityPrefix(entry As ReadingEntry) As String
            Select Case entry.Rarity.ToLowerInvariant()
                Case "uncommon" : Return "◇ "
                Case "rare" : Return "◆ "
                Case "forbidden" : Return "⚠ "
                Case "impossible" : Return "∞ "
                Case Else : Return ""
            End Select
        End Function

        Private Function LatestReadIncarnation(p As PlayerProfile, bookId As String) As Integer
            EnsureContemplationProfile(p)
            For Each j As ReadingJournalEntry In p.ReadingJournal
                If String.Equals(j.BookId, bookId, StringComparison.OrdinalIgnoreCase) Then
                    Return j.Incarnation
                End If
            Next
            Return 0
        End Function

        Private Function CountReadCategory(p As PlayerProfile, category As String) As Integer
            Dim count As Integer = 0
            For Each id As String In p.BooksRead
                Dim e As ReadingEntry = Nothing
                If _readingArchive.TryGetValue(id, e) AndAlso String.Equals(e.Category, category, StringComparison.OrdinalIgnoreCase) Then count += 1
            Next
            Return count
        End Function

        Private Function DetermineReaderArchetype(p As PlayerProfile) As String
            Dim best As String = "Wanderer"
            Dim bestCount As Integer = 0
            Dim map As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase) From {
                {"Doctor Who", "Ethicist"},
                {"TARDIS", "Console Scholar"},
                {"Gallifrey", "Matrix Archivist"},
                {"DWMyths", "Mythographer"},
                {"Korth", "Korthic Antiquarian"},
                {"Lumina Codex", "Luminarist"},
                {"Self-Help", "Inner Cartographer"}
            }
            For Each kv As KeyValuePair(Of String, String) In map
                Dim c As Integer = CountReadCategory(p, kv.Key)
                If c > bestCount Then
                    bestCount = c
                    best = kv.Value
                End If
            Next
            If p.BooksRead.Count >= 25 Then best = "Living Library"
            If p.ReadingMarginalia.Count >= 10 Then best = "Reader of Margins"
            If HasReadingKnowledge(p, "KNOW_CREVICE_BETWEEN_STORIES") Then best = "Impossible Librarian"
            Return best
        End Function

        Private Sub RefreshReaderArchetype(session As Integer, p As PlayerProfile)
            Dim nextValue As String = DetermineReaderArchetype(p)
            If p.ReaderArchetype <> nextValue Then
                Dim oldValue As String = p.ReaderArchetype
                p.ReaderArchetype = nextValue
                If oldValue <> "" Then
                    Console(session, 115, 150, 205,
                            "READER ARCHETYPE SHIFT | " & oldValue & " → " & nextValue)
                Else
                    Console(session, 115, 150, 205,
                            "READER ARCHETYPE | " & nextValue)
                End If
            End If
        End Sub

        Private Function ReadingKnowledgeSkillBonus(p As PlayerProfile, skillName As String) As Double
            If p Is Nothing OrElse p.ReadingKnowledge Is Nothing Then Return 0
            Dim bonus As Double = 0

            For Each flag As String In p.ReadingKnowledge
                Select Case flag.ToUpperInvariant()
                    Case "KNOW_MERCY_PROTOCOL", "KNOW_COMPANION_PERSPECTIVE", "KNOW_BOUNDARY_DOOR"
                        If skillName = "Diplomacy" Then bonus += 1.0
                    Case "KNOW_FIXED_POINT_ETHICS", "KNOW_UNTAKEN_ROADS", "KNOW_SLEEPING_MAP"
                        If skillName = "Temporal Science" OrElse skillName = "Navigation" Then bonus += 1.0
                    Case "KNOW_MONSTER_NAMING", "KNOW_FOREST_RELATION"
                        If skillName = "Xenobiology" OrElse skillName = "Investigation" Then bonus += 1.0
                    Case "KNOW_DIMENSIONAL_ARCHITECTURE", "KNOW_CLOISTER_PROTOCOL", "KNOW_UNFINISHED_BRIDGES"
                        If skillName = "Engineering" Then bonus += 1.0
                    Case "KNOW_DEMATERIALISATION_RHYTHM"
                        If skillName = "Piloting" Then bonus += 1.0
                    Case "KNOW_TELEPATHIC_CIRCUITS", "SCHISM_ECHO", "LUMINA_SILENCE", "LUMINA_RETURNING"
                        If skillName = "Psychic" Then bonus += 1.0
                    Case "KNOW_ZERO_ROOM", "KNOW_TWO_HEARTS", "KNOW_REGEN_IDENTITY", "LUMINA_VESSEL", "KNOW_REST_MAINTENANCE"
                        If skillName = "Medicine" Then bonus += 1.0
                    Case "KNOW_ARCHIVAL_POWER", "KNOW_OLD_KORTH", "KNOW_SECOND_MOON"
                        If skillName = "Archaeology" Then bonus += 1.0
                    Case "KNOW_WAITING_RUNE", "KNOW_INNER_PROSECUTOR", "KNOW_REPEATING_DISASTER"
                        If skillName = "Investigation" Then bonus += 1.0
                    Case "KNOW_CREVICE_BETWEEN_STORIES"
                        bonus += 1.0
                End Select
            Next

            Return Math.Min(6.0, bonus)
        End Function

        Private Function ReadingPlaceBonus(entry As ReadingEntry, place As String) As Integer
            If String.IsNullOrWhiteSpace(place) Then Return 0
            Dim p As String = place.ToLowerInvariant()
            If entry.Category = "TARDIS" AndAlso (p.Contains("library") OrElse p.Contains("cloister") OrElse p.Contains("tardis")) Then Return 4
            If entry.Category = "Gallifrey" AndAlso (p.Contains("matrix") OrElse p.Contains("archive") OrElse p.Contains("academy")) Then Return 5
            If entry.Category = "Lumina Codex" AndAlso (p.Contains("altar") OrElse p.Contains("sanctum") OrElse p.Contains("cloister")) Then Return 5
            If entry.Category = "Korth" AndAlso (p.Contains("shrine") OrElse p.Contains("ruin") OrElse p.Contains("korth")) Then Return 4
            If entry.Category = "Self-Help" AndAlso (p.Contains("zero") OrElse p.Contains("garden") OrElse p.Contains("quiet")) Then Return 3
            Return 0
        End Function

        Private Function ReadingChoicePrompt(entry As ReadingEntry) As String
            Select Case entry.Id.ToLowerInvariant()
                Case "dw001"
                    Return "The text asks: when mercy risks future harm, what should guide you?  A) possibility  B) certainty  C) accountability"
                Case "ga002"
                    Return "Which part of regeneration deserves loyalty?  A) the old self  B) the new self  C) the promise between them"
                Case "ga003"
                    Return "The margin asks what you saw in the Schism.  A) terror  B) wonder  C) yourself looking back"
                Case "my003"
                    Return "Would you enter a gallery containing the life you did not choose?  A) yes  B) no  C) only once"
                Case "lu002"
                    Return "Which silence is hardest?  A) noise ending  B) performance ending  C) explanation ending"
                Case "sh002"
                    Return "A boundary is crossed. What comes next?  A) explain more  B) restate the limit  C) disappear"
                Case "lost001"
                    Return "The impossible page asks who owns an unlived life.  A) you  B) time  C) nobody"
                Case Else
                    Return ""
            End Select
        End Function

        Private Function ReadingChoiceOutcome(entry As ReadingEntry, choice As String) As String
            choice = choice.Trim().ToUpperInvariant()
            Select Case entry.Id.ToLowerInvariant()
                Case "dw001"
                    If choice = "A" Then Return "The page approves of possibility, but warns that hope without attention becomes negligence."
                    If choice = "B" Then Return "The page writes back: certainty is often the costume fear wears when given authority."
                    Return "The word accountability darkens on the page. Mercy, it suggests, must remain answerable to consequences."
                Case "ga002"
                    If choice = "A" Then Return "The old self cannot be preserved without becoming a prison."
                    If choice = "B" Then Return "The new self cannot be free by pretending there was no inheritance."
                    Return "The word promise remains after the rest of the paragraph seems to fade."
                Case "ga003"
                    If choice = "A" Then Return "The Schism remembers fear without judging it."
                    If choice = "B" Then Return "Wonder opens like a wound and then like a window."
                    Return "For an instant, the text appears to contain your own handwriting."
                Case "my003"
                    If choice = "A" Then Return "The curator smiles as if this answer has ruined many afternoons."
                    If choice = "B" Then Return "A closed door appears in the margin. It does not look disappointed."
                    Return "The museum accepts conditions. Possibility, apparently, can tolerate boundaries."
                Case "lu002"
                    If choice = "A" Then Return "The Codex calls this the easiest silence and therefore the one most often mistaken for the whole practice."
                    If choice = "B" Then Return "The page becomes uncomfortable in exactly the correct place."
                    Return "The third silence does not answer. That is its answer."
                Case "sh002"
                    If choice = "A" Then Return "The chapter notes that explanations can become applications for permission."
                    If choice = "B" Then Return "The sentence stays short. The boundary survives being understandable rather than persuasive."
                    Return "Distance can protect, but disappearance is not the only door."
                Case "lost001"
                    If choice = "A" Then Return "The page laughs softly at the concept of ownership."
                    If choice = "B" Then Return "Time declines responsibility."
                    Return "Nothing claims the unlived life. Somehow that makes it feel more real."
            End Select
            Return ""
        End Function

        Private Async Function AwaitReadingChoice(session As Integer, st As ActiveReadingSession, entry As ReadingEntry) As Task(Of Boolean)
            st.AwaitingChoice = True
            st.ChoiceResult = ""
            Console(session, 175, 125, 220, "READING CHOICE | " & ReadingChoicePrompt(entry))
            Console(session, 115, 120, 160, "Reply with: choose A | choose B | choose C")

            Dim deadline As DateTime = DateTime.UtcNow.AddSeconds(75)
            While st.AwaitingChoice AndAlso DateTime.UtcNow < deadline
                If st.Cancelled OrElse Not _activeReadings.ContainsKey(session) Then Return False
                Await Task.Delay(500)
            End While

            If st.AwaitingChoice Then
                st.AwaitingChoice = False
                st.ChoiceResult = "C"
                Console(session, 130, 120, 160, "The text takes your silence as an answer.")
            End If

            Dim outcome As String = ReadingChoiceOutcome(entry, st.ChoiceResult)
            If outcome <> "" Then Console(session, 120, 95, 165, outcome)
            Return True
        End Function

        Private Sub SetReadingChoice(session As Integer, choice As String)
            If Not _activeReadings.ContainsKey(session) Then
                Console(session, 140, 120, 160, "READING CHOICE | No open text is waiting for an answer.")
                Return
            End If
            Dim st As ActiveReadingSession = _activeReadings(session)
            If Not st.AwaitingChoice Then
                Console(session, 140, 120, 160, "READING CHOICE | This page is not asking you anything right now.")
                Return
            End If
            choice = choice.Trim().ToUpperInvariant()
            If choice <> "A" AndAlso choice <> "B" AndAlso choice <> "C" Then
                Console(session, 170, 100, 120, "READING CHOICE | Use A, B, or C.")
                Return
            End If
            st.ChoiceResult = choice
            st.AwaitingChoice = False
            Console(session, 105, 160, 195, "You choose " & choice & ".")
        End Sub

        Private Function MarginaliaKey(entry As ReadingEntry) As String
            Return "MARGIN:" & entry.Id.ToLowerInvariant()
        End Function

        Private Function MarginaliaText(entry As ReadingEntry) As String
            Select Case entry.Id.ToLowerInvariant()
                Case "ga003" : Return """This was never a test. They only called it one afterward."""
                Case "td003" : Return """If the ship answers before you ask, consider whether the question belonged to you."""
                Case "td004" : Return """The bell rang once for a danger that had already happened."""
                Case "dw001" : Return """Mercy without memory is just repetition."""
                Case "dw004" : Return """Ask the monster who taught you its name."""
                Case "my003" : Return """Possibility is not accusation."""
                Case "ko002" : Return """WAIT was the activation word."""
                Case "ko005" : Return """Fourth fire. Same invitation."""
                Case "lu002" : Return """The third silence cannot be performed."""
                Case "lu005" : Return """Do not return unchanged merely to make others comfortable."""
                Case "sh003" : Return """Objection: the witness is also the prosecutor."""
                Case "sh005" : Return """Alone is a room. Abandoned is a verdict."""
                Case "lost001" : Return """There is a crevice between the story lived and the story remembered. Do not widen it."""
                Case Else : Return """A previous reader has underlined one sentence twice and explained nothing."""
            End Select
        End Function

        Private Sub TryDiscoverMarginalia(session As Integer, p As PlayerProfile, entry As ReadingEntry, passageIndex As Integer)
            If passageIndex < 1 Then Return
            Dim key As String = MarginaliaKey(entry)
            For Each existing As String In p.ReadingMarginalia
                If String.Equals(existing, key, StringComparison.OrdinalIgnoreCase) Then Return
            Next

            Dim chance As Integer = Math.Min(70, 18 + CInt(Math.Round(p.ReadingSkill / 2.0)))
            If entry.Rarity = "Rare" Then chance += 8
            If entry.Rarity = "Forbidden" OrElse entry.Rarity = "Impossible" Then chance += 15
            If _rng.Next(1, 101) > chance Then Return

            p.ReadingMarginalia.Add(key)
            p.ReflectionPoints += 3
            Console(session, 190, 120, 220, "MARGINALIA DISCOVERED")
            Console(session, 145, 105, 190, MarginaliaText(entry))
            Console(session, 110, 150, 180, "Reflection +3 | The margin is now recorded in your journal.")

            Select Case entry.Id.ToLowerInvariant()
                Case "my003"
                    GrantFragment(session, p, "FRAGMENT_CLOCK", "a fragment shaped like a clock with no hands")
                Case "ko005"
                    GrantFragment(session, p, "FRAGMENT_ASH", "a brittle strip smelling faintly of old smoke")
                Case "lu005"
                    GrantFragment(session, p, "FRAGMENT_MIRROR", "a silvered fragment that reflects text instead of faces")
            End Select
        End Sub

        Private Sub GrantFragment(session As Integer, p As PlayerProfile, flag As String, description As String)
            If HasReadingKnowledge(p, flag) Then Return
            p.ReadingKnowledge.Add(flag)
            Console(session, 220, 160, 90, "TEXT FRAGMENT FOUND | " & description)
            If HasReadingKnowledge(p, "FRAGMENT_CLOCK") AndAlso
               HasReadingKnowledge(p, "FRAGMENT_ASH") AndAlso
               HasReadingKnowledge(p, "FRAGMENT_MIRROR") AndAlso
               Not HasReadingKnowledge(p, "LOST_TEXT_UNLOCKED") Then
                p.ReadingKnowledge.Add("LOST_TEXT_UNLOCKED")
                Console(session, 230, 110, 180, "IMPOSSIBLE TEXT UNLOCKED | lost001 — The Crevice Between Stories")
                Console(session, 150, 100, 170, "Three unrelated fragments insist they have always been the same book.")
            End If
        End Sub

        Private Sub EmitDynamicReadingInterlude(session As Integer, p As PlayerProfile, entry As ReadingEntry)
            If entry.Category = "Gallifrey" AndAlso p.Incarnation > 1 Then
                Console(session, 105, 120, 170,
                        "The passage lands differently in Incarnation " & p.Incarnation.ToString() & ".")
            End If
            If entry.Tags.IndexOf("regeneration", StringComparison.OrdinalIgnoreCase) >= 0 AndAlso p.RegenerationsRemaining <= 2 Then
                Console(session, 190, 110, 130,
                        "With only " & p.RegenerationsRemaining.ToString() &
                        " regenerations remaining, the chapter no longer feels theoretical.")
            End If
            If entry.Tags.IndexOf("companions", StringComparison.OrdinalIgnoreCase) >= 0 AndAlso p.Companions IsNot Nothing AndAlso p.Companions.Count > 0 Then
                Console(session, 105, 135, 175,
                        "You think of " & p.Companions.Count.ToString() & " companion" &
                        If(p.Companions.Count = 1, "", "s") & " currently written into your life.")
            End If
            If entry.Category = "TARDIS" AndAlso p.TardisHull < 60 Then
                Console(session, 200, 130, 90,
                        "The repair notes feel less academic while your TARDIS hull sits at " &
                        p.TardisHull.ToString() & "%.")
            End If
            If entry.Id = "sh004" AndAlso HasStatus(p, "regeneration sickness") Then
                Console(session, 165, 115, 150,
                        "The line about maintenance becomes almost comically specific.")
            End If
        End Sub

        Private Sub RunReadingInterpretationCheck(session As Integer, p As PlayerProfile, entry As ReadingEntry, st As ActiveReadingSession)
            Dim difficulty As Integer = 25
            If entry.Rarity = "Rare" Then difficulty = 38
            If entry.Rarity = "Forbidden" Then difficulty = 52
            If entry.Rarity = "Impossible" Then difficulty = 65

            Dim check As SkillCheckResult = PerformSkillCheck(p, entry.Skill, difficulty)
            st.InterpretationSucceeded = check.Success
            ReportSkillGain(session, entry.Skill, check)

            If check.Success Then
                Console(session, 95, 180, 155,
                        "DEEP READING | " & entry.Skill & " " & check.Roll.ToString() & "/" &
                        check.Target.ToString() & " — a second meaning resolves beneath the first.")
                If entry.Id = "ga003" AndAlso Not HasReadingKnowledge(p, "SCHISM_ECHO") Then
                    Console(session, 145, 100, 190, "For an instant the prose seems to be reading you back.")
                End If
            Else
                Console(session, 170, 120, 110,
                        "PARTIAL READING | " & entry.Skill & " " & check.Roll.ToString() & "/" &
                        check.Target.ToString() & " — the passage remains suggestive rather than settled.")
                If entry.Dangerous Then
                    AddStatus(p, "Psychically Overloaded", 45, 1, "forbidden reading", session)
                    Console(session, 205, 85, 145, "The text leaves a pressure behind your eyes.")
                End If
            End If
        End Sub

        Private Function ReadingContradictionPartner(entry As ReadingEntry) As String
            Select Case entry.Id.ToLowerInvariant()
                Case "dw004" : Return "ko004"
                Case "ko004" : Return "dw004"
                Case "ga004" : Return "my001"
                Case "my001" : Return "ga004"
                Case Else : Return ""
            End Select
        End Function

        Private Sub CheckReadingContradiction(session As Integer, p As PlayerProfile, entry As ReadingEntry)
            Dim partner As String = ReadingContradictionPartner(entry)
            If partner = "" OrElse Not HasRead(p, partner) Then Return
            Dim key As String = entry.Id.ToLowerInvariant() & "+" & partner.ToLowerInvariant()
            Dim reverseKey As String = partner.ToLowerInvariant() & "+" & entry.Id.ToLowerInvariant()
            For Each s As String In p.ReadingContradictions
                If s = key OrElse s = reverseKey Then Return
            Next
            p.ReadingContradictions.Add(key)
            p.ReflectionPoints += 5
            Console(session, 230, 145, 80, "CONTRADICTION LOGGED | Two texts cannot both be entirely correct.")
            Console(session, 120, 140, 170, "Reflection +5 | The archive becomes more interesting when it stops agreeing with itself.")
        End Sub

        Private Sub ApplyReadingConsequences(session As Integer, p As PlayerProfile, entry As ReadingEntry)
            If entry.Rarity = "Forbidden" AndAlso _rng.Next(1, 101) <= 25 Then
                p.ParadoxLevel = Math.Min(100, p.ParadoxLevel + 1)
                Console(session, 210, 90, 170, "FORBIDDEN KNOWLEDGE | Paradox +1. Something has noticed that you know this.")
            ElseIf entry.Rarity = "Impossible" Then
                p.ParadoxLevel = Math.Min(100, p.ParadoxLevel + 2)
                Console(session, 235, 80, 185, "IMPOSSIBLE KNOWLEDGE | Paradox +2. The book closes before you touch it.")
            End If
        End Sub

        Private Sub ReadingMilestones(session As Integer, p As PlayerProfile)
            AddReadingAchievement(session, p, "First Reader", p.BooksRead.Count >= 1)
            AddReadingAchievement(session, p, "One More Chapter", p.BooksCompleted >= 10)
            AddReadingAchievement(session, p, "Archivist", p.BooksRead.Count >= 15)
            AddReadingAchievement(session, p, "The Library Is Alive", p.BooksRead.Count >= 30)
            AddReadingAchievement(session, p, "Read Between the Timelines", p.ReadingMarginalia.Count >= 5)
            AddReadingAchievement(session, p, "Forbidden Shelf", CountForbiddenRead(p) >= 3)
            AddReadingAchievement(session, p, "Impossible Librarian", HasReadingKnowledge(p, "KNOW_CREVICE_BETWEEN_STORIES"))
        End Sub

        Private Function CountForbiddenRead(p As PlayerProfile) As Integer
            Dim n As Integer = 0
            For Each id As String In p.BooksRead
                Dim e As ReadingEntry = Nothing
                If _readingArchive.TryGetValue(id, e) Then
                    If e.Rarity = "Forbidden" OrElse e.Rarity = "Impossible" Then n += 1
                End If
            Next
            Return n
        End Function

        Private Sub AddReadingAchievement(session As Integer, p As PlayerProfile, title As String, condition As Boolean)
            If Not condition Then Return
            For Each a As String In p.Achievements
                If String.Equals(a, title, StringComparison.OrdinalIgnoreCase) Then Return
            Next
            p.Achievements.Add(title)
            Console(session, 235, 175, 70, "ACHIEVEMENT | " & title)
        End Sub

        Private Sub MarkOwned(p As PlayerProfile, entry As ReadingEntry)
            If p.BooksOwned Is Nothing Then p.BooksOwned = New List(Of String)()
            For Each id As String In p.BooksOwned
                If String.Equals(id, entry.Id, StringComparison.OrdinalIgnoreCase) Then Return
            Next
            p.BooksOwned.Add(entry.Id)
        End Sub

        Private Sub ToggleFavoriteReading(session As Integer, id As String)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            Dim e As ReadingEntry = FindReading(id)
            If e Is Nothing Then
                Console(session, 170, 90, 100, "FAVORITE | No text matches '" & id & "'.")
                Return
            End If

            For i As Integer = p.ReadingFavorites.Count - 1 To 0 Step -1
                If String.Equals(p.ReadingFavorites(i), e.Id, StringComparison.OrdinalIgnoreCase) Then
                    p.ReadingFavorites.RemoveAt(i)
                    Console(session, 120, 130, 160, "FAVORITE REMOVED | " & e.Title)
                    SaveProfiles()
                    Return
                End If
            Next

            p.ReadingFavorites.Add(e.Id)
            Console(session, 210, 145, 190, "FAVORITE ADDED | " & e.Title)
            SaveProfiles()
        End Sub

        Private Sub SaveReadingAnnotation(session As Integer, bookId As String, note As String)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            Dim e As ReadingEntry = FindReading(bookId)
            If e Is Nothing Then
                Console(session, 170, 90, 100, "ANNOTATION | No text matches '" & bookId & "'.")
                Return
            End If
            If note.Length > 220 Then note = note.Substring(0, 220)

            For Each a As ReadingAnnotation In p.ReadingAnnotations
                If String.Equals(a.BookId, e.Id, StringComparison.OrdinalIgnoreCase) Then
                    a.Note = note : a.UpdatedUtc = DateTime.UtcNow
                    Console(session, 115, 150, 185, "ANNOTATION UPDATED | " & e.Title)
                    SaveProfiles()
                    Return
                End If
            Next

            p.ReadingAnnotations.Add(New ReadingAnnotation With {.BookId = e.Id, .Note = note, .UpdatedUtc = DateTime.UtcNow})
            Console(session, 115, 150, 185, "ANNOTATION SAVED | " & e.Title)
            SaveProfiles()
        End Sub

        Private Sub ShowReadingCollection(session As Integer)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            RefreshReaderArchetype(session, p)

            Console(session, 100, 165, 205,
                    "READER PROFILE | " & p.ReaderArchetype &
                    " | Owned " & p.BooksOwned.Count.ToString() &
                    " | Unique read " & p.BooksRead.Count.ToString() & "/" & _readingArchive.Count.ToString() &
                    " | Marginalia " & p.ReadingMarginalia.Count.ToString() &
                    " | Knowledge " & p.ReadingKnowledge.Count.ToString())

            Dim categories As String =
                "Doctor Who " & CountReadCategory(p, "Doctor Who").ToString() &
                " | TARDIS " & CountReadCategory(p, "TARDIS").ToString() &
                " | Gallifrey " & CountReadCategory(p, "Gallifrey").ToString() &
                " | DWMyths " & CountReadCategory(p, "DWMyths").ToString() &
                " | Korth " & CountReadCategory(p, "Korth").ToString() &
                " | Lumina " & CountReadCategory(p, "Lumina Codex").ToString() &
                " | Self-Help " & CountReadCategory(p, "Self-Help").ToString()
            Console(session, 105, 135, 175, "COLLECTIONS | " & categories)

            If p.ReadingFavorites.Count > 0 Then
                Console(session, 190, 135, 190, "FAVORITES | " & String.Join(", ", p.ReadingFavorites.ToArray()))
            End If
        End Sub

        Private Sub ShowReadingKnowledge(session As Integer)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            If p.ReadingKnowledge.Count = 0 Then
                Console(session, 130, 130, 170, "KNOWLEDGE | Nothing has lodged deeply enough to change your checks yet.")
                Return
            End If
            Console(session, 125, 115, 185,
                    "KNOWLEDGE | " & String.Join(" | ", p.ReadingKnowledge.ToArray()))
        End Sub

        Private Sub ShowMarginalia(session As Integer)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            If p.ReadingMarginalia.Count = 0 Then
                Console(session, 130, 130, 170, "MARGINALIA | You have not found any hidden notes yet.")
                Return
            End If
            Console(session, 165, 115, 200, "MARGINALIA | " & String.Join(" | ", p.ReadingMarginalia.ToArray()))
        End Sub

        Private Function IsQuietReadingEventActive() As Boolean
            Return DateTime.UtcNow < _quietReadingEventEndsUtc
        End Function

        Private Sub StartQuietReadingEvent(session As Integer, seconds As Integer)
            If seconds < 60 Then seconds = 60
            If seconds > 3600 Then seconds = 3600
            _quietReadingEventEndsUtc = DateTime.UtcNow.AddSeconds(seconds)
            For Each kv As KeyValuePair(Of Integer, PlayerProfile) In _sessions
                Console(kv.Key, 145, 110, 205,
                        "THE LIBRARY FALLS QUIET | Reading reflections are doubled for " &
                        (seconds \ 60).ToString() & " minute(s).")
            Next
        End Sub

        Private Sub MarkSharedReading(session As Integer, st As ActiveReadingSession, entry As ReadingEntry)
            For Each kv As KeyValuePair(Of Integer, ActiveReadingSession) In _activeReadings
                If kv.Key = session Then Continue For
                If String.Equals(kv.Value.BookId, entry.Id, StringComparison.OrdinalIgnoreCase) Then
                    st.SharedReading = True
                    kv.Value.SharedReading = True
                    Console(session, 120, 165, 195, "SHARED READING | Someone else is inside the same text.")
                    Console(kv.Key, 120, 165, 195, "SHARED READING | Another reader has entered " & entry.Title & ".")
                    Exit For
                End If
            Next
        End Sub

        Private Sub BroadcastReadAloudPassage(session As Integer, st As ActiveReadingSession, entry As ReadingEntry, text As String)
            If Not st.ReadAloud Then Return
            Dim speaker As String = _sessions(session).Name
            For Each kv As KeyValuePair(Of Integer, PlayerProfile) In _sessions
                If kv.Key = session Then Continue For
                If Not _avatarPositions.ContainsKey(session) OrElse Not _avatarPositions.ContainsKey(kv.Key) Then Continue For
                Dim a As AvatarPosition = _avatarPositions(session)
                Dim b As AvatarPosition = _avatarPositions(kv.Key)
                If Math.Abs(a.X - b.X) <= 800 AndAlso Math.Abs(a.Y - b.Y) <= 800 AndAlso Math.Abs(a.Z - b.Z) <= 800 Then
                    Console(kv.Key, 125, 150, 190, "READ ALOUD — " & speaker & ": " & text)
                End If
            Next
        End Sub

        Private Sub CheckSeriesCompletion(session As Integer, p As PlayerProfile, seriesName As String)
            If String.IsNullOrWhiteSpace(seriesName) Then Return
            Dim total As Integer = 0
            Dim read As Integer = 0
            For Each e As ReadingEntry In _readingArchive.Values
                If String.Equals(e.Series, seriesName, StringComparison.OrdinalIgnoreCase) Then
                    total += 1
                    If HasRead(p, e.Id) Then read += 1
                End If
            Next
            If total <= 1 OrElse read < total Then Return

            For Each existing As String In p.ReadingSeriesCompleted
                If String.Equals(existing, seriesName, StringComparison.OrdinalIgnoreCase) Then Return
            Next

            p.ReadingSeriesCompleted.Add(seriesName)
            p.ReflectionPoints += 10
            Console(session, 230, 170, 80,
                    "SERIES COMPLETE | " & seriesName & " | Reflection +10")
        End Sub

    End Class
End Namespace
