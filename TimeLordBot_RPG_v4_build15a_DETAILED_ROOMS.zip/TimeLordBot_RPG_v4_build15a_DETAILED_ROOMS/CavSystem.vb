﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Reflection
Imports AW

Namespace TimeLordBot

    Public Class RegenerationCavPreset

        Public Property Name As String = ""
        Public Property Pool As String = "BOTH"
        Public Property Gender As String = ""
        Public Property Design As String = ""
        Public Property Definition As String = ""

        Public Function IsReady() As Boolean
            Return Not String.IsNullOrWhiteSpace(Definition) AndAlso Not Definition.StartsWith("<CAPTURE_REQUIRED", StringComparison.OrdinalIgnoreCase)
        End Function

        Public Function AllowsRandom() As Boolean
            Dim p As String = If(Pool, "BOTH").Trim().ToUpperInvariant()
            Return p = "BOTH" OrElse p = "RANDOM"
        End Function

        Public Function AllowsControlled() As Boolean
            Dim p As String = If(Pool, "BOTH").Trim().ToUpperInvariant()
            Return p = "BOTH" OrElse p = "CONTROL" OrElse p = "CONTROLLED"
        End Function
    End Class

    Public Partial Class TardisBot
        Private ReadOnly _regenerationCavs As New List(Of RegenerationCavPreset)()
        Private ReadOnly _randomRegenerationCavs As New List(Of RegenerationCavPreset)()
        Private _regenerationCavsPath As String = ""
        Private _randomRegenerationCavsPath As String = ""
        Private Const AwCustomAvatarType As Integer = 65534
        Private Const AwAvatarSetTypeFlag As Integer = 2
        Private ReadOnly _pendingCavProbeBySession As New Dictionary(Of Integer, DateTime)()
        Private ReadOnly _lastCapturedCavDefinitionBySession As New Dictionary(Of Integer, String)()
        Private ReadOnly _expectedAppliedCavDefinitionBySession As New Dictionary(Of Integer, String)()
        Private ReadOnly _cavVerificationLabelBySession As New Dictionary(Of Integer, String)()
        Private ReadOnly _pendingCavApplyDefinitionBySession As New Dictionary(Of Integer, String)()
        Private ReadOnly _pendingCavApplyNameBySession As New Dictionary(Of Integer, String)()
        Private ReadOnly _pendingCavApplyCitizenBySession As New Dictionary(Of Integer, Integer)()
        Private ReadOnly _pendingCavApplyDeadlineBySession As New Dictionary(Of Integer, DateTime)()

        Private Sub InitializeCavSystem()
            _regenerationCavsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "RegenerationCavs.txt")
            _randomRegenerationCavsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "RandomRegenerationCavs.txt")
            LoadRegenerationCavs()
        End Sub

        Private Function ResolveCavDefinition(rawDefinition As String, catalogDirectory As String) As String
            Dim value As String = If(rawDefinition, "").Trim()
            If Not value.StartsWith("FILE:", StringComparison.OrdinalIgnoreCase) Then Return value

            Dim relativePath As String = value.Substring(5).Trim()
            If relativePath = "" Then Return ""
            relativePath = relativePath.Replace("\"c, System.IO.Path.DirectorySeparatorChar).Replace("/"c, System.IO.Path.DirectorySeparatorChar)

            Dim candidates As New List(Of String)()
            If System.IO.Path.IsPathRooted(relativePath) Then
                candidates.Add(relativePath)
            Else
                ' Normal deployed layout: catalog + CAV folders beside the EXE.
                candidates.Add(System.IO.Path.Combine(catalogDirectory, relativePath))
                candidates.Add(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath))

                ' Some old-style Visual Studio projects do not preserve wildcard Content subfolders
                ' in bin\Debug/bin\Release. During development also look back toward the project root.
                Dim probe As DirectoryInfo = New DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory)
                For depth As Integer = 1 To 4
                    If probe.Parent Is Nothing Then Exit For
                    probe = probe.Parent
                    candidates.Add(System.IO.Path.Combine(probe.FullName, relativePath))
                Next

                ' Last-resort compatibility: if MSBuild flattened the .awcav files into the output folder,
                ' accept the basename there as well.
                candidates.Add(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, System.IO.Path.GetFileName(relativePath)))
            End If

            Dim seen As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
            For Each candidate As String In candidates
                Dim fullPath As String = System.IO.Path.GetFullPath(candidate)
                If seen.Contains(fullPath) Then Continue For
                seen.Add(fullPath)
                Try
                    If File.Exists(fullPath) Then
                        Dim xml As String = File.ReadAllText(fullPath)
                        If Not String.IsNullOrWhiteSpace(xml) Then Return xml
                    End If
                Catch ex As Exception
                    _log("CAV catalog warning reading " & fullPath & ": " & ex.Message)
                End Try
            Next

            _log("CAV catalog warning: could not resolve FILE:" & relativePath & " from " & catalogDirectory & ". Checked " & String.Join(" ; ", New List(Of String)(seen).ToArray()) )
            Return ""
        End Function

        Private Sub LoadCavCatalog(filePath As String, target As List(Of RegenerationCavPreset), defaultPool As String)
            target.Clear()
            If Not File.Exists(filePath) Then Return

            Dim catalogDirectory As String = System.IO.Path.GetDirectoryName(filePath)
            Try
                For Each raw As String In File.ReadAllLines(filePath)
                    Dim line As String = If(raw, "").Trim()
                    If line = "" OrElse line.StartsWith("#") Then Continue For

                    Dim fields() As String = line.Split("|"c)
                    Dim preset As New RegenerationCavPreset()
                    Dim definitionSource As String = ""

                    If fields.Length >= 5 Then
                        preset.Name = fields(0).Trim()
                        preset.Pool = fields(1).Trim()
                        preset.Gender = fields(2).Trim()
                        preset.Design = fields(3).Trim()
                        definitionSource = String.Join("|", fields, 4, fields.Length - 4).Trim()
                    Else
                        Dim splitAt As Integer = line.IndexOf("|"c)
                        If splitAt > 0 Then
                            preset.Name = line.Substring(0, splitAt).Trim()
                            definitionSource = line.Substring(splitAt + 1).Trim()
                        Else
                            preset.Name = "Regeneration Look " & (target.Count + 1).ToString()
                            definitionSource = line
                        End If
                        preset.Pool = defaultPool
                    End If

                    If String.IsNullOrWhiteSpace(preset.Pool) Then preset.Pool = defaultPool
                    preset.Definition = ResolveCavDefinition(definitionSource, catalogDirectory)
                    If preset.Name <> "" Then target.Add(preset)
                Next
            Catch ex As Exception
                _log("CAV catalog load warning for " & filePath & ": " & ex.Message)
            End Try
        End Sub

        Private Sub LoadRegenerationCavs()
            If String.IsNullOrWhiteSpace(_regenerationCavsPath) Then
                _regenerationCavsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "RegenerationCavs.txt")
            End If
            If String.IsNullOrWhiteSpace(_randomRegenerationCavsPath) Then
                _randomRegenerationCavsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "RandomRegenerationCavs.txt")
            End If

            LoadCavCatalog(_regenerationCavsPath, _regenerationCavs, "CONTROL")
            LoadCavCatalog(_randomRegenerationCavsPath, _randomRegenerationCavs, "RANDOM")

            Dim controlledReady As Integer = _regenerationCavs.FindAll(Function(x) x.IsReady()).Count
            Dim randomReady As Integer = _randomRegenerationCavs.FindAll(Function(x) x.IsReady()).Count
            _log("Loaded controlled regeneration CAV catalog: " & _regenerationCavs.Count.ToString() & " entries (" & controlledReady.ToString() & " ready).")
            _log("Loaded random regeneration CAV pool: " & _randomRegenerationCavs.Count.ToString() & " entries (" & randomReady.ToString() & " ready).")
        End Sub

        Private Function TryGetAwAttribute(name As String, ByRef attr As Attributes) As Boolean
            Try
                attr = DirectCast([Enum].Parse(GetType(Attributes), name, True), Attributes)
                Return True
            Catch
                Return False
            End Try
        End Function

        Private Function TrySetAwInt(attributeName As String, value As Integer) As Boolean
            If _sdk Is Nothing Then Return False
            Dim attr As Attributes
            If Not TryGetAwAttribute(attributeName, attr) Then
                _log("CAV SDK: AW.Core does not expose attribute " & attributeName & ".")
                Return False
            End If
            Try
                _sdk.SetInt(attr, value)
                Return True
            Catch ex As Exception
                _log("CAV SDK: failed setting " & attributeName & ": " & ex.Message)
                Return False
            End Try
        End Function

        Private Function TrySetAwString(attributeName As String, value As String) As Boolean
            If _sdk Is Nothing Then Return False
            Dim attr As Attributes
            If Not TryGetAwAttribute(attributeName, attr) Then
                _log("CAV SDK: AW.Core does not expose attribute " & attributeName & ".")
                Return False
            End If
            Try
                _sdk.SetString(attr, If(value, ""))
                Return True
            Catch ex As Exception
                _log("CAV SDK: failed setting " & attributeName & ": " & ex.Message)
                Return False
            End Try
        End Function

        Private Function ConvertReflectionArgument(value As Object, targetType As Type) As Object
            If value Is Nothing Then Return Nothing
            If targetType.IsInstanceOfType(value) Then Return value
            If targetType.IsEnum Then Return [Enum].ToObject(targetType, Convert.ToInt32(value))
            Return Convert.ChangeType(value, targetType)
        End Function

        Private Function TryInvokeSdk(methodName As String, ByRef result As Object, ParamArray args() As Object) As Boolean
            result = Nothing
            If _sdk Is Nothing Then Return False
            Try
                Dim methods As MethodInfo() = _sdk.GetType().GetMethods(BindingFlags.Public Or BindingFlags.Instance)
                For Each m As MethodInfo In methods
                    If Not String.Equals(m.Name, methodName, StringComparison.OrdinalIgnoreCase) Then Continue For
                    Dim pars As ParameterInfo() = m.GetParameters()
                    If pars.Length <> args.Length Then Continue For
                    Try
                        Dim converted() As Object = New Object() {}
                        If args.Length > 0 Then
                            ReDim converted(args.Length - 1)
                            For i As Integer = 0 To args.Length - 1
                                converted(i) = ConvertReflectionArgument(args(i), pars(i).ParameterType)
                            Next
                        End If
                        result = m.Invoke(_sdk, converted)
                        Return True
                    Catch
                    End Try
                Next
            Catch ex As Exception
                _log("CAV SDK invoke warning for " & methodName & ": " & ex.Message)
            End Try
            Return False
        End Function

        Private Function SdkResultLooksSuccessful(result As Object) As Boolean
            If result Is Nothing Then Return True
            Try
                Return Convert.ToInt32(result) = 0
            Catch
                Return True
            End Try
        End Function

        Private Function GetAvatarCitizenForSession(session As Integer) As Integer
            Dim citizen As Integer = 0
            If _citizenBySession.TryGetValue(session, citizen) Then Return citizen
            Return 0
        End Function

        Private Function LooksLikeAwcavXml(definition As String) As Boolean
            Dim s As String = If(definition, "").TrimStart()
            Return s.StartsWith("<?xml", StringComparison.OrdinalIgnoreCase) OrElse s.StartsWith("<cav", StringComparison.OrdinalIgnoreCase)
        End Function

        Private Sub DumpCavSdkSurface(session As Integer)
            If _sdk Is Nothing Then Return
            Try
                Dim lines As New List(Of String)()
                For Each m As MethodInfo In _sdk.GetType().GetMethods(BindingFlags.Public Or BindingFlags.Instance)
                    If m.Name.IndexOf("Cav", StringComparison.OrdinalIgnoreCase) < 0 AndAlso m.Name.IndexOf("Avatar", StringComparison.OrdinalIgnoreCase) < 0 Then Continue For
                    Dim ps As New List(Of String)()
                    For Each pi As ParameterInfo In m.GetParameters()
                        ps.Add(pi.ParameterType.Name & " " & pi.Name)
                    Next
                    lines.Add(m.ReturnType.Name & " " & m.Name & "(" & String.Join(", ", ps.ToArray()) & ")")
                Next
                lines.Sort(StringComparer.OrdinalIgnoreCase)
                _log("=== CAV SDK SURFACE ===")
                For Each line As String In lines
                    _log(line)
                Next
                _log("=== END CAV SDK SURFACE ===")

                Dim dumpPath As String = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CAV_SDK_SURFACE.txt")
                Dim dumpText As String = "=== CAV SDK SURFACE ===" & Environment.NewLine & _
                    String.Join(Environment.NewLine, lines.ToArray()) & Environment.NewLine & _
                    "=== END CAV SDK SURFACE ===" & Environment.NewLine
                System.IO.File.WriteAllText(dumpPath, dumpText)

                Console(session, 130, 200, 230, "CAV SDK | " & lines.Count.ToString() & " signatures found. Saved to CAV_SDK_SURFACE.txt.")
                For Each line As String In lines
                    Console(session, 150, 210, 235, "CAV SDK | " & line)
                Next
            Catch ex As Exception
                _log("CAV SDK surface dump failed: " & ex.ToString())
            End Try
        End Sub

        Private Sub BeginCavProbe(session As Integer)
            If _sdk Is Nothing OrElse session <= 0 Then Return

            Dim citizen As Integer = GetAvatarCitizenForSession(session)
            If citizen <= 0 Then
                Console(session, 220, 100, 90, "CAV PROBE FAILED | No citizen number is known for your live avatar session yet. Move once or re-enter the world and try again.")
                _log("CAV probe aborted: session " & session.ToString() & " has no mapped citizen number.")
                Return
            End If

            Try
                Dim requestResult As Result = _sdk.CavRequest(citizen, session)
                _log("CAV PROBE | CavRequest(" & citizen.ToString() & ", " & session.ToString() & ") => " & requestResult.ToString())

                If requestResult <> Result.Success Then
                    Console(session, 220, 100, 90, "CAV PROBE REQUEST REJECTED | SDK result " & requestResult.ToString() & ".")
                    Return
                End If

                ' Some AW.Core builds populate GetCavData immediately; others do it after the callback.
                Dim immediate As String = ""
                Try
                    immediate = _sdk.GetCavData()
                Catch ex As Exception
                    _log("CAV PROBE | Immediate GetCavData() raised: " & ex.Message)
                End Try

                If Not String.IsNullOrWhiteSpace(immediate) Then
                    _lastCapturedCavDefinitionBySession(session) = immediate
                    Dim capturePath As String = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CapturedCAVs.txt")
                    Try
                        File.AppendAllText(capturePath, DateTime.UtcNow.ToString("o") & "|session:" & session.ToString() & "|" & immediate & Environment.NewLine)
                    Catch ex As Exception
                        _log("Could not save immediately captured CAV definition: " & ex.Message)
                    End Try
                    Console(session, 100, 220, 150, "CAV PROBE SUCCESS | Live CAV definition captured immediately (" & immediate.Length.ToString() & " chars).")
                    _log("CAV probe captured " & immediate.Length.ToString() & " chars immediately for session " & session.ToString() & ".")
                    Return
                End If

                _pendingCavProbeBySession(session) = DateTime.UtcNow.AddSeconds(10)
                Console(session, 140, 190, 230, "CAV PROBE REQUESTED | CavRequest succeeded. Waiting for DeltaWorlds to return your live CAV definition...")
                _log("CAV probe request accepted for citizen " & citizen.ToString() & ", session " & session.ToString() & ".")
            Catch ex As Exception
                _log("CAV PROBE DIRECT CALL FAILED: " & ex.ToString())
                Console(session, 220, 100, 90, "CAV PROBE FAILED | Direct CavRequest call raised: " & ex.Message)
            End Try
        End Sub

        Private Sub TickCavProbe(now As DateTime)
            If _sdk Is Nothing OrElse _pendingCavProbeBySession.Count = 0 Then Return
            Dim sessions() As Integer = New List(Of Integer)(_pendingCavProbeBySession.Keys).ToArray()
            For Each session As Integer In sessions
                Dim definition As String = ""
                Try
                    definition = _sdk.GetCavData()
                Catch ex As Exception
                    _log("CAV probe GetCavData warning: " & ex.Message)
                End Try

                If String.IsNullOrWhiteSpace(definition) Then
                    Try
                        Dim attr As Attributes
                        If TryGetAwAttribute("CavDefinition", attr) Then definition = _sdk.GetString(attr)
                    Catch ex As Exception
                        _log("CAV probe attribute read warning: " & ex.Message)
                    End Try
                End If

                If Not String.IsNullOrWhiteSpace(definition) AndAlso Not LooksLikeAwcavXml(definition) Then
                    _lastCapturedCavDefinitionBySession(session) = definition
                    _pendingCavProbeBySession.Remove(session)
                    Dim capturePath As String = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CapturedCAVs.txt")
                    Try
                        File.AppendAllText(capturePath, DateTime.UtcNow.ToString("o") & "|session:" & session.ToString() & "|" & definition & Environment.NewLine)
                    Catch ex As Exception
                        _log("Could not save captured CAV definition: " & ex.Message)
                    End Try
                    Console(session, 100, 220, 150, "CAV PROBE SUCCESS | Live protocol definition captured (" & definition.Length.ToString() & " chars). Saved to CapturedCAVs.txt.")
                    _log("CAV PROBE CAPTURED session " & session.ToString() & " length=" & definition.Length.ToString() & " definition=" & definition)
                ElseIf now >= _pendingCavProbeBySession(session) Then
                    _pendingCavProbeBySession.Remove(session)
                    Console(session, 220, 150, 70, "CAV PROBE TIMEOUT | No protocol CAV definition arrived. Run type:cavsdk and send me the operator-log output.")
                End If
            Next
        End Sub

        Private Sub TestCapturedCav(session As Integer)
            Dim definition As String = ""
            If Not _lastCapturedCavDefinitionBySession.TryGetValue(session, definition) OrElse String.IsNullOrWhiteSpace(definition) Then
                Console(session, 200, 150, 80, "No captured live CAV definition is available yet. Run type:cavprobe first.")
                Return
            End If
            ApplyCavDefinitionToPlayer(session, definition, "captured live CAV test")
        End Sub


        Private Function Adler32(data As Byte()) As UInteger
            Const ModAdler As UInteger = 65521UI
            Dim a As UInteger = 1UI
            Dim b As UInteger = 0UI
            For Each value As Byte In data
                a = (a + CUInt(value)) Mod ModAdler
                b = (b + a) Mod ModAdler
            Next
            Return (b << 16) Or a
        End Function

        Private Function MakeZlibPayload(text As String) As Byte()
            Dim input As Byte() = System.Text.Encoding.UTF8.GetBytes(text)
            Dim rawDeflate As Byte()

            Using ms As New MemoryStream()
                Using ds As New System.IO.Compression.DeflateStream(
                    ms, System.IO.Compression.CompressionMode.Compress, True)
                    ds.Write(input, 0, input.Length)
                End Using
                rawDeflate = ms.ToArray()
            End Using

            Dim checksum As UInteger = Adler32(input)

            Using output As New MemoryStream()
                ' RFC1950 zlib header. 78 DA matches the live DeltaWorlds payload observed.
                output.WriteByte(&H78)
                output.WriteByte(&HDA)
                output.Write(rawDeflate, 0, rawDeflate.Length)

                ' Adler-32 trailer is big endian.
                output.WriteByte(CByte((checksum >> 24) And &HFFUI))
                output.WriteByte(CByte((checksum >> 16) And &HFFUI))
                output.WriteByte(CByte((checksum >> 8) And &HFFUI))
                output.WriteByte(CByte(checksum And &HFFUI))

                Return output.ToArray()
            End Using
        End Function

        Private Function TrySetRawCavPayload(definition As String, session As Integer) As Boolean
            Try
                Dim cavAttr As Attributes
                If Not TryGetAwAttribute("CavDefinition", cavAttr) Then
                    _log("CAV RAW WRITE | CavDefinition attribute unavailable.")
                    Return False
                End If

                Dim payload As Byte() = MakeZlibPayload(definition)
                _log("CAV RAW WRITE | Built zlib payload " & payload.Length.ToString() &
                     " bytes from " & definition.Length.ToString() &
                     " chars. Head=" &
                     BitConverter.ToString(payload, 0, Math.Min(payload.Length, 16)))

                Dim methods() As System.Reflection.MethodInfo = _sdk.GetType().GetMethods()
                For Each mi As System.Reflection.MethodInfo In methods
                    If mi.Name <> "SetData" Then Continue For

                    Dim ps() As System.Reflection.ParameterInfo = mi.GetParameters()
                    Dim sig As New System.Text.StringBuilder()
                    sig.Append(mi.ReturnType.Name).Append(" ").Append(mi.Name).Append("(")
                    For i As Integer = 0 To ps.Length - 1
                        If i > 0 Then sig.Append(", ")
                        sig.Append(ps(i).ParameterType.Name).Append(" ").Append(ps(i).Name)
                    Next
                    sig.Append(")")
                    _log("CAV RAW WRITE SDK | " & sig.ToString())

                    If ps.Length = 2 Then
                        Try
                            Dim arg0 As Object = Nothing
                            Dim arg1 As Object = Nothing

                            If ps(0).ParameterType.IsEnum Then
                                arg0 = cavAttr
                            ElseIf ps(0).ParameterType Is GetType(Integer) Then
                                arg0 = CInt(cavAttr)
                            Else
                                Continue For
                            End If

                            If ps(1).ParameterType Is GetType(Byte()) Then
                                arg1 = payload
                            Else
                                Continue For
                            End If

                            mi.Invoke(_sdk, New Object() {arg0, arg1})
                            _log("CAV RAW WRITE | Invoked " & sig.ToString() & " successfully.")
                            If session > 0 AndAlso _sessions.ContainsKey(session) Then
                                Console(session, 110, 220, 160,
                                    "CAV RAW WRITE | Injected " & payload.Length.ToString() &
                                    " zlib bytes through SetData.")
                            End If
                            Return True
                        Catch ex As Exception
                            Dim inner As Exception = If(ex.InnerException, ex)
                            _log("CAV RAW WRITE | SetData invoke failed: " & inner.Message)
                        End Try
                    End If
                Next
            Catch ex As Exception
                _log("CAV RAW WRITE fatal: " & ex.ToString())
            End Try
            Return False
        End Function


        Private Function TrySetCavDefinitionProperty(definition As String, session As Integer) As Boolean
            Try
                Dim p As System.Reflection.PropertyInfo =
                    _sdk.GetType().GetProperty("CavDefinition",
                        System.Reflection.BindingFlags.Public Or
                        System.Reflection.BindingFlags.Instance)

                If p Is Nothing Then
                    _log("CAV PROPERTY WRITE | CavDefinition property was not found on AW.Core.Instance.")
                    Return False
                End If

                _log("CAV PROPERTY WRITE | CavDefinition property type=" &
                     p.PropertyType.FullName &
                     " CanWrite=" & p.CanWrite.ToString())

                If Not p.CanWrite Then Return False

                If p.PropertyType Is GetType(String) Then
                    p.SetValue(_sdk, definition, Nothing)
                    _log("CAV PROPERTY WRITE | Assigned " &
                         definition.Length.ToString() &
                         " XML chars through Instance.CavDefinition.")
                    If session > 0 AndAlso _sessions.ContainsKey(session) Then
                        Console(session, 110, 220, 160,
                            "CAV PROPERTY WRITE | Loaded " &
                            definition.Length.ToString() &
                            " XML chars into CavDefinition.")
                    End If
                    Return True
                End If

                _log("CAV PROPERTY WRITE | Unsupported CavDefinition property type " &
                     p.PropertyType.FullName & ".")
            Catch ex As Exception
                Dim inner As Exception = If(ex.InnerException, ex)
                _log("CAV PROPERTY WRITE FAILED | " & inner.ToString())
                If session > 0 AndAlso _sessions.ContainsKey(session) Then
                    Console(session, 220, 110, 90,
                        "CAV PROPERTY WRITE FAILED | " & inner.Message)
                End If
            End Try
            Return False
        End Function

        Private Function ApplyCavDefinitionToPlayer(session As Integer, definition As String, displayName As String) As Boolean
            If session <= 0 OrElse String.IsNullOrWhiteSpace(definition) OrElse _sdk Is Nothing Then Return False
            If definition.StartsWith("<CAPTURE_REQUIRED", StringComparison.OrdinalIgnoreCase) Then
                Console(session, 220, 150, 70, "CAV catalog entry '" & displayName & "' still needs a usable CAV definition.")
                Return False
            End If

            Dim citizen As Integer = GetAvatarCitizenForSession(session)
            If citizen <= 0 Then
                Console(session, 210, 90, 90, "CAV APPLY FAILED | No citizen number is mapped to your avatar session.")
                Return False
            End If

            _log("CAV APPLY BEGIN | session=" & session.ToString() &
                 " citizen=" & citizen.ToString() &
                 " name=" & displayName &
                 " definitionLength=" & definition.Length.ToString() &
                 " xml=" & LooksLikeAwcavXml(definition).ToString())

            Try
                ' IMPORTANT: CavChange acts on the current AW_CAV_* target context.
                ' Explicitly target the avatar we intend to change before loading/sending
                ' the replacement definition.
                Dim cavCitizenAttr As Attributes
                Dim cavSessionAttr As Attributes

                If Not TryGetAwAttribute("CavCitizen", cavCitizenAttr) OrElse
                   Not TryGetAwAttribute("CavSession", cavSessionAttr) Then
                    Console(session, 210, 90, 90,
                            "CAV APPLY FAILED | This AW.Core build does not expose CavCitizen/CavSession attributes.")
                    Return False
                End If

                _sdk.SetInt(cavCitizenAttr, citizen)
                _sdk.SetInt(cavSessionAttr, session)

                _log("CAV APPLY TARGET | CavCitizen=" & citizen.ToString() &
                     " CavSession=" & session.ToString())

                ' AW.Core exposes a real writable Instance.CavDefinition property.
                ' Use that native property first; previous builds were writing through
                ' helper/raw APIs whose return codes did not change the stored CAV.
                Dim usedPropertyWrite As Boolean = TrySetCavDefinitionProperty(definition, session)

                If Not usedPropertyWrite Then
                    _log("CAV PROPERTY WRITE | Falling back to SetCavData.")
                    _sdk.SetCavData(definition)
                End If

                ' CavChange is asynchronous. Register the pending write BEFORE calling it,
                ' then wait for CallbackCavResult before AvatarSet/reload or verification.
                _pendingCavApplyDefinitionBySession(session) = definition
                _pendingCavApplyNameBySession(session) = displayName
                _pendingCavApplyCitizenBySession(session) = citizen
                _pendingCavApplyDeadlineBySession(session) = DateTime.UtcNow.AddSeconds(2)

                Dim cavResult As Result = _sdk.CavChange()
                _log("CAV APPLY | " &
                     If(usedPropertyWrite, "CavDefinition property", "SetCavData fallback") &
                     " prepared replacement; CavChange immediate result => " & cavResult.ToString())

                If cavResult <> Result.Success Then
                    _pendingCavApplyDefinitionBySession.Remove(session)
                    _pendingCavApplyNameBySession.Remove(session)
                    _pendingCavApplyCitizenBySession.Remove(session)
                    _pendingCavApplyDeadlineBySession.Remove(session)
                    Console(session, 210, 90, 90,
                            "CAV APPLY FAILED | CavChange returned " & cavResult.ToString() & ".")
                    Return False
                End If

                Console(session, 110, 210, 170,
                        "CAV CHANGE REQUESTED | " & displayName &
                        " submitted. Waiting for CallbackCavResult before reloading or verifying.")

                Return True
            Catch ex As Exception
                _log("CAV APPLY EXCEPTION | " & ex.ToString())
                Console(session, 210, 90, 90,
                        "CAV APPLY FAILED | " & ex.Message)
                Return False
            End Try
        End Function

        Private Function FindCavPreset(name As String, controlledOnly As Boolean) As RegenerationCavPreset
            If String.IsNullOrWhiteSpace(name) Then Return Nothing
            Dim q As String = name.Trim()
            For Each p As RegenerationCavPreset In _regenerationCavs
                If controlledOnly AndAlso Not p.AllowsControlled() Then Continue For
                If String.Equals(p.Name, q, StringComparison.OrdinalIgnoreCase) Then Return p
            Next
            For Each p As RegenerationCavPreset In _regenerationCavs
                If controlledOnly AndAlso Not p.AllowsControlled() Then Continue For
                If p.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0 Then Return p
            Next
            Return Nothing
        End Function

        Private Sub PersistCavChoice(p As PlayerProfile, chosen As RegenerationCavPreset)
            p.CurrentCavName = chosen.Name
            p.CurrentCavDefinition = chosen.Definition
            p.CurrentCavIncarnation = p.Incarnation
            If p.IncarnationHistory.Count > 0 Then
                Dim current As IncarnationRecord = p.IncarnationHistory(p.IncarnationHistory.Count - 1)
                current.CavName = chosen.Name
                current.CavDefinition = chosen.Definition
            End If
        End Sub

        Private Function ApplyRandomRegenerationCav(session As Integer, p As PlayerProfile) As Boolean
            Dim candidates As List(Of RegenerationCavPreset) = _randomRegenerationCavs.FindAll(Function(x) x.AllowsRandom() AndAlso x.IsReady())
            If candidates.Count = 0 Then
                _log("CAV regeneration skipped for " & p.Name & ": the random regeneration CAV pool contains no live definitions.")
                Console(session, 220, 150, 70, "Random regeneration appearance pool is unavailable. Your regeneration will continue without a forced CAV change.")
                Return False
            End If

            If candidates.Count > 1 AndAlso Not String.IsNullOrWhiteSpace(p.CurrentCavDefinition) Then
                candidates.RemoveAll(Function(x) String.Equals(x.Definition, p.CurrentCavDefinition, StringComparison.Ordinal))
                If candidates.Count = 0 Then candidates = _randomRegenerationCavs.FindAll(Function(x) x.AllowsRandom() AndAlso x.IsReady())
            End If

            Dim chosen As RegenerationCavPreset = candidates(_rng.Next(candidates.Count))
            If Not ApplyCavDefinitionToPlayer(session, chosen.Definition, chosen.Name) Then Return False
            PersistCavChoice(p, chosen)
            Return True
        End Function

        Private Function ApplyControlledRegenerationCav(session As Integer, p As PlayerProfile) As Boolean
            If Not p.ControlledRegenerationArmed OrElse String.IsNullOrWhiteSpace(p.ControlledRegenerationCavName) Then Return False

            Dim chosen As RegenerationCavPreset = FindCavPreset(p.ControlledRegenerationCavName, True)
            p.ControlledRegenerationArmed = False
            p.ControlledRegenerationCavName = ""

            If chosen Is Nothing Then
                Console(session, 220, 130, 70, "Controlled regeneration target vanished from the CAV catalog. Falling back to random regeneration.")
                Return False
            End If
            If Not chosen.IsReady() Then
                Console(session, 220, 130, 70, "Controlled regeneration look '" & chosen.Name & "' has no live AW_CAV_DEFINITION yet. Falling back to random regeneration.")
                Return False
            End If
            If Not ApplyCavDefinitionToPlayer(session, chosen.Definition, chosen.Name) Then Return False
            PersistCavChoice(p, chosen)
            Return True
        End Function

        Private Function ApplyRegenerationCavForIncarnation(session As Integer, p As PlayerProfile) As Boolean
            If p.ControlledRegenerationArmed Then
                If ApplyControlledRegenerationCav(session, p) Then Return True
            End If
            Return ApplyRandomRegenerationCav(session, p)
        End Function

        Private Function ArmControlledRegeneration(session As Integer, p As PlayerProfile, requestedName As String) As Boolean
            Dim chosen As RegenerationCavPreset = FindCavPreset(requestedName, True)
            If chosen Is Nothing Then
                Console(session, 210, 100, 90, "No controlled regeneration CAV named '" & requestedName & "' exists.")
                Return False
            End If
            If Not chosen.IsReady() Then
                Console(session, 220, 150, 70, "'" & chosen.Name & "' exists in the Doctor catalog, but its live AW_CAV_DEFINITION has not been captured yet.")
                Return False
            End If

            p.ControlledRegenerationArmed = True
            p.ControlledRegenerationCavName = chosen.Name
            Console(session, 190, 140, 235, "CONTROLLED REGENERATION ARMED | Next incarnation: " & chosen.Name & If(chosen.Gender <> "", " | " & chosen.Gender, "") & ".")
            If chosen.Design <> "" Then Console(session, 150, 170, 220, chosen.Design)
            Return True
        End Function

        Private Sub ClearControlledRegeneration(session As Integer, p As PlayerProfile)
            p.ControlledRegenerationArmed = False
            p.ControlledRegenerationCavName = ""
            Console(session, 150, 150, 180, "Controlled regeneration cancelled. The next regeneration will randomize normally.")
        End Sub

        Private Sub ListControlledRegenerationCavs(session As Integer)
            Dim names As New List(Of String)()
            For Each c As RegenerationCavPreset In _regenerationCavs
                If c.AllowsControlled() Then
                    names.Add(c.Name & If(c.IsReady(), "", " [design-only]"))
                End If
            Next
            If names.Count = 0 Then
                Console(session, 170, 150, 170, "No controlled regeneration CAVs are catalogued.")
                Return
            End If
            Console(session, 190, 160, 235, "CONTROLLED REGENERATION CATALOG | " & String.Join(", ", names.ToArray()))
        End Sub

        Private Sub BroadcastRegenerationWorldMessage(p As PlayerProfile)
            Dim traveller As String = If(String.IsNullOrWhiteSpace(p.Name), "A Time Lord", p.Name)
            Dim appearance As String = If(String.IsNullOrWhiteSpace(p.CurrentCavName), "an unknown new form", p.CurrentCavName)
            Dim msg As String = "REGENERATION ACROSS THE VORTEX | " & traveller & " has regenerated into Incarnation " & p.Incarnation.ToString() & " — " & appearance & "."
            Dim sessions() As Integer = New List(Of Integer)(_sessions.Keys).ToArray()
            For Each s As Integer In sessions
                Console(s, 245, 195, 75, msg)
            Next
            _log("WORLD REGENERATION MESSAGE: " & msg)
        End Sub

        Private Sub ShowCavStatus(session As Integer, p As PlayerProfile)
            Dim ready As Integer = _regenerationCavs.FindAll(Function(x) x.IsReady()).Count
            Dim randomReady As Integer = _randomRegenerationCavs.FindAll(Function(x) x.IsReady()).Count
            Dim controlState As String = If(p.ControlledRegenerationArmed, " | CONTROL ARMED: " & p.ControlledRegenerationCavName, "")
            Dim pools As String = "Controlled " & ready.ToString() & "/" & _regenerationCavs.Count.ToString() & " | Random " & randomReady.ToString() & "/" & _randomRegenerationCavs.Count.ToString()
            If String.IsNullOrWhiteSpace(p.CurrentCavDefinition) Then
                Console(session, 150, 150, 170, "INCARNATION APPEARANCE | No live regeneration CAV assigned. " & pools & controlState & ".")
            Else
                Console(session, 130, 200, 230, "INCARNATION APPEARANCE | " & If(p.CurrentCavName, "Custom Avatar") & " | Incarnation " & p.CurrentCavIncarnation.ToString() & " | " & pools & controlState & ".")
            End If
        End Sub

        Private Function ReapplyCurrentCav(session As Integer, p As PlayerProfile) As Boolean
            If String.IsNullOrWhiteSpace(p.CurrentCavDefinition) Then
                Console(session, 180, 130, 80, "No stored incarnation CAV exists to reapply.")
                Return False
            End If
            Return ApplyCavDefinitionToPlayer(session, p.CurrentCavDefinition, If(p.CurrentCavName, "Stored incarnation appearance"))
        End Function

        Private Sub CallbackCavReceived(sender As AW.Instance, result As Result)
            HandleCavSdkReturn(sender, "CallbackCav", result)
        End Sub

        Private Sub CallbackCavResultReceived(sender As AW.Instance, result As Result)
            Dim handled As Boolean = HandlePendingCavChangeResult(sender, result)
            If Not handled Then
                HandleCavSdkReturn(sender, "CallbackCavResult", result)
            End If
        End Sub


        Private Function HandlePendingCavChangeResult(sender As AW.Instance, result As Result) As Boolean
            If _pendingCavApplyDefinitionBySession.Count = 0 Then Return False

            Dim session As Integer = 0
            Try
                Dim cavSessionAttr As Attributes
                If TryGetAwAttribute("CavSession", cavSessionAttr) Then
                    session = sender.GetInt(cavSessionAttr)
                End If
            Catch
            End Try

            If session <= 0 OrElse Not _pendingCavApplyDefinitionBySession.ContainsKey(session) Then
                If _pendingCavApplyDefinitionBySession.Count = 1 Then
                    For Each kv As KeyValuePair(Of Integer, String) In _pendingCavApplyDefinitionBySession
                        session = kv.Key
                        Exit For
                    Next
                Else
                    Return False
                End If
            End If

            Return FinalizePendingCavChange(session, result, "CallbackCavResult")
        End Function

        Private Function FinalizePendingCavChange(session As Integer, result As Result, sourceName As String) As Boolean
            If session <= 0 OrElse Not _pendingCavApplyDefinitionBySession.ContainsKey(session) Then Return False

            Dim definition As String = _pendingCavApplyDefinitionBySession(session)
            Dim displayName As String = If(_pendingCavApplyNameBySession.ContainsKey(session),
                                           _pendingCavApplyNameBySession(session),
                                           "replacement CAV")
            Dim citizen As Integer = If(_pendingCavApplyCitizenBySession.ContainsKey(session),
                                        _pendingCavApplyCitizenBySession(session),
                                        GetAvatarCitizenForSession(session))

            _pendingCavApplyDefinitionBySession.Remove(session)
            _pendingCavApplyNameBySession.Remove(session)
            _pendingCavApplyCitizenBySession.Remove(session)
            _pendingCavApplyDeadlineBySession.Remove(session)

            _log("CAV CHANGE COMPLETE | source=" & sourceName &
                 " session=" & session.ToString() &
                 " citizen=" & citizen.ToString() &
                 " result=" & result.ToString())

            If result <> Result.Success Then
                If _sessions.ContainsKey(session) Then
                    Console(session, 220, 90, 90,
                            "CAV CHANGE FAILED | " & sourceName &
                            " returned " & result.ToString() & ".")
                End If
                Return True
            End If

            If _sessions.ContainsKey(session) Then
                Console(session, 100, 230, 150,
                        "CAV CHANGE COMMITTED | " & sourceName &
                        " accepted " & displayName &
                        ". Reloading avatar, then verifying...")
            End If

            Try
                Dim avatarTypeAttr As Attributes
                Dim avatarSetFlagAttr As Attributes
                Dim avatarCitizenAttr As Attributes
                Dim avatarSessionAttr As Attributes

                If TryGetAwAttribute("AvatarType", avatarTypeAttr) Then
                    _sdk.SetInt(avatarTypeAttr, AwCustomAvatarType)
                End If
                If TryGetAwAttribute("AvatarSetFlag", avatarSetFlagAttr) Then
                    _sdk.SetInt(avatarSetFlagAttr, AwAvatarSetTypeFlag)
                End If
                If TryGetAwAttribute("AvatarCitizen", avatarCitizenAttr) Then
                    _sdk.SetInt(avatarCitizenAttr, citizen)
                End If
                If TryGetAwAttribute("AvatarSession", avatarSessionAttr) Then
                    _sdk.SetInt(avatarSessionAttr, session)
                End If

                Dim avatarSetResult As Result = _sdk.AvatarSet(session)
                Dim reloadResult As Result = _sdk.AvatarReload(citizen, session)

                _log("CAV POST-COMMIT | AvatarSet => " & avatarSetResult.ToString() &
                     " | AvatarReload => " & reloadResult.ToString())
            Catch ex As Exception
                _log("CAV POST-COMMIT avatar reload warning: " & ex.Message)
            End Try

            _expectedAppliedCavDefinitionBySession(session) = definition
            _cavVerificationLabelBySession(session) = "POST-COMMIT TARGET"
            _pendingCavProbeBySession(session) = DateTime.UtcNow.AddSeconds(10)

            Dim verifyResult As Result = _sdk.CavRequest(citizen, session)
            _log("CAV POST-COMMIT VERIFY | CavRequest(" & citizen.ToString() & ", " &
                 session.ToString() & ") => " & verifyResult.ToString())

            If verifyResult <> Result.Success AndAlso _sessions.ContainsKey(session) Then
                Console(session, 220, 150, 70,
                        "CAV VERIFY WARNING | Post-commit CavRequest returned " &
                        verifyResult.ToString() & ".")
            End If

            Return True
        End Function

        Private Sub TickPendingCavChanges(now As DateTime)
            If _pendingCavApplyDeadlineBySession.Count = 0 Then Return

            Dim sessions() As Integer =
                New List(Of Integer)(_pendingCavApplyDeadlineBySession.Keys).ToArray()

            For Each session As Integer In sessions
                If Not _pendingCavApplyDeadlineBySession.ContainsKey(session) Then Continue For
                If now < _pendingCavApplyDeadlineBySession(session) Then Continue For

                _log("CAV CHANGE FALLBACK | No completion callback/event arrived within 2 seconds for session " &
                     session.ToString() & ". Continuing from CavChange immediate Success.")

                If _sessions.ContainsKey(session) Then
                    Console(session, 180, 190, 230,
                            "CAV CHANGE FALLBACK | No completion callback arrived; reloading and verifying after 2 seconds.")
                End If

                FinalizePendingCavChange(session, Result.Success, "2-second fallback")
            Next
        End Sub

        Private Sub EventCavDefinitionChanged(sender As AW.Instance)
            If _pendingCavApplyDefinitionBySession.Count > 0 Then
                Dim session As Integer = 0
                Try
                    Dim cavSessionAttr As Attributes
                    If TryGetAwAttribute("CavSession", cavSessionAttr) Then
                        session = sender.GetInt(cavSessionAttr)
                    End If
                Catch
                End Try

                If session <= 0 AndAlso _pendingCavApplyDefinitionBySession.Count = 1 Then
                    For Each kv As KeyValuePair(Of Integer, String) In _pendingCavApplyDefinitionBySession
                        session = kv.Key
                        Exit For
                    Next
                End If

                If session > 0 AndAlso FinalizePendingCavChange(session, Result.Success, "EventCavDefinitionChange") Then
                    Return
                End If
            End If

            HandleCavSdkReturn(sender, "EventCavDefinitionChange", Result.Success)
        End Sub

        Private Sub CallbackWorldCavReceived(sender As AW.Instance, result As Result)
            HandleCavSdkReturn(sender, "CallbackWorldCav", result)
        End Sub

        Private Sub CallbackWorldCavResultReceived(sender As AW.Instance, result As Result)
            HandleCavSdkReturn(sender, "CallbackWorldCavResult", result)
        End Sub

        Private Sub EventWorldCavDefinitionChanged(sender As AW.Instance)
            HandleCavSdkReturn(sender, "EventWorldCavDefinitionChange", Result.Success)
        End Sub


        Private Function ReadCavDiagnosticAttribute(sender As AW.Instance, attributeName As String, asString As Boolean) As String
            Try
                Dim attr As Attributes
                If Not TryGetAwAttribute(attributeName, attr) Then
                    Return "<attribute unavailable>"
                End If

                If asString Then
                    Dim value As String = sender.GetString(attr)
                    If value Is Nothing Then Return "<null>"
                    If value.Length = 0 Then Return "<empty>"
                    Return value
                Else
                    Return sender.GetInt(attr).ToString()
                End If
            Catch ex As Exception
                Return "<error: " & ex.Message & ">"
            End Try
        End Function



        Private Function TryDecompressZlib(bytes As Byte(), ByRef decoded As String) As Boolean
            decoded = ""
            If bytes Is Nothing OrElse bytes.Length < 7 Then Return False

            ' DeltaWorlds CAV payloads returned by GetData() are RFC1950 zlib streams.
            ' 0x78 is the common CMF byte; 0xDA is a high-compression FLG byte.
            If bytes(0) <> &H78 Then Return False

            Try
                ' .NET Framework DeflateStream expects the raw DEFLATE body, so skip the
                ' 2-byte zlib header and the 4-byte Adler-32 trailer.
                Using input As New MemoryStream(bytes, 2, bytes.Length - 6, False)
                    Using inflater As New System.IO.Compression.DeflateStream(
                        input, System.IO.Compression.CompressionMode.Decompress, False)
                        Using output As New MemoryStream()
                            inflater.CopyTo(output)
                            Dim expanded As Byte() = output.ToArray()
                            decoded = System.Text.Encoding.UTF8.GetString(expanded)
                            Return Not String.IsNullOrWhiteSpace(decoded)
                        End Using
                    End Using
                End Using
            Catch ex As Exception
                _log("CAV ZLIB | Manual decompression failed: " & ex.Message)
                Return False
            End Try
        End Function

        Private Function ProbeRawCavPayload(sender As AW.Instance, targetSession As Integer, sourceName As String) As String
            Try
                Dim cavAttr As Attributes
                If Not TryGetAwAttribute("CavDefinition", cavAttr) Then
                    Return ""
                End If

                Dim methods() As System.Reflection.MethodInfo = sender.GetType().GetMethods()
                For Each mi As System.Reflection.MethodInfo In methods
                    If mi.Name <> "GetBytes" AndAlso mi.Name <> "GetData" Then Continue For

                    Try
                        Dim ps() As System.Reflection.ParameterInfo = mi.GetParameters()
                        Dim args() As Object = Nothing

                        If ps.Length = 1 Then
                            Dim pt As Type = ps(0).ParameterType
                            If pt.IsEnum Then
                                args = New Object() {cavAttr}
                            ElseIf pt Is GetType(Integer) Then
                                args = New Object() {CInt(cavAttr)}
                            Else
                                Continue For
                            End If
                        Else
                            Continue For
                        End If

                        Dim raw As Object = mi.Invoke(sender, args)
                        If raw Is Nothing Then
                            _log("CAV RAW | " & mi.Name & " returned <null>.")
                            Continue For
                        End If

                        Dim bytes As Byte() = TryCast(raw, Byte())
                        If bytes IsNot Nothing Then
                            Dim hexPreview As String = BitConverter.ToString(bytes, 0, Math.Min(bytes.Length, 32))
                            Dim b64 As String = Convert.ToBase64String(bytes)

                            _log("CAV RAW | " & mi.Name & " returned " & bytes.Length.ToString() &
                                 " bytes. Head=" & hexPreview)

                            If targetSession > 0 AndAlso _sessions.ContainsKey(targetSession) Then
                                Console(targetSession, 120, 210, 235,
                                    "CAV RAW | " & mi.Name & " returned " &
                                    bytes.Length.ToString() & " bytes. Head=" & hexPreview)
                            End If

                            Try
                                Dim rawPath As String = System.IO.Path.Combine(
                                    AppDomain.CurrentDomain.BaseDirectory,
                                    "CapturedCAV_raw_" & targetSession.ToString() & ".bin")
                                File.WriteAllBytes(rawPath, bytes)

                                Dim b64Path As String = System.IO.Path.Combine(
                                    AppDomain.CurrentDomain.BaseDirectory,
                                    "CapturedCAV_raw_" & targetSession.ToString() & ".base64.txt")
                                File.WriteAllText(b64Path, b64)
                            Catch ex As Exception
                                _log("CAV RAW save warning: " & ex.Message)
                            End Try

                            Dim decompressed As String = ""
                            If TryDecompressZlib(bytes, decompressed) Then
                                _log("CAV ZLIB | Successfully decompressed " &
                                     bytes.Length.ToString() & " bytes into " &
                                     decompressed.Length.ToString() & " characters.")

                                If targetSession > 0 AndAlso _sessions.ContainsKey(targetSession) Then
                                    Console(targetSession, 100, 230, 150,
                                        "CAV ZLIB SUCCESS | Expanded " &
                                        bytes.Length.ToString() & " compressed bytes into " &
                                        decompressed.Length.ToString() & " characters.")
                                End If

                                Try
                                    Dim textPath As String = System.IO.Path.Combine(
                                        AppDomain.CurrentDomain.BaseDirectory,
                                        "CapturedCAV_decompressed_" & targetSession.ToString() & ".txt")
                                    File.WriteAllText(textPath, decompressed)
                                Catch ex As Exception
                                    _log("CAV ZLIB save warning: " & ex.Message)
                                End Try

                                Return decompressed
                            End If

                            ' Only treat the raw payload itself as text if it is not zlib.
                            If bytes.Length < 2 OrElse bytes(0) <> &H78 Then
                                Try
                                    Dim utf As String = System.Text.Encoding.UTF8.GetString(bytes)
                                    If Not String.IsNullOrWhiteSpace(utf) Then
                                        Dim printable As Integer = 0
                                        For Each ch As Char In utf
                                            If Not Char.IsControl(ch) OrElse ch = ControlChars.Cr OrElse ch = ControlChars.Lf OrElse ch = ControlChars.Tab Then
                                                printable += 1
                                            End If
                                        Next
                                        If utf.Length > 0 AndAlso CDbl(printable) / CDbl(utf.Length) > 0.8 Then
                                            _log("CAV RAW | Payload appears to be UTF-8 text.")
                                            Return utf.Trim(ChrW(0), ControlChars.Cr, ControlChars.Lf)
                                        End If
                                    End If
                                Catch
                                End Try
                            End If

                            Return ""
                        End If

                        Dim textValue As String = TryCast(raw, String)
                        If textValue IsNot Nothing Then
                            _log("CAV RAW | " & mi.Name & " returned String length " & textValue.Length.ToString() & ".")
                            If textValue.Length > 0 Then Return textValue
                        Else
                            _log("CAV RAW | " & mi.Name & " returned type " & raw.GetType().FullName & ".")
                        End If
                    Catch ex As Exception
                        Dim inner As Exception = ex
                        If ex.InnerException IsNot Nothing Then inner = ex.InnerException
                        _log("CAV RAW | " & mi.Name & " invoke failed: " & inner.Message)
                    End Try
                Next

                ' Log the exact available raw accessor signatures once, so the next pass
                ' can be made strongly typed if necessary.
                For Each mi As System.Reflection.MethodInfo In methods
                    If mi.Name = "GetBytes" OrElse mi.Name = "GetData" Then
                        Dim sig As New System.Text.StringBuilder()
                        sig.Append(mi.ReturnType.Name).Append(" ").Append(mi.Name).Append("(")
                        Dim ps() As System.Reflection.ParameterInfo = mi.GetParameters()
                        For i As Integer = 0 To ps.Length - 1
                            If i > 0 Then sig.Append(", ")
                            sig.Append(ps(i).ParameterType.Name).Append(" ").Append(ps(i).Name)
                        Next
                        sig.Append(")")
                        _log("CAV RAW SDK | " & sig.ToString())
                        If targetSession > 0 AndAlso _sessions.ContainsKey(targetSession) Then
                            Console(targetSession, 150, 190, 230, "CAV RAW SDK | " & sig.ToString())
                        End If
                    End If
                Next
            Catch ex As Exception
                _log("CAV RAW probe fatal error: " & ex.ToString())
            End Try
            Return ""
        End Function

        Private Sub DumpCavCallbackDiagnostics(sender As AW.Instance, sourceName As String, callbackResult As Result, targetSession As Integer)
            Try
                Dim cavCitizen As String = ReadCavDiagnosticAttribute(sender, "CavCitizen", False)
                Dim cavSession As String = ReadCavDiagnosticAttribute(sender, "CavSession", False)
                Dim cavDefinition As String = ReadCavDiagnosticAttribute(sender, "CavDefinition", True)
                Dim avatarCitizen As String = ReadCavDiagnosticAttribute(sender, "AvatarCitizen", False)
                Dim avatarSession As String = ReadCavDiagnosticAttribute(sender, "AvatarSession", False)
                Dim avatarType As String = ReadCavDiagnosticAttribute(sender, "AvatarType", False)

                Dim cavData As String = ""
                Dim cavDataLabel As String = "<empty>"
                Try
                    cavData = sender.GetCavData()
                    If cavData Is Nothing Then
                        cavDataLabel = "<null>"
                    ElseIf cavData.Length > 0 Then
                        cavDataLabel = cavData
                    End If
                Catch ex As Exception
                    cavDataLabel = "<error: " & ex.Message & ">"
                End Try

                Dim lines As New List(Of String)()
                lines.Add("CAV DIAG | source=" & sourceName & " result=" & callbackResult.ToString())
                lines.Add("CAV DIAG | CavCitizen=" & cavCitizen & " CavSession=" & cavSession)
                lines.Add("CAV DIAG | AvatarCitizen=" & avatarCitizen & " AvatarSession=" & avatarSession & " AvatarType=" & avatarType)
                lines.Add("CAV DIAG | CavDefinition=" & If(cavDefinition.Length > 180, cavDefinition.Substring(0, 180) & "...", cavDefinition))
                lines.Add("CAV DIAG | GetCavData=" & If(cavDataLabel.Length > 180, cavDataLabel.Substring(0, 180) & "...", cavDataLabel))

                For Each line As String In lines
                    _log(line)
                    If targetSession > 0 AndAlso _sessions.ContainsKey(targetSession) Then
                        Console(targetSession, 180, 200, 230, line)
                    End If
                Next
            Catch ex As Exception
                _log("CAV DIAG fatal error: " & ex.ToString())
            End Try
        End Sub

        Private Sub HandleCavSdkReturn(sender As AW.Instance, sourceName As String, callbackResult As Result)
            Try
                Dim session As Integer = 0
                Dim citizen As Integer = 0

                Try
                    Dim cavSessionAttr As Attributes
                    If TryGetAwAttribute("CavSession", cavSessionAttr) Then
                        session = sender.GetInt(cavSessionAttr)
                    End If
                Catch ex As Exception
                    _log("CAV CALLBACK [" & sourceName & "] CavSession read warning: " & ex.Message)
                End Try

                Try
                    Dim cavCitizenAttr As Attributes
                    If TryGetAwAttribute("CavCitizen", cavCitizenAttr) Then
                        citizen = sender.GetInt(cavCitizenAttr)
                    End If
                Catch ex As Exception
                    _log("CAV CALLBACK [" & sourceName & "] CavCitizen read warning: " & ex.Message)
                End Try

                ' Some builds do not expose CavSession/CavCitizen through attributes on
                ' the callback.  If exactly one player is waiting, that request owns it.
                If session <= 0 AndAlso _pendingCavProbeBySession.Count = 1 Then
                    For Each kv As KeyValuePair(Of Integer, DateTime) In _pendingCavProbeBySession
                        session = kv.Key
                        Exit For
                    Next
                End If

                DumpCavCallbackDiagnostics(sender, sourceName, callbackResult, session)

                Dim definition As String = ""

                ' For CavRequest the returned protocol definition is exposed through
                ' AW_CAV_DEFINITION during the callback. GetCavData() is a separate
                ' wrapper surface and may legitimately be empty here.
                Try
                    Dim cavDefinitionAttr As Attributes
                    If TryGetAwAttribute("CavDefinition", cavDefinitionAttr) Then
                        definition = sender.GetString(cavDefinitionAttr)
                    End If
                Catch ex As Exception
                    _log("CAV CALLBACK [" & sourceName & "] CavDefinition read warning: " & ex.Message)
                End Try

                If String.IsNullOrWhiteSpace(definition) Then
                    Try
                        definition = sender.GetCavData()
                    Catch ex As Exception
                        _log("CAV CALLBACK [" & sourceName & "] GetCavData warning: " & ex.Message)
                    End Try
                End If

                If String.IsNullOrWhiteSpace(definition) Then
                    definition = ProbeRawCavPayload(sender, session, sourceName)
                End If

                _log("CAV CALLBACK [" & sourceName & "] result=" & callbackResult.ToString() &
                     " session=" & session.ToString() &
                     " citizen=" & citizen.ToString() &
                     " definitionLength=" & If(definition, "").Length.ToString())

                If String.IsNullOrWhiteSpace(definition) Then
                    If session > 0 AndAlso _sessions.ContainsKey(session) Then
                        Console(session, 180, 160, 90,
                                "CAV CALLBACK | " & sourceName &
                                " returned " & callbackResult.ToString() &
                                " but contained no CAV definition.")
                    End If
                    Return
                End If

                If session <= 0 Then
                    _log("CAV CALLBACK [" & sourceName & "] contained a definition but no session could be associated with it.")
                    Return
                End If

                _lastCapturedCavDefinitionBySession(session) = definition
                _pendingCavProbeBySession.Remove(session)

                If _expectedAppliedCavDefinitionBySession.ContainsKey(session) Then
                    Dim expected As String = _expectedAppliedCavDefinitionBySession(session)
                    _expectedAppliedCavDefinitionBySession.Remove(session)

                    Dim verifyLabel As String = "CAV TARGET"
                    If _cavVerificationLabelBySession.ContainsKey(session) Then
                        verifyLabel = _cavVerificationLabelBySession(session)
                        _cavVerificationLabelBySession.Remove(session)
                    End If

                    If String.Equals(expected, definition, StringComparison.Ordinal) Then
                        Console(session, 80, 230, 140,
                                "CAV VERIFY SUCCESS [" & verifyLabel &
                                "] | Returned the exact replacement definition.")
                        _log("CAV VERIFY SUCCESS [" & verifyLabel &
                             "] | Returned definition exactly matches the applied definition.")
                    Else
                        Console(session, 230, 100, 90,
                                "CAV VERIFY FAILED [" & verifyLabel &
                                "] | Returned a different live CAV definition after CavChange.")
                        _log("CAV VERIFY FAILED [" & verifyLabel &
                             "] | expectedLength=" & expected.Length.ToString() &
                             " returnedLength=" & definition.Length.ToString())
                    End If
                End If

                Try
                    Dim capturePath As String =
                        System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CapturedCAVs.txt")
                    File.AppendAllText(
                        capturePath,
                        DateTime.UtcNow.ToString("o") &
                        "|session:" & session.ToString() &
                        "|citizen:" & citizen.ToString() &
                        "|" & definition &
                        Environment.NewLine)
                Catch ex As Exception
                    _log("CAV CALLBACK capture-save warning: " & ex.Message)
                End Try

                Console(session, 100, 220, 150,
                        "CAV PROBE SUCCESS | " & sourceName &
                        " returned your live CAV definition (" &
                        definition.Length.ToString() & " chars).")
            Catch ex As Exception
                _log("CAV CALLBACK [" & sourceName & "] fatal handler error: " & ex.ToString())
            End Try
        End Sub

End Class
End Namespace
