# TimeLordBot V3 changelog

V3 adds the adventure layer on top of the V2 health/skill/TARDIS simulation.

- Persistent two-heart Time Lord cardiovascular condition
- Low-health unconsciousness and revival
- V3 medbay heals hearts, Health, statuses and unconsciousness
- Two random incarnation traits on awakening/regeneration
- Trait bonuses integrated into shared skill checks
- Sonic screwdriver modes and object API
- Wood immunity easter egg/mechanic
- Persistent enemy/encounter state in `EnemyStates.xml`
- Multi-solution encounters: Combat, Sonic, Diplomacy, Stealth, Psychic, Investigation
- Enemy retaliation using typed damage
- Builder-authored missions
- Procedural TARDIS distress calls from the navigation database
- Automatic mission progress on destination arrival
- Persistent discoveries and 100-entry recent travel log
- Generic faction reputation
- Persistent achievements and character-history counters
- Toggleable per-player HUD using the supplied DeltaWorlds HUD textures
- HUD click handling for status, skills, missions, travel and achievements
- Ready-to-paste V3 object recipe sheet

Existing V2 TARDIS, cross-world travel, health, status, regeneration, skills, repair and object actions remain in place.
