Imports System
Imports System.Diagnostics
Imports System.IO
Imports System.Threading
Imports System.Windows.Forms

Namespace TimeLordBot
    Friend Module Program
        Private ReadOnly CrashLogPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "TimeLordBot_crash.log")

        <STAThread()>
        Public Sub Main()
            ' Catch managed Windows Forms exceptions instead of allowing the EXE to vanish.
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException)
            AddHandler Application.ThreadException, AddressOf OnUiThreadException
            AddHandler AppDomain.CurrentDomain.UnhandledException, AddressOf OnUnhandledDomainException

            Try
                Application.EnableVisualStyles()
                Application.SetCompatibleTextRenderingDefault(False)
                Application.Run(New MainForm())
            Catch ex As Exception
                WriteCrashLog("TOP-LEVEL APPLICATION FAILURE", ex, True)
            End Try
        End Sub

        Private Sub OnUiThreadException(sender As Object, e As ThreadExceptionEventArgs)
            ' UI-thread exceptions are logged and swallowed so one bad event does not
            ' immediately terminate the long-running bot process.
            WriteCrashLog("WINDOWS FORMS THREAD EXCEPTION", e.Exception, False)
        End Sub

        Private Sub OnUnhandledDomainException(sender As Object, e As UnhandledExceptionEventArgs)
            Dim ex As Exception = TryCast(e.ExceptionObject, Exception)
            If ex IsNot Nothing Then
                WriteCrashLog("APPDOMAIN UNHANDLED EXCEPTION", ex, e.IsTerminating)
            Else
                WriteCrashText("APPDOMAIN UNHANDLED NON-EXCEPTION OBJECT" & Environment.NewLine &
                               "Terminating: " & e.IsTerminating.ToString() & Environment.NewLine &
                               Convert.ToString(e.ExceptionObject))
            End If
        End Sub

        Private Sub WriteCrashLog(context As String, ex As Exception, terminating As Boolean)
            Dim text As String = context & Environment.NewLine &
                                 "UTC: " & DateTime.UtcNow.ToString("O") & Environment.NewLine &
                                 "Terminating: " & terminating.ToString() & Environment.NewLine &
                                 "Process: " & Process.GetCurrentProcess().Id.ToString() & Environment.NewLine &
                                 "OS: " & Environment.OSVersion.ToString() & Environment.NewLine &
                                 ".NET: " & Environment.Version.ToString() & Environment.NewLine &
                                 ex.ToString()
            WriteCrashText(text)
        End Sub

        Private Sub WriteCrashText(text As String)
            Try
                File.AppendAllText(CrashLogPath,
                    Environment.NewLine &
                    "============================================================" & Environment.NewLine &
                    text & Environment.NewLine)
            Catch
                ' A crash logger must never cause a second crash.
            End Try
        End Sub
    End Module
End Namespace
