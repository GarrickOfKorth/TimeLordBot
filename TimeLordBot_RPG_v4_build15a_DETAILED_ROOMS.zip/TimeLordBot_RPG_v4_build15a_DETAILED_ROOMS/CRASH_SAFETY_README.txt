TIME LORD BOT — BUILD FIX 9: CRASH SAFETY
=========================================

WHY THIS EXISTS
---------------
If the entire EXE disappears, that is a process crash rather than a normal
DeltaWorlds disconnect. Build Fix 9 adds two protection layers:

1. Managed exception protection inside TimeLordBot.exe
   - Windows Forms UI exceptions are caught and logged.
   - AppDomain unhandled exceptions are logged.
   - Top-level application failures are logged.
   - The log file is: TimeLordBot_crash.log
   - Event-loop errors now record full exception/stack details instead of only
     the exception message.

2. Optional external watchdog
   - Launch Run_TimeLordBot_Watchdog.cmd instead of double-clicking the EXE.
   - If TimeLordBot.exe terminates for any reason, the watchdog waits five
     seconds and launches it again.
   - This also covers hard/native failures in aw.dll that .NET may be unable to
     catch or log.
   - Press Ctrl+C in the watchdog window to stop it intentionally.
   - Alternatively create a file named STOP_WATCHDOG in the bot folder; the
     watchdog will exit after the current bot process closes.

WHAT TO SEND FOR DEBUGGING
--------------------------
If the bot disappears again, send TimeLordBot_crash.log if it exists.

If the watchdog reports that the EXE exited but NO crash log was written, that
strongly suggests a native process failure (for example inside aw.dll / the AW
runtime) or an external termination rather than a normal managed exception.
The exit code displayed by the watchdog is useful evidence in that case.

EXTRA HARDENING
---------------
The avatar-proximity loop now enumerates a snapshot of tracked avatars instead
of the live dictionary, reducing the risk of collection-change/re-entrancy
failures while avatar events are arriving.
