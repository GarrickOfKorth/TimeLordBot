Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Xml.Serialization
Imports AW

Namespace TimeLordBot

    Public Class DiscoveryRecord
        Public Property Id As String = ""
        Public Property Name As String = ""
        Public Property WorldName As String = ""
        Public Property DiscoveredUtc As DateTime = DateTime.UtcNow
    End Class

    Public Class TravelRecord
        Public Property Destination As String = ""
        Public Property WorldName As String = ""
        Public Property VisitedUtc As DateTime = DateTime.UtcNow
    End Class

    Public Class MissionProgress
        Public Property Id As String = ""
        Public Property Title As String = ""
        Public Property Objective As String = ""
        Public Property Current As Integer = 0
        Public Property Required As Integer = 1
        Public Property Status As String = "active"
        Public Property Destination As String = ""
        Public Property StartedUtc As DateTime = DateTime.UtcNow
        Public Property CompletedUtc As DateTime = DateTime.MinValue
    End Class

    Public Class FactionStanding
        Public Property Name As String = ""
        Public Property Reputation As Integer = 0
    End Class

    Public Class EnemyState
        Public Property Key As String = ""
        Public Property Id As String = ""
        Public Property Name As String = "Hostile"
        Public Property Species As String = "Unknown"
        Public Property WorldName As String = ""
        Public Property Health As Integer = 40
        Public Property MaxHealth As Integer = 40
        Public Property Defense As Integer = 45
        Public Property Attack As Integer = 10
        Public Property AttackDifficulty As Integer = 45
        Public Property DamageType As String = "energy"
        Public Property IsDefeated As Boolean = False
        Public Property DefeatedBy As String = ""
        Public Property DefeatedUtc As DateTime = DateTime.MinValue
    End Class

    Public Partial Class TardisBot
        Private _v3Initialized As Boolean = False
        Private _enemyStatesPath As String = ""
        Private ReadOnly _enemies As New Dictionary(Of String, EnemyState)(StringComparer.OrdinalIgnoreCase)
        Private ReadOnly _lastHudRefresh As New Dictionary(Of Integer, DateTime)()
        Private ReadOnly _lastHeartTick As New Dictionary(Of Integer, DateTime)()

        Private Sub EnsureV3Initialized()
            If _v3Initialized Then Return
            _v3Initialized = True
            _enemyStatesPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "EnemyStates.xml")
            LoadEnemyStates()
        End Sub

        Private Sub LoadEnemyStates()
            Try
                If Not File.Exists(_enemyStatesPath) Then Return
                Dim ser As New XmlSerializer(GetType(List(Of EnemyState)))
                Using fs As FileStream = File.OpenRead(_enemyStatesPath)
                    Dim list As List(Of EnemyState) = DirectCast(ser.Deserialize(fs), List(Of EnemyState))
                    For Each e As EnemyState In list
                        If Not String.IsNullOrWhiteSpace(e.Key) Then _enemies(e.Key) = e
                    Next
                End Using
            Catch ex As Exception
                _log("Enemy state load warning: " & ex.Message)
            End Try
        End Sub

        Private Sub SaveEnemyStates()
            Try
                EnsureV3Initialized()
                Dim ser As New XmlSerializer(GetType(List(Of EnemyState)))
                Using fs As FileStream = File.Create(_enemyStatesPath)
                    ser.Serialize(fs, New List(Of EnemyState)(_enemies.Values))
                End Using
            Catch ex As Exception
                _log("Enemy state save warning: " & ex.Message)
            End Try
        End Sub

        ' ============================================================
        ' V3 ROUTERS
        ' ============================================================

        Private Function HandleV3TardisControl(session As Integer, sender As AW.Instance, action As String, controlType As String) As Boolean
            EnsureV3Initialized()
            Dim p As PlayerProfile = _sessions(session)
            Select Case controlType.Trim().ToLowerInvariant()
                Case "hud"
                    Dim mode As String = GetParam(action, "mode").ToLowerInvariant()
                    If mode = "on" Then
                        p.HudEnabled = True
                    ElseIf mode = "off" Then
                        p.HudEnabled = False
                    Else
                        p.HudEnabled = Not p.HudEnabled
                    End If
                    If p.HudEnabled Then
                        Console(session, 90, 190, 220, "TARDIS HUD LINK ONLINE.")
                        RefreshRpgHud(session, True)
                    Else
                        ClearRpgHud(session)
                        Console(session, 140, 140, 170, "TARDIS HUD LINK OFFLINE.")
                    End If
                    Return True

                Case "distress"
                    GenerateDistressCall(session, p, CurrentWorld(sender))
                    Return True

                Case "mission"
                    ShowActiveMissions(session, p)
                    Return True

                Case "sonic"
                    Console(session, 120, 190, 220, "Sonic interface mode: " & p.SonicMode.ToUpperInvariant() & ". Use ~rpg action:sonic on a target object.")
                    Return True
            End Select
            Return False
        End Function

        Private Function HandleV3TimeLordControl(session As Integer, sender As AW.Instance, action As String, controlType As String) As Boolean
            EnsureV3Initialized()
            Dim p As PlayerProfile = _sessions(session)
            Select Case controlType.Trim().ToLowerInvariant()
                Case "hearts", "heartstatus"
                    ShowHeartStatus(session, p)
                    Return True
                Case "traits"
                    ShowTraits(session, p)
                    Return True
                Case "missions", "mission"
                    ShowActiveMissions(session, p)
                    Return True
                Case "achievements"
                    ShowAchievements(session, p)
                    Return True
                Case "travel", "travellog"
                    ShowTravelLog(session, p)
                    Return True
                Case "reputation", "factions"
                    ShowReputation(session, p)
                    Return True
                Case "sonic"
                    Dim mode As String = GetParam(action, "mode")
                    If mode <> "" Then p.SonicMode = NormalizeSonicMode(mode)
                    Console(session, 120, 190, 220, "Sonic screwdriver mode: " & p.SonicMode.ToUpperInvariant() & ".")
                    Return True
                Case "hud"
                    Dim mode As String = GetParam(action, "mode").ToLowerInvariant()
                    p.HudEnabled = If(mode = "on", True, If(mode = "off", False, Not p.HudEnabled))
                    If p.HudEnabled Then RefreshRpgHud(session, True) Else ClearRpgHud(session)
                    Return True
            End Select
            Return False
        End Function

        Private Function HandleV3RpgAction(session As Integer, sender As AW.Instance, action As String, command As String) As Boolean
            EnsureV3Initialized()
            Dim p As PlayerProfile = _sessions(session)
            Select Case command
                Case "sonicmode"
                    p.SonicMode = NormalizeSonicMode(GetParam(action, "mode"))
                    Console(session, 110, 190, 230, "Sonic mode set to " & p.SonicMode.ToUpperInvariant() & ".")
                    Return True

                Case "sonic"
                    UseSonic(session, p, sender, action)
                    Return True

                Case "discover"
                    Dim id As String = GetParam(action, "id")
                    Dim title As String = GetParam(action, "name")
                    If title = "" Then title = sender.GetString(Attributes.ObjectDescription)
                    If id = "" Then id = title.Replace(" ", "_")
                    RecordDiscovery(session, p, id, title, CurrentWorld(sender))
                    Return True

                Case "reputation"
                    ChangeReputation(session, p, GetParam(action, "faction"), ParseInt(GetParam(action, "amount"), 0))
                    Return True

                Case "missionstart"
                    StartMission(session, p, action)
                    Return True

                Case "missionprogress"
                    ProgressMission(session, p, GetParam(action, "id"), Math.Max(1, ParseInt(GetParam(action, "amount"), 1)))
                    Return True

                Case "missioncomplete"
                    CompleteMission(session, p, GetParam(action, "id"))
                    Return True

                Case "missionfail"
                    FailMission(session, p, GetParam(action, "id"))
                    Return True

                Case "heartdamage"
                    ApplyDirectHeartDamage(p, GetParam(action, "heart"), Math.Max(1, ParseInt(GetParam(action, "amount"), 20)), session)
                    Return True

                Case "heartheal"
                    HealHearts(p, Math.Max(1, ParseInt(GetParam(action, "amount"), 20)), session)
                    Return True

                Case "revive"
                    Dim med As SkillCheckResult = PerformSkillCheck(p, "Medicine", RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 45), 1, 100))
                    If med.Success Then
                        RemoveStatusSilent(p, "Unconscious")
                        ApplyHealing(p, If(med.CriticalSuccess, 25, 12), session, "emergency revival")
                        Console(session, 90, 200, 140, "Consciousness stabilizes.")
                    Else
                        Console(session, 220, 120, 80, "Revival attempt fails to stabilize consciousness.")
                    End If
                    ReportSkillGain(session, "Medicine", med)
                    Return True

                Case "medbay"
                    Dim wasUnconscious As Boolean = HasStatus(p, "Unconscious")
                    Dim difficulty As Integer = RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 30), 1, 100)
                    Dim med As SkillCheckResult = PerformSkillCheck(p, "Medicine", difficulty)
                    ApplyHealing(p, If(med.Success, If(med.CriticalSuccess, 45, 30), 10), session, "TARDIS medical bay")
                    If med.Success Then
                        HealHearts(p, If(med.CriticalSuccess, 35, 20), session)
                        CureOneHarmfulStatus(p, session)
                        RemoveStatusSilent(p, "Unconscious")
                        If wasUnconscious Then p.LivesSaved += 1
                    End If
                    ReportSkillGain(session, "Medicine", med)
                    EvaluateAchievements(session, p)
                    Return True

                Case "hud"
                    Dim mode As String = GetParam(action, "mode").ToLowerInvariant()
                    p.HudEnabled = If(mode = "on", True, If(mode = "off", False, Not p.HudEnabled))
                    If p.HudEnabled Then RefreshRpgHud(session, True) Else ClearRpgHud(session)
                    Return True
            End Select
            Return False
        End Function

        ' ============================================================
        ' TWO HEARTS / UNCONSCIOUSNESS
        ' ============================================================

        Private Sub ApplyHeartTrauma(p As PlayerProfile, amount As Integer, session As Integer)
            If Not p.IsTimeLord Then Return
            Dim trauma As Integer = Math.Max(4, amount \ 2)
            If _rng.Next(0, 2) = 0 Then
                p.HeartOneHealth = Math.Max(0, p.HeartOneHealth - trauma)
                Console(session, 230, 90, 90, "CARDIOVASCULAR TRAUMA: first heart " & p.HeartOneHealth.ToString() & "/100.")
            Else
                p.HeartTwoHealth = Math.Max(0, p.HeartTwoHealth - trauma)
                Console(session, 230, 90, 90, "CARDIOVASCULAR TRAUMA: second heart " & p.HeartTwoHealth.ToString() & "/100.")
            End If
            If p.HeartOneHealth <= 0 Xor p.HeartTwoHealth <= 0 Then
                AddStatus(p, "Single Heart Trauma", 180, 1, "cardiovascular injury", session)
            End If
            If p.HeartOneHealth <= 0 AndAlso p.HeartTwoHealth <= 0 Then
                Console(session, 245, 50, 50, "BOTH HEARTS HAVE FAILED. Regeneration is becoming unavoidable.")
                p.Health = 0
            End If
        End Sub

        Private Sub ApplyDirectHeartDamage(p As PlayerProfile, heart As String, amount As Integer, session As Integer)
            If Not p.IsTimeLord Then
                Console(session, 180, 90, 90, "No binary vascular system detected.")
                Return
            End If
            If heart.Trim().ToLowerInvariant() = "2" OrElse heart.ToLowerInvariant().Contains("two") Then
                p.HeartTwoHealth = Math.Max(0, p.HeartTwoHealth - amount)
            Else
                p.HeartOneHealth = Math.Max(0, p.HeartOneHealth - amount)
            End If
            ShowHeartStatus(session, p)
            If p.HeartOneHealth <= 0 AndAlso p.HeartTwoHealth <= 0 Then
                p.Health = 0
                HandleZeroHealth(session, p, "cardiac failure")
            End If
        End Sub

        Private Sub HealHearts(p As PlayerProfile, amount As Integer, session As Integer)
            If Not p.IsTimeLord Then Return
            p.HeartOneHealth = Math.Min(100, p.HeartOneHealth + amount)
            p.HeartTwoHealth = Math.Min(100, p.HeartTwoHealth + amount)
            If p.HeartOneHealth > 0 AndAlso p.HeartTwoHealth > 0 Then RemoveStatusSilent(p, "Single Heart Trauma")
            Console(session, 100, 190, 145, "Binary cardiovascular repair: H1 " & p.HeartOneHealth.ToString() & "/100 | H2 " & p.HeartTwoHealth.ToString() & "/100.")
        End Sub

        Private Sub ShowHeartStatus(session As Integer, p As PlayerProfile)
            If Not p.IsTimeLord Then
                Console(session, 150, 130, 160, "Human cardiovascular profile: one heart.")
                Return
            End If
            Console(session, 220, 90, 100, "TWO HEARTS | First " & p.HeartOneHealth.ToString() & "/100 | Second " & p.HeartTwoHealth.ToString() & "/100.")
        End Sub

        Private Sub RemoveStatusSilent(p As PlayerProfile, statusName As String)
            If p.StatusEffects Is Nothing Then Return
            For i As Integer = p.StatusEffects.Count - 1 To 0 Step -1
                If String.Equals(p.StatusEffects(i).Name.Replace(" ", ""), statusName.Replace(" ", ""), StringComparison.OrdinalIgnoreCase) Then p.StatusEffects.RemoveAt(i)
            Next
        End Sub

        ' ============================================================
        ' INCARNATION TRAITS
        ' ============================================================

        Private ReadOnly Property TraitPool As String()
            Get
                Return New String() {"Born Pilot", "Brilliant Engineer", "Temporal Intuition", "Psychic Sensitive", "Silver Tongue", "Field Medic", "Iron Constitution", "Artron Reservoir", "Shadow Walker", "Relentless Investigator", "Xenobiologist", "Sonic Savant"}
            End Get
        End Property

        Private Sub RollIncarnationTraits(p As PlayerProfile)
            p.IncarnationTraits = New List(Of String)()
            Dim pool As New List(Of String)(TraitPool)
            While p.IncarnationTraits.Count < 2 AndAlso pool.Count > 0
                Dim index As Integer = _rng.Next(0, pool.Count)
                p.IncarnationTraits.Add(pool(index))
                pool.RemoveAt(index)
            End While
            p.MaxHealth = 100 + If(HasIncarnationTrait(p, "Iron Constitution"), 15, 0)
            p.MaxArtronReserve = 250 + If(HasIncarnationTrait(p, "Artron Reservoir"), 50, 0)
        End Sub

        Private Function HasIncarnationTrait(p As PlayerProfile, traitName As String) As Boolean
            If p.IncarnationTraits Is Nothing Then Return False
            For Each t As String In p.IncarnationTraits
                If String.Equals(t, traitName, StringComparison.OrdinalIgnoreCase) Then Return True
            Next
            Return False
        End Function

        Private Function TraitSkillBonus(p As PlayerProfile, skillName As String) As Double
            Select Case skillName
                Case "Piloting" : If HasIncarnationTrait(p, "Born Pilot") Then Return 8
                Case "Engineering" : If HasIncarnationTrait(p, "Brilliant Engineer") Then Return 8
                Case "Navigation", "Temporal Science" : If HasIncarnationTrait(p, "Temporal Intuition") Then Return 8
                Case "Psychic" : If HasIncarnationTrait(p, "Psychic Sensitive") Then Return 8
                Case "Diplomacy" : If HasIncarnationTrait(p, "Silver Tongue") Then Return 8
                Case "Medicine" : If HasIncarnationTrait(p, "Field Medic") Then Return 8
                Case "Stealth" : If HasIncarnationTrait(p, "Shadow Walker") Then Return 8
                Case "Investigation" : If HasIncarnationTrait(p, "Relentless Investigator") Then Return 8
                Case "Xenobiology" : If HasIncarnationTrait(p, "Xenobiologist") Then Return 8
                Case "Sonic Technology" : If HasIncarnationTrait(p, "Sonic Savant") Then Return 8
            End Select
            Return 0
        End Function

        Private Sub ShowTraits(session As Integer, p As PlayerProfile)
            If p.IncarnationTraits Is Nothing OrElse p.IncarnationTraits.Count = 0 Then
                Console(session, 160, 130, 180, "No incarnation traits recorded yet.")
            Else
                Console(session, 190, 150, 230, "INCARNATION " & p.Incarnation.ToString() & " TRAITS | " & String.Join(" | ", p.IncarnationTraits.ToArray()))
            End If
        End Sub

        ' ============================================================
        ' SONIC SCREWDRIVER
        ' ============================================================

        Private Function NormalizeSonicMode(mode As String) As String
            mode = If(mode, "").Trim().ToLowerInvariant().Replace(" ", "")
            Select Case mode
                Case "scan", "analyze", "unlock", "repair", "disrupt", "interface", "medical", "lifesigns", "overload"
                    Return mode
                Case Else
                    Return "scan"
            End Select
        End Function

        Private Sub UseSonic(session As Integer, p As PlayerProfile, sender As AW.Instance, action As String)
            EnsureV4Profile(p)
            If Not p.SonicOwned Then
                Console(session, 210, 100, 80, "No sonic screwdriver is registered to this biodata profile.")
                Return
            End If
            Dim mode As String = GetParam(action, "mode")
            If mode = "" Then mode = p.SonicMode Else mode = NormalizeSonicMode(mode)
            p.SonicMode = mode
            Dim material As String = GetParam(action, "material").ToLowerInvariant()
            If material = "wood" OrElse material = "wooden" Then
                Console(session, 210, 130, 70, "The sonic screwdriver buzzes indignantly. Still doesn't do wood.")
                Return
            End If
            Dim difficulty As Integer = RpgRules.Clamp(ParseInt(GetParam(action, "difficulty"), 40), 1, 100)
            If mode = "overload" Then
                If p.ArtronReserve < 15 Then
                    Console(session, 220, 80, 80, "Sonic overload requires 15 Artron.")
                    Return
                End If
                p.ArtronReserve -= 15
                difficulty = Math.Min(100, difficulty + 15)
            End If

            Dim check As SkillCheckResult = PerformSkillCheck(p, "Sonic Technology", difficulty)
            If check.Success Then
                Dim resultText As String = GetParam(action, "result")
                If resultText = "" Then resultText = sender.GetString(Attributes.ObjectDescription)
                Select Case mode
                    Case "medical", "lifesigns"
                        Console(session, 90, 200, 180, "SONIC MEDICAL SCAN | Health " & p.Health.ToString() & "/" & p.MaxHealth.ToString() & " | H1 " & p.HeartOneHealth.ToString() & " | H2 " & p.HeartTwoHealth.ToString() & ".")
                    Case "repair"
                        Dim systemName As String = GetParam(action, "system")
                        If systemName <> "" Then RepairTardis(p, systemName, difficulty, session) Else Console(session, 100, 190, 210, "Sonic repair field stabilizes the target circuitry.")
                    Case "unlock"
                        Console(session, 100, 200, 200, "Sonic resonance releases the lock.")
                    Case "interface"
                        Console(session, 100, 200, 220, "Sonic interface handshake accepted. " & resultText)
                    Case "disrupt"
                        Console(session, 120, 190, 230, "Sonic disruption pulse lands cleanly. " & resultText)
                    Case "overload"
                        Console(session, 230, 190, 80, "SONIC OVERLOAD SUCCESSFUL. " & resultText)
                    Case Else
                        Console(session, 100, 200, 220, "SONIC " & mode.ToUpperInvariant() & ": " & resultText)
                End Select
            Else
                Console(session, 220, 110, 80, "Sonic " & mode & " attempt fails (" & check.Roll.ToString() & "/" & check.Target.ToString() & ").")
                If check.CriticalFailure AndAlso mode = "overload" Then ApplyDamage(p, 8, "energy", session, "sonic feedback")
            End If
            ReportSkillGain(session, "Sonic Technology", check)
        End Sub

        ' ============================================================
        ' ENCOUNTERS / NPC ENEMIES
        ' ============================================================

        Private Sub HandleEnemyAction(session As Integer, sender As AW.Instance, action As String)
            EnsureV3Initialized()
            Dim p As PlayerProfile = _sessions(session)
            If p.IsDead Then
                Console(session, 200, 70, 70, "A dead incarnation cannot engage an encounter.")
                Return
            End If
            If HasStatus(p, "Unconscious") Then
                Console(session, 200, 90, 90, "You are unconscious and cannot act.")
                Return
            End If

            Dim worldName As String = CurrentWorld(sender)
            Dim id As String = GetParam(action, "id")
            If id = "" Then id = sender.GetString(Attributes.ObjectDescription).Replace(" ", "_") & "_" & sender.GetInt(Attributes.ObjectX).ToString() & "_" & sender.GetInt(Attributes.ObjectZ).ToString()
            Dim key As String = worldName & ":" & id
            Dim enemy As EnemyState = Nothing
            If Not _enemies.TryGetValue(key, enemy) Then
                enemy = New EnemyState()
                enemy.Key = key
                enemy.Id = id
                enemy.WorldName = worldName
                enemy.Name = GetParam(action, "name")
                If enemy.Name = "" Then enemy.Name = sender.GetString(Attributes.ObjectDescription)
                If enemy.Name = "" Then enemy.Name = "Hostile"
                enemy.Species = GetParam(action, "species")
                If enemy.Species = "" Then enemy.Species = "Unknown"
                enemy.MaxHealth = Math.Max(1, ParseInt(GetParam(action, "hp"), 40))
                enemy.Health = enemy.MaxHealth
                enemy.Defense = RpgRules.Clamp(ParseInt(GetParam(action, "defense"), 45), 1, 100)
                enemy.Attack = Math.Max(1, ParseInt(GetParam(action, "attack"), 10))
                enemy.AttackDifficulty = RpgRules.Clamp(ParseInt(GetParam(action, "attackdifficulty"), 45), 1, 100)
                enemy.DamageType = GetParam(action, "damagetype")
                If enemy.DamageType = "" Then enemy.DamageType = "energy"
                ApplySpeciesTemplate(enemy, action)
                _enemies(key) = enemy
            End If

            If enemy.IsDefeated OrElse enemy.Health <= 0 Then
                Console(session, 120, 160, 160, enemy.Name & " has already been neutralized.")
                Return
            End If

            Dim approach As String = GetParam(action, "approach").ToLowerInvariant()
            If approach = "" Then approach = "combat"
            Dim skillName As String = "Combat"
            Select Case approach
                Case "sonic" : skillName = "Sonic Technology"
                Case "diplomacy", "talk" : skillName = "Diplomacy"
                Case "stealth", "evade" : skillName = "Stealth"
                Case "psychic" : skillName = "Psychic"
                Case "investigate" : skillName = "Investigation"
            End Select

            If approach = "sonic" AndAlso GetParam(action, "material").ToLowerInvariant() = "wood" Then
                Console(session, 210, 130, 70, "The sonic screwdriver cannot affect the wooden target.")
                EnemyRetaliate(session, p, enemy)
                Return
            End If

            Dim speciesPressure As Double = 1.0
            Dim speciesDifficulty As Integer = 0
            If Not SpeciesEncounterRule(session, p, enemy, approach, speciesPressure, speciesDifficulty) Then Return
            Dim encounterDifficulty As Integer = RpgRules.Clamp(enemy.Defense + speciesDifficulty, 1, 100)
            Dim check As SkillCheckResult = PerformSkillCheck(p, skillName, encounterDifficulty)
            If check.Success Then
                Dim pressure As Integer = 8 + CInt(Math.Floor(GetSkillValue(p, skillName) / 8.0))
                If approach <> "combat" Then pressure += 4
                pressure = Math.Max(1, CInt(Math.Round(pressure * speciesPressure)))
                If check.CriticalSuccess Then pressure *= 2
                enemy.Health = Math.Max(0, enemy.Health - pressure)
                Console(session, 90, 200, 150, skillName & " succeeds against " & enemy.Name & ": encounter integrity " & enemy.Health.ToString() & "/" & enemy.MaxHealth.ToString() & ".")
            Else
                Console(session, 220, 110, 80, skillName & " fails against " & enemy.Name & ".")
            End If
            ReportSkillGain(session, skillName, check)

            If enemy.Health <= 0 Then
                enemy.IsDefeated = True
                enemy.DefeatedBy = p.Name
                enemy.DefeatedUtc = DateTime.UtcNow
                p.EnemiesDefeated += 1
                Dim reward As Integer = Math.Max(0, ParseInt(GetParam(action, "rewardartron"), 10))
                p.ArtronReserve = Math.Min(p.MaxArtronReserve, p.ArtronReserve + reward)
                Console(session, 230, 190, 90, enemy.Name & " NEUTRALIZED via " & approach.ToUpperInvariant() & ". Artron reward: " & reward.ToString() & ".")
                Dim faction As String = GetParam(action, "faction")
                If faction <> "" Then ChangeReputation(session, p, faction, ParseInt(GetParam(action, "reputation"), 2))
                Dim missionId As String = GetParam(action, "missionid")
                If missionId <> "" Then ProgressMission(session, p, missionId, 1)
                EvaluateAchievements(session, p)
                OnEnemyDefeatedV4(session, p, enemy, approach)
                SaveEnemyStates()
                SaveProfiles()
                Return
            End If

            ' Successful diplomacy/stealth can avoid retaliation; direct conflict usually cannot.
            If Not check.Success OrElse approach = "combat" OrElse approach = "sonic" OrElse approach = "psychic" Then EnemyRetaliate(session, p, enemy)
            SaveEnemyStates()
            SaveProfiles()
        End Sub

        Private Sub EnemyRetaliate(session As Integer, p As PlayerProfile, enemy As EnemyState)
            Dim evade As SkillCheckResult = PerformSkillCheck(p, "Combat", enemy.AttackDifficulty)
            If evade.CriticalSuccess Then
                Console(session, 100, 190, 220, "You evade " & enemy.Name & " completely.")
                Return
            End If
            Dim amount As Integer = enemy.Attack
            If evade.Success Then amount = Math.Max(1, amount \ 2)
            If evade.CriticalFailure Then amount = CInt(Math.Ceiling(amount * 1.5))
            ApplyDamage(p, amount, enemy.DamageType, session, enemy.Name)
        End Sub

        ' ============================================================
        ' MISSIONS / DISTRESS CALLS
        ' ============================================================

        Private Sub GenerateDistressCall(session As Integer, p As PlayerProfile, currentWorld As String)
            Dim unique As New List(Of TardisDestination)()
            Dim seen As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
            For Each d As TardisDestination In _destinations.Values
                Dim k As String = d.WorldName & ":" & d.Name
                If seen.Add(k) Then unique.Add(d)
            Next
            If unique.Count = 0 Then
                Console(session, 180, 100, 100, "No navigation destinations are available for distress traffic.")
                Return
            End If
            Dim dsel As TardisDestination = unique(_rng.Next(0, unique.Count))
            Dim worldName As String = If(String.IsNullOrWhiteSpace(dsel.WorldName), currentWorld, dsel.WorldName)
            Dim id As String = "distress_" & DateTime.UtcNow.ToString("yyyyMMddHHmmss")
            Dim m As New MissionProgress With {
                .Id = id,
                .Title = "Distress Call: " & dsel.Name,
                .Objective = "Reach " & dsel.Name & " and investigate the emergency signal.",
                .Required = 1,
                .Destination = dsel.Name & " [" & worldName & "]"
            }
            p.Missions.Add(m)
            Console(session, 240, 150, 70, "DISTRESS SIGNAL RECEIVED — " & m.Title & ".")
            Console(session, 160, 190, 230, m.Objective)
        End Sub

        Private Sub StartMission(session As Integer, p As PlayerProfile, action As String)
            Dim id As String = GetParam(action, "id")
            If id = "" Then id = "mission_" & DateTime.UtcNow.ToString("yyyyMMddHHmmss")
            Dim existing As MissionProgress = FindMission(p, id)
            If existing IsNot Nothing AndAlso existing.Status = "active" Then
                Console(session, 170, 150, 100, "Mission already active: " & existing.Title & ".")
                Return
            End If
            Dim m As New MissionProgress With {
                .Id = id,
                .Title = If(GetParam(action, "title") = "", id, GetParam(action, "title")),
                .Objective = GetParam(action, "objective"),
                .Required = Math.Max(1, ParseInt(GetParam(action, "required"), 1)),
                .Destination = GetParam(action, "destination")
            }
            p.Missions.Add(m)
            Console(session, 240, 170, 80, "MISSION ACCEPTED: " & m.Title & ".")
            If m.Objective <> "" Then Console(session, 150, 190, 230, m.Objective)
        End Sub

        Private Function FindMission(p As PlayerProfile, id As String) As MissionProgress
            If p.Missions Is Nothing Then p.Missions = New List(Of MissionProgress)()
            For Each m As MissionProgress In p.Missions
                If String.Equals(m.Id, id, StringComparison.OrdinalIgnoreCase) Then Return m
            Next
            Return Nothing
        End Function

        Private Sub ProgressMission(session As Integer, p As PlayerProfile, id As String, amount As Integer)
            Dim m As MissionProgress = FindMission(p, id)
            If m Is Nothing OrElse m.Status <> "active" Then
                Console(session, 180, 120, 100, "No active mission named '" & id & "'.")
                Return
            End If
            m.Current = Math.Min(m.Required, m.Current + amount)
            Console(session, 140, 200, 220, "MISSION: " & m.Title & " — " & m.Current.ToString() & "/" & m.Required.ToString() & ".")
            If m.Current >= m.Required Then CompleteMission(session, p, id)
        End Sub

        Private Sub CompleteMission(session As Integer, p As PlayerProfile, id As String)
            Dim m As MissionProgress = FindMission(p, id)
            If m Is Nothing Then Return
            If m.Status = "completed" Then Return
            m.Status = "completed"
            m.CompletedUtc = DateTime.UtcNow
            p.MissionsCompleted += 1
            p.ArtronReserve = Math.Min(p.MaxArtronReserve, p.ArtronReserve + 20)
            Console(session, 240, 200, 80, "MISSION COMPLETE: " & m.Title & ". +20 Artron.")
            EvaluateAchievements(session, p)
        End Sub

        Private Sub FailMission(session As Integer, p As PlayerProfile, id As String)
            Dim m As MissionProgress = FindMission(p, id)
            If m Is Nothing Then Return
            m.Status = "failed"
            m.CompletedUtc = DateTime.UtcNow
            Console(session, 210, 90, 90, "MISSION FAILED: " & m.Title & ".")
        End Sub

        Private Sub ShowActiveMissions(session As Integer, p As PlayerProfile)
            Dim active As New List(Of String)()
            If p.Missions IsNot Nothing Then
                For Each m As MissionProgress In p.Missions
                    If m.Status = "active" Then active.Add(m.Title & " " & m.Current.ToString() & "/" & m.Required.ToString())
                Next
            End If
            If active.Count = 0 Then Console(session, 130, 150, 170, "No active missions.") Else Console(session, 240, 180, 80, "ACTIVE MISSIONS | " & String.Join(" | ", active.ToArray()))
        End Sub

        ' ============================================================
        ' DISCOVERY / TRAVEL / REPUTATION / ACHIEVEMENTS
        ' ============================================================

        Private Sub RecordTravel(session As Integer, p As PlayerProfile, d As TardisDestination, worldName As String)
            If p.TravelLog Is Nothing Then p.TravelLog = New List(Of TravelRecord)()
            p.TravelLog.Add(New TravelRecord With {.Destination = d.Name, .WorldName = worldName, .VisitedUtc = DateTime.UtcNow})
            While p.TravelLog.Count > 100
                p.TravelLog.RemoveAt(0)
            End While
            p.FlightsCompleted += 1
            If p.TardisHull >= 90 AndAlso p.TardisTemporalIntegrity >= 90 AndAlso p.TardisPower >= 90 Then p.PerfectLandings += 1
            RecordDiscovery(session, p, "destination:" & worldName & ":" & d.Name, d.Name, worldName)
            If p.Missions IsNot Nothing Then
                Dim toProgress As New List(Of String)()
                For Each m As MissionProgress In p.Missions
                    If m.Status = "active" AndAlso m.Destination <> "" AndAlso m.Destination.IndexOf(d.Name, StringComparison.OrdinalIgnoreCase) >= 0 Then toProgress.Add(m.Id)
                Next
                For Each missionId As String In toProgress
                    ProgressMission(session, p, missionId, 1)
                Next
            End If
            EvaluateAchievements(session, p)
            SaveProfiles()
        End Sub

        Private Sub RecordDiscovery(session As Integer, p As PlayerProfile, id As String, title As String, worldName As String)
            If p.Discoveries Is Nothing Then p.Discoveries = New List(Of DiscoveryRecord)()
            For Each d As DiscoveryRecord In p.Discoveries
                If String.Equals(d.Id, id, StringComparison.OrdinalIgnoreCase) Then Return
            Next
            p.Discoveries.Add(New DiscoveryRecord With {.Id = id, .Name = title, .WorldName = worldName, .DiscoveredUtc = DateTime.UtcNow})
            p.ArtronReserve = Math.Min(p.MaxArtronReserve, p.ArtronReserve + 3)
            Console(session, 190, 160, 240, "DISCOVERED: " & title & " [" & worldName & "] — +3 Artron.")
            Dim inv As SkillCheckResult = PerformSkillCheck(p, "Investigation", 25)
            ReportSkillGain(session, "Investigation", inv)
            EvaluateAchievements(session, p)
        End Sub

        Private Function GetFaction(p As PlayerProfile, factionName As String) As FactionStanding
            If p.Factions Is Nothing Then p.Factions = New List(Of FactionStanding)()
            For Each f As FactionStanding In p.Factions
                If String.Equals(f.Name, factionName, StringComparison.OrdinalIgnoreCase) Then Return f
            Next
            Dim created As New FactionStanding With {.Name = factionName, .Reputation = 0}
            p.Factions.Add(created)
            Return created
        End Function

        Private Sub ChangeReputation(session As Integer, p As PlayerProfile, factionName As String, amount As Integer)
            If String.IsNullOrWhiteSpace(factionName) OrElse amount = 0 Then Return
            Dim f As FactionStanding = GetFaction(p, factionName.Trim())
            f.Reputation = RpgRules.Clamp(f.Reputation + amount, -1000, 1000)
            Console(session, If(amount >= 0, 110, 220), If(amount >= 0, 190, 100), 170, factionName & " reputation " & If(amount >= 0, "+", "") & amount.ToString() & " => " & f.Reputation.ToString() & ".")
        End Sub

        Private Sub ShowReputation(session As Integer, p As PlayerProfile)
            If p.Factions Is Nothing OrElse p.Factions.Count = 0 Then
                Console(session, 150, 150, 170, "No faction reputation recorded.")
                Return
            End If
            Dim parts As New List(Of String)()
            For Each f As FactionStanding In p.Factions
                parts.Add(f.Name & " " & f.Reputation.ToString())
            Next
            Console(session, 170, 160, 220, "REPUTATION | " & String.Join(" | ", parts.ToArray()))
        End Sub

        Private Sub AwardAchievement(session As Integer, p As PlayerProfile, title As String)
            If p.Achievements Is Nothing Then p.Achievements = New List(Of String)()
            For Each a As String In p.Achievements
                If String.Equals(a, title, StringComparison.OrdinalIgnoreCase) Then Return
            Next
            p.Achievements.Add(title)
            Console(session, 245, 205, 60, "ACHIEVEMENT UNLOCKED: " & title & ".")
        End Sub

        Private Sub EvaluateAchievements(session As Integer, p As PlayerProfile)
            If p.FlightsCompleted >= 1 Then AwardAchievement(session, p, "First Flight")
            If p.FlightsCompleted >= 25 Then AwardAchievement(session, p, "Seasoned Traveller")
            If p.PerfectLandings >= 10 Then AwardAchievement(session, p, "Like a Glove")
            If p.Discoveries IsNot Nothing AndAlso p.Discoveries.Count >= 10 Then AwardAchievement(session, p, "Wanderer in the Fourth Dimension")
            If p.EnemiesDefeated >= 1 Then AwardAchievement(session, p, "Everybody Lives... Eventually")
            If p.MissionsCompleted >= 5 Then AwardAchievement(session, p, "Answering the Call")
            If p.LivesSaved >= 1 Then AwardAchievement(session, p, "Just This Once, Everybody Lives")
            If p.Incarnation >= 2 Then AwardAchievement(session, p, "New Teeth")
            EnsureSkills(p)
            For Each s As SkillProgress In p.Skills
                If s.Value >= 75 Then AwardAchievement(session, p, "Expert: " & s.Name)
                If s.Value >= 99 Then AwardAchievement(session, p, "Master: " & s.Name)
            Next
        End Sub

        Private Sub ShowAchievements(session As Integer, p As PlayerProfile)
            If p.Achievements Is Nothing OrElse p.Achievements.Count = 0 Then Console(session, 160, 150, 170, "No achievements unlocked yet.") Else Console(session, 245, 200, 70, "ACHIEVEMENTS | " & String.Join(" | ", p.Achievements.ToArray()))
        End Sub

        Private Sub ShowTravelLog(session As Integer, p As PlayerProfile)
            If p.TravelLog Is Nothing OrElse p.TravelLog.Count = 0 Then
                Console(session, 140, 150, 170, "Travel log is empty.")
                Return
            End If
            Dim start As Integer = Math.Max(0, p.TravelLog.Count - 8)
            Dim parts As New List(Of String)()
            For i As Integer = start To p.TravelLog.Count - 1
                Dim t As TravelRecord = p.TravelLog(i)
                parts.Add(t.Destination & " [" & t.WorldName & "]")
            Next
            Console(session, 100, 180, 225, "RECENT TRAVEL | " & String.Join(" | ", parts.ToArray()))
        End Sub

        ' ============================================================
        ' HUD
        ' ============================================================

        Public Sub EventHudClick(sender As AW.Instance)
            On Error Resume Next
            Dim session As Integer = sender.GetInt(Attributes.HudElementSession)
            Dim id As Integer = sender.GetInt(Attributes.HudElementId)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            Select Case id
                Case 7320 : ShowTimeLordStatus(session, p)
                Case 7321 : ShowSkills(session, p)
                Case 7322 : ShowActiveMissions(session, p)
                Case 7323 : ShowTravelLog(session, p)
                Case 7324 : ShowAchievements(session, p)
                Case 7325 : ShowInventory(session, p)
                Case 7326 : ShowAcademy(session, p)
                Case 7327 : ShowCompanions(session, p)
                Case 7328 : ShowParadox(session, p)
                Case 7329 : ShowSonicProfile(session, p)
                Case 7330 : ShowTardisRooms(session, p)
                Case 7399
                    p.HudEnabled = False
                    ClearRpgHud(session)
                    SaveProfiles()
                    Console(session, 140, 140, 170, "TARDIS HUD hidden. Use a console HUD toggle to restore it.")
                    Return
            End Select
            RefreshRpgHud(session, True)
        End Sub

        Private Sub TickV3(now As DateTime)
            EnsureV3Initialized()
            For Each pair As KeyValuePair(Of Integer, PlayerProfile) In New Dictionary(Of Integer, PlayerProfile)(_sessions)
                Dim session As Integer = pair.Key
                Dim p As PlayerProfile = pair.Value
                If p.IsTimeLord AndAlso (p.HeartOneHealth <= 0 Xor p.HeartTwoHealth <= 0) Then
                    Dim mayTick As Boolean = Not _lastHeartTick.ContainsKey(session) OrElse (now - _lastHeartTick(session)).TotalSeconds >= 20
                    If mayTick Then
                        _lastHeartTick(session) = now
                        p.Health = Math.Max(1, p.Health - 1)
                        Console(session, 210, 100, 100, "Single-heart strain: Health " & p.Health.ToString() & "/" & p.MaxHealth.ToString() & ".")
                        If p.HudEnabled Then RefreshRpgHud(session, True)
                    End If
                End If
            Next
        End Sub

        Private Sub RefreshRpgHud(session As Integer, force As Boolean)
            If _sdk Is Nothing OrElse Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            If Not p.HudEnabled Then Return
            Dim now As DateTime = DateTime.UtcNow
            If Not force AndAlso _lastHudRefresh.ContainsKey(session) AndAlso (now - _lastHudRefresh(session)).TotalSeconds < 2 Then Return
            _lastHudRefresh(session) = now

            ' IMPORTANT: do not destroy/recreate the HUD on every refresh.
            ' HudCreate with the same IDs updates the existing elements in place.
            ' This removes the visible flicker caused by ClearRpgHud + Transition.
            EnsureV4Profile(p)
            CreateHudImage(session, 7300, "ghud-container2.png", 310, -250, 300, 570)
            CreateHudText(session, 7301, ShortText(p.Title, 22) & " // INC " & p.Incarnation.ToString(), 330, -198, 250, 24, 24, 24, 24, False)
            CreateHudImage(session, 7302, "ghud-healthpotion.png", 328, -160, 22, 36)
            CreateHudText(session, 7303, "HEALTH  " & p.Health.ToString() & "/" & p.MaxHealth.ToString(), 355, -157, 210, 22, 35, 35, 35, False)
            CreateHudImage(session, 7304, "ghud-manapotion.png", 328, -123, 26, 26)
            CreateHudText(session, 7305, "ARTRON  " & p.ArtronReserve.ToString() & "/" & p.MaxArtronReserve.ToString(), 355, -122, 210, 22, 35, 35, 35, False)
            If p.IsTimeLord Then CreateHudText(session, 7306, "HEARTS  " & p.HeartOneHealth.ToString() & " / " & p.HeartTwoHealth.ToString(), 330, -90, 240, 22, 35, 35, 35, False)
            CreateHudText(session, 7307, "TARDIS H" & p.TardisHull.ToString() & " T" & p.TardisTemporalIntegrity.ToString() & " P" & p.TardisPower.ToString(), 330, -61, 245, 22, 35, 35, 35, False)

            Dim statusText As String = "Stable"
            If p.StatusEffects IsNot Nothing AndAlso p.StatusEffects.Count > 0 Then statusText = p.StatusEffects(0).Name
            CreateHudText(session, 7308, "STATUS  " & statusText, 330, -32, 245, 22, 35, 35, 35, False)
            CreateHudText(session, 7310, "PARADOX " & p.ParadoxLevel.ToString() & "/100  |  " & p.AcademyRank, 330, -5, 245, 22, 35, 35, 35, False)

            Dim activeMission As MissionProgress = FirstActiveMission(p)
            If activeMission Is Nothing Then
                CreateHudText(session, 7309, "MISSION  None", 330, 24, 245, 34, 45, 45, 45, False)
            Else
                CreateHudText(session, 7309, "MISSION  " & ShortText(activeMission.Title, 24) & " " & activeMission.Current.ToString() & "/" & activeMission.Required.ToString(), 330, 24, 245, 34, 45, 45, 45, False)
            End If

            CreateHudText(session, 7320, "STATUS", 330, 76, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7321, "SKILLS", 462, 76, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7322, "MISSIONS", 330, 106, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7323, "TRAVEL", 462, 106, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7324, "ACHIEVEMENTS", 330, 136, 244, 24, 28, 28, 28, True)
            CreateHudText(session, 7325, "INVENTORY", 330, 166, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7326, "ACADEMY", 462, 166, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7327, "COMPANION", 330, 196, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7328, "PARADOX", 462, 196, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7329, "SONIC", 330, 226, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7330, "ROOMS", 462, 226, 112, 24, 28, 28, 28, True)
            CreateHudText(session, 7399, "CLOSE HUD", 390, 266, 125, 24, 18, 18, 18, True)
        End Sub

        Private Function FirstActiveMission(p As PlayerProfile) As MissionProgress
            If p.Missions Is Nothing Then Return Nothing
            For Each m As MissionProgress In p.Missions
                If m.Status = "active" Then Return m
            Next
            Return Nothing
        End Function

        Private Function ShortText(value As String, maxLength As Integer) As String
            If value Is Nothing Then Return ""
            If value.Length <= maxLength Then Return value
            Return value.Substring(0, Math.Max(1, maxLength - 3)) & "..."
        End Function

        Private Sub ClearRpgHud(session As Integer)
            If _sdk Is Nothing OrElse session <= 0 Then Return
            On Error Resume Next
            For id As Integer = 7300 To 7399
                _sdk.HudDestroy(session, id)
            Next
        End Sub

        Private Sub CreateHudImage(session As Integer, id As Integer, texture As String, x As Integer, y As Integer, width As Integer, height As Integer)
            ' AW/DeltaWorlds HUD Z ordering places LOWER Z values nearer the viewer.
            ' Keep artwork at a large Z so text is rendered in front of it.
            CreateHudElement(1, texture, id, session, x, y, 100, width, height, 255, 255, 255, False)
        End Sub

        Private Sub CreateHudText(session As Integer, id As Integer, text As String, x As Integer, y As Integer, width As Integer, height As Integer, red As Integer, green As Integer, blue As Integer, clickable As Boolean)
            ' LOWER Z values render closer to the viewer in AW/DeltaWorlds.
            ' Clickable labels sit closest, ordinary text just behind them, artwork farthest back.
            CreateHudElement(0, text, id, session, x, y, If(clickable, 1, 5), width, height, red, green, blue, clickable)
        End Sub

        Private Sub CreateHudElement(hudType As Integer, text As String, id As Integer, session As Integer, x As Integer, y As Integer, z As Integer, width As Integer, height As Integer, red As Integer, green As Integer, blue As Integer, clickable As Boolean)
            On Error Resume Next
            ' Persistent HUD elements should not use Transition. Re-applying an element
            ' with Transition causes the AW client to animate/fade it again, which looks
            ' like flicker when live stats are refreshed.
            Dim flags As Integer = CInt(AW.HudElementFlag.Stretch)
            If clickable Then flags = flags Or CInt(AW.HudElementFlag.Clicks)
            _sdk.SetInt(Attributes.HudElementType, hudType)
            _sdk.SetString(Attributes.HudElementText, If(text, ""))
            _sdk.SetInt(Attributes.HudElementId, id)
            _sdk.SetInt(Attributes.HudElementOrigin, AW.HudOrigin.Center)
            _sdk.SetFloat(Attributes.HudElementOpacity, If(hudType = 1, 0.96F, 1.0F))
            _sdk.SetInt(Attributes.HudElementX, x)
            _sdk.SetInt(Attributes.HudElementY, y)
            _sdk.SetInt(Attributes.HudElementZ, z)
            _sdk.SetInt(Attributes.HudElementFlags, flags)
            _sdk.SetInt(Attributes.HudElementSession, session)
            _sdk.SetInt(Attributes.HudElementColor, HudColor(red, green, blue))
            _sdk.SetInt(Attributes.HudElementSizeX, width)
            _sdk.SetInt(Attributes.HudElementSizeY, height)
            _sdk.SetInt(Attributes.HudElementTextureOffsetX, 0)
            _sdk.SetInt(Attributes.HudElementTextureOffsetY, 0)
            _sdk.HudCreate()
        End Sub

        Private Function HudColor(red As Integer, green As Integer, blue As Integer) As Integer
            red = RpgRules.Clamp(red, 0, 255)
            green = RpgRules.Clamp(green, 0, 255)
            blue = RpgRules.Clamp(blue, 0, 255)
            Return red Or (green << 8) Or (blue << 16)
        End Function

    End Class
End Namespace
