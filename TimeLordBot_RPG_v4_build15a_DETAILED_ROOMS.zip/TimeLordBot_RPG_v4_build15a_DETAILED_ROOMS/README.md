﻿# TimeLordBot — Standalone DeltaWorlds Time Lord RPG

TimeLordBot is a standalone VB.NET / AW.Core Doctor Who RPG bot extracted from DWMyths. It contains no meditation, Korth, Draeda crafting, Lumina Codex, tea, shrine, or self-help systems.

## Current game loop

Explore -> operate the TARDIS -> make skill checks -> take damage/status effects -> heal or repair -> improve skills -> survive/regenerate -> continue the incarnation.

Profiles are persisted to `TimeLordProfiles.xml` beside the executable.

## Build

Open `TimeLordBot.sln` in Visual Studio and build the .NET Framework 4.8 x86 target. `AW.Core.dll` and `aw.dll` are included in the project folder.

## Time Lord profile

A profile now persists:

- Time Lord / non-Time-Lord biology
- alive/dead state
- incarnation number
- regenerations remaining
- regeneration suppression
- Health / Max Health
- Artron reserve / maximum reserve
- 13 use-based RPG skills
- timed status effects
- incarnation history and cause of regeneration
- TARDIS hull integrity
- TARDIS temporal integrity
- TARDIS power
- personal TARDIS interior anchor

## Skills

Skills run from 0 to 100:

- Piloting
- Navigation
- Engineering
- Temporal Science
- Medicine
- Sonic Technology
- Psychic
- Diplomacy
- Investigation
- Combat
- Stealth
- Archaeology
- Xenobiology

Skill checks use a d100-style roll. Difficulty, current skill, critical success (1-5), critical failure (96-100), temporary status penalties, and use-based skill gain are all handled by the shared RPG engine.

Trivial checks stop yielding skill once a character significantly outclasses their difficulty. Skill gains become progressively smaller near mastery.

## Health and typed damage

Supported damage types are free-form, with built-in special behavior for:

- physical
- explosive
- fire
- radiation
- poison
- temporal
- psychic

Examples:

```
activate ~rpg action:damage,amount:20,damagetype:physical
activate ~rpg action:damage,amount:15,damagetype:radiation
activate ~rpg action:damage,amount:30,damagetype:temporal
activate ~rpg action:damage,amount:12,damagetype:fire
```

Damage can create secondary conditions. Temporal damage also drains Artron. At zero Health, a Time Lord with a functioning regeneration matrix automatically regenerates. Otherwise the incarnation dies.

## Healing

Object healing:

```
activate ~rpg action:heal,amount:20
```

TARDIS medical bay:

```
activate ~rpg action:medbay,difficulty:30
```

The medbay makes a Medicine check, heals more on success, trains Medicine, and can remove one harmful condition.

Time Lord Artron cellular repair:

```
activate ~timelord type:artronheal,amount:20
```

This spends personal Artron reserve and trains Medicine.

## Status effects

The bot has a live tick loop. Timed conditions expire automatically and several cause repeated damage/resource drain while active.

Built-in ticking conditions include:

- Burning
- Bleeding
- Poisoned
- Irradiated
- Artron Starved

Other implemented conditions include:

- Regeneration Sickness
- Temporal Displaced
- Psychically Overloaded

Apply and cure statuses from world objects:

```
activate ~rpg action:status,name:Poisoned,duration:90,potency:2
activate ~rpg action:status,name:Irradiated,duration:120,potency:3
activate ~rpg action:cure,name:Poisoned
```

## Regeneration

Time Lords begin with 12 regenerations unless configured otherwise.

Lethal damage automatically invokes regeneration when possible. Voluntary regeneration remains available while critically injured:

```
activate ~timelord type:regenerate
```

Each regeneration:

- ends the previous incarnation record with a cause and timestamp
- consumes one regeneration
- increments incarnation number
- restores Health
- restores some Artron energy
- creates a new incarnation-history entry
- applies 180 seconds of Regeneration Sickness

Regeneration Sickness increases incoming damage and reduces difficult skill performance.

Regeneration controls:

```
activate ~timelord type:awaken
activate ~timelord type:blockregen
activate ~timelord type:unblockregen
activate ~timelord type:status
activate ~timelord type:skills
```

## TARDIS condition

Every player profile has persistent TARDIS condition:

- Hull Integrity: 0-100
- Temporal Integrity: 0-100
- Power: 0-100

Damage a ship from an object/event:

```
activate ~rpg action:tardisdamage,amount:15,system:hull
activate ~rpg action:tardisdamage,amount:20,system:temporal
activate ~rpg action:tardisdamage,amount:10,system:power
```

Repair panel:

```
activate ~rpg action:repair,system:hull,difficulty:40
activate ~rpg action:repair,system:temporal,difficulty:55
activate ~rpg action:repair,system:power,difficulty:35
```

Repairs make Engineering checks and train Engineering. Critical failures can cause additional damage. A TARDIS at 0 Power or 0 Temporal Integrity is unable to dematerialise until repaired.

Bad flights now damage both the Time Lord and the TARDIS.

## Universal RPG object API

Any DeltaWorlds builder can create RPG content without editing the bot:

```
activate ~rpg action:damage,amount:20,damagetype:radiation
activate ~rpg action:heal,amount:15
activate ~rpg action:status,name:Burning,duration:30,potency:2
activate ~rpg action:cure,name:Burning
activate ~rpg action:skillcheck,skill:Engineering,difficulty:55
activate ~rpg action:artron,amount:-10
activate ~rpg action:artron,amount:25
activate ~rpg action:tardisdamage,amount:10,system:temporal
activate ~rpg action:repair,system:temporal,difficulty:50
activate ~rpg action:medbay,difficulty:30
activate ~rpg action:statusreport
activate ~rpg action:skills
```

This API is intended to become the common foundation for monsters, traps, missions, sonic puzzles, medicine, radiation zones, temporal anomalies, NPC encounters, and authored adventures.

## TARDIS flight controls

Examples:

```
activate ~tardiscontrol type:coordinates,destination:Draeda
activate ~tardiscontrol type:destinations
activate ~tardiscontrol type:reloadnav
activate ~tardiscontrol type:helmic
activate ~tardiscontrol type:artron,amount:10
activate ~tardiscontrol type:setinterior
activate ~tardiscontrol type:anchor
activate ~tardiscontrol type:lifesupport
activate ~tardiscontrol type:telepathic
activate ~tardiscontrol type:landingmode,mode:sealed
activate ~tardiscontrol type:handbrake
activate ~tardiscontrol type:hads,mode:on
activate ~tardiscontrol type:cloisterbell
activate ~tardiscontrol type:stabilize
activate ~tardiscontrol type:status
activate ~tardiscontrol type:dematerialise
```

Operating the console now trains relevant RPG skills:

- Coordinates -> Navigation
- Helmic regulator -> Engineering
- Architectural anchor -> Temporal Science
- Life support -> Engineering
- Telepathic circuits -> Psychic
- Dematerialisation -> Piloting

Critical calibration failures can leave the corresponding system unready.

## Multi-world destinations

Canonical destination format:

```
Name|World|X|Y|Z|Yaw|ArtronCost|aliases|NavigationDifficulty
```

Example:

```
Draeda|DWMyths|-20853|800|-17750|3580|10|draeda|30
Gallifrey|DoctorWho|1234|500|-6789|1800|25|gallifrey,capitol|70
```

Legacy local rows are still accepted:

```
Name|X|Y|Z|Yaw|ArtronCost
```

Same-world flight teleports the player and creates the physical return TARDIS shell. Cross-world flight uses `TeleportWorld` and deliberately does **not** attempt to create a TARDIS return object in the destination world.

## TARDIS return / interior anchor

Place this inside a player's TARDIS interior to establish their anchor:

```
activate ~tardiscontrol type:setinterior
```

Locally materialised TARDIS exterior shells use:

```
activate ~tardisreturn
```

The return action can itself cross worlds to the player's recorded interior anchor.

## Suggested world-building examples

Radiation leak:

```
activate ~rpg action:damage,amount:8,damagetype:radiation
```

Live wire:

```
activate ~rpg action:damage,amount:12,damagetype:energy
```

Temporal fissure:

```
activate ~rpg action:damage,amount:18,damagetype:temporal
```

Engineering puzzle:

```
activate ~rpg action:skillcheck,skill:Engineering,difficulty:65
```

Ancient Gallifreyan inscription:

```
activate ~rpg action:skillcheck,skill:Archaeology,difficulty:70
```

Alien autopsy / scanner station:

```
activate ~rpg action:skillcheck,skill:Xenobiology,difficulty:55
```

Psychic interface:

```
activate ~rpg action:skillcheck,skill:Psychic,difficulty:60
```

## Next systems designed to plug into this foundation

The next logical modules are NPC/enemy encounters, sonic screwdriver modes, two-heart trauma, unconscious/stabilisation mechanics, missions/distress calls, discoveries/travel log, faction reputation, achievements, incarnation traits, and non-combat encounter resolution.

# V3 — The Adventure Layer

V3 turns the persistent Time Lord/TARDIS simulation into an adventure RPG. Existing V2 object actions remain compatible.

## Two hearts and unconsciousness

Time Lords now persist two independent heart-condition values (0-100). Heavy physical, explosive, or energy trauma can damage one heart. Losing one heart creates Single Heart Trauma and slowly strains Health until treated. Losing both hearts forces lethal cardiac failure and therefore regeneration when available.

Low Health can also cause temporary Unconsciousness. Unconscious characters are effectively unable to perform useful skill checks and cannot engage enemies until stabilized.

```
activate ~timelord type:hearts
activate ~rpg action:heartdamage,heart:1,amount:25
activate ~rpg action:heartheal,amount:20
activate ~rpg action:revive,difficulty:45
activate ~rpg action:medbay,difficulty:30
```

The V3 medbay heals ordinary Health, cardiovascular damage, harmful status effects, and unconsciousness on a successful Medicine check.

## Incarnation traits

Each regeneration rolls two incarnation-specific traits. The permanent Time Lord keeps learned skills, history, TARDIS state, reputation, discoveries, achievements, and mission history, while the current incarnation receives its own aptitudes.

Current trait pool includes:

- Born Pilot
- Brilliant Engineer
- Temporal Intuition
- Psychic Sensitive
- Silver Tongue
- Field Medic
- Iron Constitution
- Artron Reservoir
- Shadow Walker
- Relentless Investigator
- Xenobiologist
- Sonic Savant

Most provide +8 effective skill to their specialty. Iron Constitution increases maximum Health and reduces incoming damage; Artron Reservoir increases maximum Artron reserve.

```
activate ~timelord type:traits
```

## Sonic screwdriver

Every profile now remembers a sonic mode:

- scan
- analyze
- unlock
- repair
- disrupt
- interface
- medical
- lifesigns
- overload

Set a mode:

```
activate ~timelord type:sonic,mode:scan
activate ~rpg action:sonicmode,mode:interface
```

Use it on an object:

```
activate ~rpg action:sonic,mode:scan,difficulty:30,result:Gallifreyan circuitry detected
activate ~rpg action:sonic,mode:unlock,difficulty:45
activate ~rpg action:sonic,mode:interface,difficulty:55,result:Archive node connected
activate ~rpg action:sonic,mode:medical,difficulty:35
activate ~rpg action:sonic,mode:repair,difficulty:50,system:temporal
activate ~rpg action:sonic,mode:overload,difficulty:65,result:The containment field collapses
```

Objects tagged `material:wood` automatically defeat sonic use, because of course they do.

## NPC / enemy encounters

Any world object can become a persistent encounter by putting `~enemy` in its action.

Example hostile Dalek:

```
activate ~enemy id:dalek01,name:Dalek Scout,species:Dalek,hp:70,defense:65,attack:18,attackdifficulty:55,damagetype:energy,rewardartron:15,faction:Gallifrey,reputation:2,approach:combat
```

The `approach:` value decides the player's resolution skill:

- combat -> Combat
- sonic -> Sonic Technology
- diplomacy / talk -> Diplomacy
- stealth / evade -> Stealth
- psychic -> Psychic
- investigate -> Investigation

An encounter has persistent integrity/Health while the bot is running and is saved to `EnemyStates.xml`. Neutralizing it records the player, timestamp, reward, enemy-defeat statistic, optional faction reputation and optional mission progress.

Example nonviolent encounter:

```
activate ~enemy id:judooncheckpoint,name:Judoon Captain,species:Judoon,hp:45,defense:50,attack:12,damagetype:physical,approach:diplomacy,rewardartron:10
```

Example mission-linked encounter:

```
activate ~enemy id:cyberleader1,name:Cyber-Leader,species:Cyberman,hp:90,defense:70,attack:20,attackdifficulty:60,damagetype:energy,approach:sonic,missionid:cyber_tomb,rewardartron:25
```

## Missions and distress calls

A TARDIS console can now request a procedural distress call from the known destination database:

```
activate ~tardiscontrol type:distress
```

This creates a persistent active mission pointing toward a known TARDIS destination. Arriving there automatically advances destination-linked missions.

Builder-authored missions:

```
activate ~rpg action:missionstart,id:cyber_tomb,title:The Tomb Opens,objective:Investigate the Cyberman signal,required:3,destination:Draeda
activate ~rpg action:missionprogress,id:cyber_tomb,amount:1
activate ~rpg action:missioncomplete,id:cyber_tomb
activate ~rpg action:missionfail,id:cyber_tomb
```

View missions:

```
activate ~timelord type:missions
activate ~tardiscontrol type:mission
```

Note: the legacy object-parameter parser uses commas as separators, so mission titles/objectives and sonic result text should not contain literal commas.

## Discoveries and travel log

Every successful TARDIS materialisation is added to the character's travel log. A destination becomes a discovery the first time it is visited; discoveries award a small Artron recharge and an Investigation-learning opportunity.

World builders can define discoveries directly:

```
activate ~rpg action:discover,id:omega_vault,name:The Omega Vault
```

View recent travel:

```
activate ~timelord type:travellog
```

## Faction reputation

Reputation is generic rather than hardcoded, so a world can create any faction it needs:

```
activate ~rpg action:reputation,faction:Gallifrey,amount:5
activate ~rpg action:reputation,faction:UNIT,amount:3
activate ~rpg action:reputation,faction:Daleks,amount:-10
activate ~timelord type:reputation
```

Reputation is clamped between -1000 and +1000.

## Achievements and character history

V3 records flights, near-perfect landings, discoveries, enemies neutralized, missions completed, lives saved, regeneration history and mastered skills.

Automatic achievements include:

- First Flight
- Seasoned Traveller
- Like a Glove
- Wanderer in the Fourth Dimension
- Everybody Lives... Eventually
- Answering the Call
- Just This Once, Everybody Lives
- New Teeth
- Expert: <skill>
- Master: <skill>

```
activate ~timelord type:achievements
```

## Toggleable TARDIS HUD

V3 uses the supplied DeltaWorlds HUD textures. HUD state is persistent per player and is OFF by default.

Put this on a TARDIS console control:

```
activate ~tardiscontrol type:hud,mode:toggle
```

Or explicit controls:

```
activate ~tardiscontrol type:hud,mode:on
activate ~tardiscontrol type:hud,mode:off
```

The HUD displays:

- incarnation
- Health
- Artron reserve
- both Time Lord hearts
- TARDIS Hull / Temporal Integrity / Power
- current status effect
- current mission
- clickable Status / Skills / Missions / Travel / Achievements controls
- Close HUD

The HUD uses these supplied textures directly:

- `ghud-container2.png`
- `ghud-healthpotion.png`
- `ghud-manapotion.png`

All original supplied textures are included under `HUDTextures/` for future interfaces.

IMPORTANT: Active Worlds/DeltaWorlds HUD image elements resolve textures through the world's object path. Copy the HUD textures you use to the world's object-path texture location using the exact filenames. Keeping them only beside the bot executable does not make clients render them.

## V3 object recipe sheet

See `V3_OBJECT_RECIPES.txt` for ready-to-paste controls, medbay panels, hazards, sonic targets, discoveries, missions and sample encounters.

# V4 — Final Complete-RPG Layer

V4 connects the V2/V3 foundations into a broader persistent Doctor Who RPG.

New persistent systems:

- player species/biodata identity
- Gallifreyan Academy credits, ranks and generated titles
- inventory, consumables, equippable artifacts and skill bonuses
- owned/customisable sonic screwdriver with upgrade tiers
- travelling companions with loyalty and skill support
- paradox accumulation and temporal-stabilisation gameplay
- unlockable TARDIS rooms with gameplay functions
- xenobiology species catalogue
- species-aware enemies (Dalek, Cyberman, Weeping Angel, Sontaran, Judoon, Auton, Time Lord)
- procedural TARDIS adventures
- dialogue-tree/story-flag scripting
- expanded HUD access to Inventory / Academy / Companions / Paradox / Sonic / Rooms

## Final HUD controls

The HUD remains optional and can be toggled from a TARDIS console:

```
activate ~tardiscontrol type:hud,mode:toggle
```

V4 HUD buttons expose Status, Skills, Missions, Travel, Achievements, Inventory, Academy, Companion, Paradox, Sonic and TARDIS Rooms.

## Academy progression

Academy credits are earned from practical skill use, travel, field encounters, non-lethal resolutions, research and scripted rewards.

Ranks:

1. Initiate
2. Novice
3. Academy Graduate
4. Time Lord
5. Senior Time Lord
6. Cardinal
7. High Councillor

Higher ranks provide a small universal skill bonus rather than replacing use-based skill advancement.

## Inventory and artifacts

Builder example:

```
activate ~rpg action:itemgive,id:matrix_key,name:Matrix Key,type:artifact,qty:1,skill:Temporal Science,bonus:5,description:An ancient Gallifreyan access key
activate ~rpg action:equip,id:matrix_key
```

Consumables can use `type:healing` / `type:medkit` or `type:artron` / `type:artroncell`.

## Sonic screwdriver ownership

```
activate ~rpg action:sonicgrant,name:My Sonic Screwdriver
activate ~rpg action:soniccustomize,name:Vortex Key,casing:brass,emitter:blue-ring,crystal:kyber
activate ~rpg action:sonicupgrade,amount:1
```

The sonic now has persistent name, casing, emitter, crystal, upgrade tier and current mode. Upgrade tier modifies Sonic Technology checks.

## Companions

```
activate ~rpg action:companionadd,id:ace,name:Ace,species:Human,role:Companion,loyalty:70,skill:Combat,bonus:5
activate ~rpg action:companionactivate,id:ace
activate ~rpg action:companionloyalty,id:ace,amount:10
```

One active companion can contribute a loyalty-scaled skill bonus.

## Paradox

Paradox is a persistent 0-100 temporal-instability score. Cross-world TARDIS travel adds a small amount automatically; scripted temporal decisions can add or remove more.

```
activate ~rpg action:paradox,amount:20,source:Changed a fixed event
activate ~rpg action:paradoxstabilize
```

High paradox penalises Piloting, Navigation and Temporal Science and can cause temporal displacement/recoil.

## TARDIS rooms

Every profile begins with Console Room and Medical Bay. Rooms can be added by builders:

```
activate ~rpg action:roomunlock,name:Workshop
activate ~rpg action:roomunlock,name:Library
activate ~rpg action:roomunlock,name:Cloister Room
activate ~rpg action:roomunlock,name:Zero Room
```

Use:

```
activate ~rpg action:roomuse,name:Medical Bay,difficulty:30
activate ~rpg action:roomuse,name:Workshop,difficulty:45
activate ~rpg action:roomuse,name:Library,difficulty:40
activate ~rpg action:roomuse,name:Cloister Room
activate ~rpg action:roomuse,name:Zero Room
```

## Procedural adventures

A console can ask the TARDIS to find trouble:

```
activate ~tardiscontrol type:adventure
```

The bot chooses a navigation destination and creates a persistent mission hook. These adventures intentionally use the same mission/encounter/dialogue systems as authored content.

## Dialogue/story scripting

```
activate ~rpg action:dialogue,text:State your business.,skill:Diplomacy,difficulty:55,successtext:The guard steps aside.,failtext:The guard refuses.,setflag:citadel_access,faction:Gallifrey,reputation:2
```

Later nodes can require the flag:

```
activate ~rpg action:dialogue,requireflag:citadel_access,text:The sealed chamber is now open.,missionid:omega_case,progress:1
```

This creates lightweight branching adventures without recompiling the bot.


## Build Fix 2: Stable HUD + EventChat controls

The persistent HUD no longer destroys/recreates itself every two seconds and no longer uses the `Transition` flag. The parchment background is Z=1, normal text Z=20, and clickable labels Z=30 so artwork cannot cover the text. HUD content has also been moved down inside the parchment's writable area.

Chat controls are now supported through `EventChat`:

`/hud on`, `/hud off`, `/hud`, `/status`, `/skills`, `/missions`, `/travel`, `/achievements`, `/inventory`, `/academy`, `/companions`, `/paradox`, `/sonic`, `/rooms`, `/destinations`, `/distress`, `/adventure`, `/tardishelp`.

Console-operation chat shortcuts include `/tardis coordinates <destination>`, `/tardis helmic`, `/tardis artron <amount>`, `/tardis architecture`, `/tardis lifesupport`, `/tardis telepathic`, `/tardis handbrake`, and `/tardis dematerialise`. These invoke the same TARDIS control handlers as clickable console objects rather than a separate ruleset.

Natural roleplay triggers are intentionally conservative: `TARDIS show HUD`, `TARDIS hide HUD`, `TARDIS status`, `TARDIS destinations`, `TARDIS distress`, and `TARDIS adventure`.


## Build Fix 4 - Correct HUD depth ordering
DeltaWorlds/AW renders lower HUD Z values closer to the viewer. The parchment artwork now uses Z=100, ordinary text Z=5, and clickable labels Z=1. This fixes the parchment washing over otherwise-dark text.

## Operator Console (Build Fix 5)
The Windows application now doubles as a live GM/operator dashboard. In addition to the normal DeltaWorlds citizen/password, bot name, and home-world connection settings, the authentication host and port are editable (default `auth.deltaworlds.com:6671`).

The runtime panel shows connection state, current home world, uptime, players online, stored character profiles, unique TARDIS destinations, active flight-state count, and whether profile changes are waiting to be written. Operators can force a safe profile save, reload `TardisDestinations.txt` without restarting the bot, or open the bot data folder.

The Time Lord Profile Inspector works even while the bot is offline because profiles are loaded when the program starts. It can display all saved profiles or only currently online players and summarizes identity/title, incarnation/regenerations, health/two-heart condition, Artron, paradox, Academy rank, TARDIS health, flight/mission totals, discoveries, achievements, HUD/sonic state, status effects, active missions, skills, incarnation traits, and companions.


## Live GameMaster workstation

The Windows operator console now includes editable Destinations, Conversation, Zone and Avatar trigger grids, a conversation trigger tester, a scalar Profile Editor, persistent Enemy State editor, online GM action runner, and a Raw Files editor. Structured editors validate before saving and reload their rules without restarting the bot. See `GM_OPERATOR_GUIDE.txt`.
