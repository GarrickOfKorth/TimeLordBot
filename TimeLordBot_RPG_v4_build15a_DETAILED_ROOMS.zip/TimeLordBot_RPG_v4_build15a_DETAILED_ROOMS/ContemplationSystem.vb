﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Threading.Tasks
Imports AW

Namespace TimeLordBot

    Public Class ReadingEntry
        Public Id As String = ""
        Public Category As String = ""
        Public Title As String = ""
        Public Reward As Integer = 1
        Public Skill As String = "Investigation"
        Public Tags As String = ""
        Public Passages As New List(Of String)()

        ' Living Library metadata
        Public Rarity As String = "Common"
        Public Series As String = ""
        Public SeriesIndex As Integer = 0
        Public RequiresFlag As String = ""
        Public KnowledgeFlag As String = ""
        Public Reliability As String = "ordinary"
        Public Dangerous As Boolean = False
        Public HasChoice As Boolean = False
    End Class

    Public Class ReadingJournalEntry
        Public Property BookId As String = ""
        Public Property Title As String = ""
        Public Property Category As String = ""
        Public Property Reflection As Integer = 0
        Public Property Incarnation As Integer = 0
        Public Property Choice As String = ""
        Public Property ReadingPlace As String = ""
        Public Property CompletedUtc As DateTime = DateTime.UtcNow
    End Class

    Public Class ReadingBookmark
        Public Property BookId As String = ""
        Public Property NextPassage As Integer = 0
        Public Property UpdatedUtc As DateTime = DateTime.UtcNow
    End Class

    Friend Class ActiveReadingSession
        Public BookId As String = ""
        Public NextPassage As Integer = 0
        Public StartX As Integer
        Public StartY As Integer
        Public StartZ As Integer
        Public Cancelled As Boolean = False
        Public Token As Guid = Guid.NewGuid()

        Public ReadingPlace As String = ""
        Public AwaitingChoice As Boolean = False
        Public ChoiceResult As String = ""
        Public InterpretationSucceeded As Boolean = False
        Public SharedReading As Boolean = False
        Public ReadAloud As Boolean = False
        Public IsReread As Boolean = False
        Public LastReadIncarnation As Integer = 0
    End Class

    Friend Class ActiveMeditationSession
        Public DurationSeconds As Integer
        Public Reward As Integer
        Public SkillGain As Double
        Public StartUtc As DateTime
        Public EndUtc As DateTime
        Public StartX As Integer
        Public StartY As Integer
        Public StartZ As Integer
        Public PointId As String = ""
        Public NextAtmosphereUtc As DateTime = DateTime.MinValue
        Public AtmosphereCount As Integer = 0
        Public LastAtmosphereIndex As Integer = -1
    End Class

    Public Class MeditationPointRecord
        Public Id As String = ""
        Public Name As String = ""
        Public CommunityReflection As Integer = 0
        Public TotalStillnessSeconds As Long = 0
        Public Vitality As Integer = 50
        Public Caretaker As String = ""
        Public LastMeditatedUtc As DateTime = DateTime.MinValue
    End Class

    Public Partial Class TardisBot

        Private ReadOnly _readingArchive As New Dictionary(Of String, ReadingEntry)(StringComparer.OrdinalIgnoreCase)
        Private ReadOnly _activeReadings As New Dictionary(Of Integer, ActiveReadingSession)()
        Private ReadOnly _activeMeditations As New Dictionary(Of Integer, ActiveMeditationSession)()
        Private ReadOnly _selectedMeditationPoint As New Dictionary(Of Integer, String)()
        Private ReadOnly _meditationPoints As New Dictionary(Of String, MeditationPointRecord)(StringComparer.OrdinalIgnoreCase)
        Private _contemplationLoaded As Boolean = False

        Private Sub EnsureContemplationLoaded()
            If _contemplationLoaded Then Return
            _contemplationLoaded = True
            LoadReadingArchive()
            LoadMeditationPoints()
            _log("CONTEMPLATION | Loaded " & _readingArchive.Count.ToString() &
                 " readings and " & _meditationPoints.Count.ToString() & " meditation points.")
        End Sub

        Private Sub EnsureContemplationProfile(p As PlayerProfile)
            If p.BooksRead Is Nothing Then p.BooksRead = New List(Of String)()
            If p.ReadingJournal Is Nothing Then p.ReadingJournal = New List(Of ReadingJournalEntry)()
            If p.ReadingBookmarks Is Nothing Then p.ReadingBookmarks = New List(Of ReadingBookmark)()
            If p.ReadingKnowledge Is Nothing Then p.ReadingKnowledge = New List(Of String)()
            If p.ReadingMarginalia Is Nothing Then p.ReadingMarginalia = New List(Of String)()
            If p.ReadingFavorites Is Nothing Then p.ReadingFavorites = New List(Of String)()
            If p.BooksOwned Is Nothing Then p.BooksOwned = New List(Of String)()
            If p.ReadingAnnotations Is Nothing Then p.ReadingAnnotations = New List(Of ReadingAnnotation)()
            If p.ReadingSeriesCompleted Is Nothing Then p.ReadingSeriesCompleted = New List(Of String)()
            If p.ReadingContradictions Is Nothing Then p.ReadingContradictions = New List(Of String)()
            If p.ReadingSkill < 0 Then p.ReadingSkill = 0
            If p.MeditationSkill < 0 Then p.MeditationSkill = 0
        End Sub

        Private Sub LoadReadingArchive()
            _readingArchive.Clear()
            Dim path As String = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ReadingBooks.txt")
            If Not File.Exists(path) Then
                _log("READING | ReadingBooks.txt was not found.")
                Return
            End If

            For Each raw As String In File.ReadAllLines(path)
                Dim line As String = raw.Trim()
                If line = "" OrElse line.StartsWith("#") Then Continue For
                Dim parts() As String = line.Split(New String() {"||"}, StringSplitOptions.None)
                If parts.Length < 8 Then Continue For

                Dim e As New ReadingEntry()
                e.Id = parts(0).Trim()
                e.Category = parts(1).Trim()
                e.Title = parts(2).Trim()
                Integer.TryParse(parts(3).Trim(), e.Reward)
                If e.Reward <= 0 Then e.Reward = 1
                e.Skill = parts(4).Trim()
                e.Tags = parts(5).Trim()
                For i As Integer = 6 To parts.Length - 1
                    If parts(i).Trim() <> "" Then e.Passages.Add(parts(i).Trim())
                Next
                ConfigureAdvancedReading(e)
                If e.Id <> "" AndAlso e.Passages.Count > 0 Then _readingArchive(e.Id) = e
            Next
        End Sub

        Private Function MeditationFilePath() As String
            Return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MeditationPoints.txt")
        End Function

        Private Sub LoadMeditationPoints()
            _meditationPoints.Clear()
            Dim path As String = MeditationFilePath()
            If Not File.Exists(path) Then Return
            For Each raw As String In File.ReadAllLines(path)
                Dim p() As String = raw.Split("|"c)
                If p.Length < 7 Then Continue For
                Dim r As New MeditationPointRecord()
                r.Id = p(0)
                r.Name = p(1)
                Integer.TryParse(p(2), r.CommunityReflection)
                Long.TryParse(p(3), r.TotalStillnessSeconds)
                Integer.TryParse(p(4), r.Vitality)
                r.Caretaker = p(5)
                DateTime.TryParse(p(6), r.LastMeditatedUtc)
                If r.Id <> "" Then _meditationPoints(r.Id) = r
            Next
        End Sub

        Private Sub SaveMeditationPoints()
            Try
                Dim rows As New List(Of String)()
                For Each r As MeditationPointRecord In _meditationPoints.Values
                    rows.Add(SafeField(r.Id) & "|" & SafeField(r.Name) & "|" &
                             r.CommunityReflection.ToString() & "|" &
                             r.TotalStillnessSeconds.ToString() & "|" &
                             r.Vitality.ToString() & "|" &
                             SafeField(r.Caretaker) & "|" & r.LastMeditatedUtc.ToString("o"))
                Next
                File.WriteAllLines(MeditationFilePath(), rows.ToArray())
            Catch ex As Exception
                _log("MEDITATION save warning: " & ex.Message)
            End Try
        End Sub

        Private Function SafeField(value As String) As String
            If value Is Nothing Then Return ""
            Return value.Replace("|", "/")
        End Function

        Private Function IsNearStart(session As Integer, sx As Integer, sy As Integer, sz As Integer, tolerance As Integer) As Boolean
            If Not _avatarPositions.ContainsKey(session) Then Return True
            Dim p As AvatarPosition = _avatarPositions(session)
            Return Math.Abs(p.X - sx) <= tolerance AndAlso
                   Math.Abs(p.Y - sy) <= tolerance AndAlso
                   Math.Abs(p.Z - sz) <= tolerance
        End Function

        Private Sub GetCurrentPosition(session As Integer, ByRef x As Integer, ByRef y As Integer, ByRef z As Integer)
            x = 0 : y = 0 : z = 0
            If _avatarPositions.ContainsKey(session) Then
                x = _avatarPositions(session).X
                y = _avatarPositions(session).Y
                z = _avatarPositions(session).Z
            End If
        End Sub

        Private Function FindBookmark(p As PlayerProfile, id As String) As ReadingBookmark
            EnsureContemplationProfile(p)
            For Each b As ReadingBookmark In p.ReadingBookmarks
                If String.Equals(b.BookId, id, StringComparison.OrdinalIgnoreCase) Then Return b
            Next
            Return Nothing
        End Function

        Private Function HasRead(p As PlayerProfile, id As String) As Boolean
            EnsureContemplationProfile(p)
            For Each s As String In p.BooksRead
                If String.Equals(s, id, StringComparison.OrdinalIgnoreCase) Then Return True
            Next
            Return False
        End Function

        Private Function FindReading(search As String) As ReadingEntry
            EnsureContemplationLoaded()
            If String.IsNullOrWhiteSpace(search) Then Return Nothing
            Dim e As ReadingEntry = Nothing
            If _readingArchive.TryGetValue(search.Trim(), e) Then Return e
            For Each candidate As ReadingEntry In _readingArchive.Values
                If candidate.Title.IndexOf(search.Trim(), StringComparison.OrdinalIgnoreCase) >= 0 Then Return candidate
            Next
            Return Nothing
        End Function

        Private Sub StartReading(session As Integer, id As String, Optional shouldResume As Boolean = True, Optional readingPlace As String = "", Optional readAloud As Boolean = False)
            EnsureContemplationLoaded()
            If Not _sessions.ContainsKey(session) Then Return
            If _activeMeditations.ContainsKey(session) Then
                Console(session, 130, 130, 180, "READING | Finish or leave your meditation before opening a text.")
                Return
            End If
            If _activeReadings.ContainsKey(session) Then
                Console(session, 130, 130, 180, "READING | You are already inside another text.")
                Return
            End If

            Dim entry As ReadingEntry = FindReading(id)
            If entry Is Nothing Then
                Console(session, 170, 90, 90, "READING | No archive text matches '" & id & "'.")
                Return
            End If

            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)

            Dim gateReason As String = ""
            If Not CanOpenAdvancedReading(p, entry, gateReason) Then
                Console(session, 190, 100, 130, "SEALED TEXT | " & gateReason)
                Return
            End If

            Dim st As New ActiveReadingSession()
            st.BookId = entry.Id
            st.ReadingPlace = readingPlace
            st.ReadAloud = readAloud
            st.IsReread = HasRead(p, entry.Id)
            st.LastReadIncarnation = LatestReadIncarnation(p, entry.Id)
            GetCurrentPosition(session, st.StartX, st.StartY, st.StartZ)

            If shouldResume Then
                Dim bm As ReadingBookmark = FindBookmark(p, entry.Id)
                If bm IsNot Nothing AndAlso bm.NextPassage > 0 AndAlso bm.NextPassage < entry.Passages.Count Then
                    st.NextPassage = bm.NextPassage
                End If
            End If

            _activeReadings(session) = st
            MarkSharedReading(session, st, entry)
            ReadBookAsync(session, st, entry)
        End Sub

        Private Async Sub ReadBookAsync(session As Integer, st As ActiveReadingSession, entry As ReadingEntry)
            Try
                Dim p As PlayerProfile = _sessions(session)
                Dim returning As Boolean = st.NextPassage > 0

                Console(session, 105, 85, 155, If(returning,
                        "READING RESUMED | " & entry.Title,
                        "READING OPENED | " & ReadingRarityPrefix(entry) & entry.Title &
                        " [" & entry.Category & " / " & entry.Rarity & "]"))
                Console(session, 95, 90, 130,
                        If(returning,
                           "Your bookmark remembers where your attention broke.",
                           "The world recedes slightly as your attention settles onto the page."))

                If st.ReadingPlace <> "" Then
                    Console(session, 105, 125, 165, "READING PLACE | " & st.ReadingPlace)
                End If
                If st.IsReread AndAlso st.LastReadIncarnation > 0 AndAlso st.LastReadIncarnation <> p.Incarnation Then
                    Console(session, 185, 120, 205,
                            "INCARNATION REREAD | You last finished this in Incarnation " &
                            st.LastReadIncarnation.ToString() & ". The words recognize a different face.")
                ElseIf st.IsReread Then
                    Console(session, 120, 135, 170, "REREADING | The book is unchanged. You are not.")
                End If

                Await Task.Delay(2500)

                For i As Integer = st.NextPassage To entry.Passages.Count - 1
                    If Not _activeReadings.ContainsKey(session) OrElse _activeReadings(session).Token <> st.Token OrElse st.Cancelled Then Return
                    If Not IsNearStart(session, st.StartX, st.StartY, st.StartZ, 150) Then
                        InterruptReading(session, "You move far enough that the thread of the text breaks.")
                        Return
                    End If

                    Dim lead As String
                    Select Case i Mod 5
                        Case 0 : lead = "The first lines establish their own quiet."
                        Case 1 : lead = "You turn the page."
                        Case 2 : lead = "A sentence makes you slow down."
                        Case 3 : lead = "The argument changes shape beneath your attention."
                        Case Else : lead = "Only the final passage remains."
                    End Select
                    Console(session, 95, 85, 135, lead)
                    Await Task.Delay(700)
                    Console(session, 80, 75, 125, entry.Passages(i))
                    BroadcastReadAloudPassage(session, st, entry, entry.Passages(i))

                    st.NextPassage = i + 1
                    SaveBookmark(p, entry.Id, st.NextPassage)

                    TryDiscoverMarginalia(session, p, entry, i)

                    If i = 1 Then EmitDynamicReadingInterlude(session, p, entry)
                    If i = 2 Then
                        RunReadingInterpretationCheck(session, p, entry, st)
                        If entry.HasChoice Then
                            Dim choiceCompleted As Boolean = Await AwaitReadingChoice(session, st, entry)
                            If Not choiceCompleted Then Return
                        End If
                    End If

                    Await Task.Delay(5200)
                Next

                If Not _activeReadings.ContainsKey(session) OrElse st.Cancelled Then Return
                p.PendingReadingShared = st.SharedReading
                p.PendingReadingChoice = st.ChoiceResult
                p.PendingReadingPlace = st.ReadingPlace
                p.PendingReadingIncarnationShift = (st.IsReread AndAlso st.LastReadIncarnation > 0 AndAlso st.LastReadIncarnation <> p.Incarnation)
                _activeReadings.Remove(session)
                RemoveBookmark(p, entry.Id)
                CompleteReading(session, p, entry)
            Catch ex As Exception
                _activeReadings.Remove(session)
                Console(session, 170, 90, 90, "READING | The reading was interrupted.")
                _log("READING exception: " & ex.ToString())
            End Try
        End Sub

        Private Sub SaveBookmark(p As PlayerProfile, id As String, nextPassage As Integer)
            EnsureContemplationProfile(p)
            Dim bm As ReadingBookmark = FindBookmark(p, id)
            If bm Is Nothing Then
                bm = New ReadingBookmark With {.BookId = id}
                p.ReadingBookmarks.Add(bm)
            End If
            bm.NextPassage = nextPassage
            bm.UpdatedUtc = DateTime.UtcNow
            SaveProfiles()
        End Sub

        Private Sub RemoveBookmark(p As PlayerProfile, id As String)
            EnsureContemplationProfile(p)
            For i As Integer = p.ReadingBookmarks.Count - 1 To 0 Step -1
                If String.Equals(p.ReadingBookmarks(i).BookId, id, StringComparison.OrdinalIgnoreCase) Then
                    p.ReadingBookmarks.RemoveAt(i)
                End If
            Next
        End Sub

        Private Sub InterruptReading(session As Integer, reason As String)
            If Not _activeReadings.ContainsKey(session) Then Return
            Dim st As ActiveReadingSession = _activeReadings(session)
            st.Cancelled = True
            _activeReadings.Remove(session)
            Console(session, 150, 90, 110, "READING PAUSED | " & reason)
            Console(session, 100, 120, 150, "Your place has been bookmarked. Say 'continue reading' when you are ready.")
        End Sub

        Private Sub CompleteReading(session As Integer, p As PlayerProfile, entry As ReadingEntry)
            EnsureContemplationProfile(p)
            Dim firstRead As Boolean = Not HasRead(p, entry.Id)
            Dim reward As Integer = If(firstRead, entry.Reward, Math.Max(1, entry.Reward \ 4))
            Dim placeBonus As Integer = ReadingPlaceBonus(entry, p.PendingReadingPlace)
            If placeBonus > 0 Then reward += placeBonus
            If p.PendingReadingShared Then reward += 4
            If p.PendingReadingIncarnationShift Then reward += 3
            If IsQuietReadingEventActive() Then reward *= _quietReadingMultiplier

            Dim completedChoice As String = p.PendingReadingChoice
            Dim completedPlace As String = p.PendingReadingPlace

            p.PendingReadingShared = False
            p.PendingReadingChoice = ""
            p.PendingReadingPlace = ""
            p.PendingReadingIncarnationShift = False

            p.ReflectionPoints += reward
            p.ReadingSkill = Math.Min(100.0, p.ReadingSkill + If(firstRead, 0.35, 0.05))
            p.BooksCompleted += 1

            If firstRead Then
                p.BooksRead.Add(entry.Id)
                MarkOwned(p, entry)
                GrantReadingKnowledge(session, p, entry)
                If entry.Category = "Doctor Who" OrElse entry.Category = "TARDIS" OrElse entry.Category = "Gallifrey" Then
                    p.AcademyCredits += 1
                End If
            End If

            p.ReadingJournal.Insert(0, New ReadingJournalEntry With {
                .BookId = entry.Id,
                .Title = entry.Title,
                .Category = entry.Category,
                .Reflection = reward,
                .Incarnation = p.Incarnation,
                .Choice = completedChoice,
                .ReadingPlace = completedPlace,
                .CompletedUtc = DateTime.UtcNow
            })
            While p.ReadingJournal.Count > 30
                p.ReadingJournal.RemoveAt(p.ReadingJournal.Count - 1)
            End While

            Dim check As SkillCheckResult = PerformSkillCheck(p, entry.Skill, Math.Max(15, Math.Min(75, entry.Reward + 20)))
            ReportSkillGain(session, entry.Skill, check)

            Console(session, 100, 190, 150, "READING COMPLETE | " & entry.Title)
            Console(session, 100, 170, 190,
                    "Reflection +" & reward.ToString() &
                    " | Reading " & p.ReadingSkill.ToString("0.00") &
                    " | " & entry.Skill & " exercised" &
                    If(firstRead AndAlso (entry.Category = "Doctor Who" OrElse entry.Category = "TARDIS" OrElse entry.Category = "Gallifrey"), " | Academy +1", ""))
            If placeBonus > 0 Then
                Console(session, 130, 165, 190, "PLACE RESONANCE | +" & placeBonus.ToString() & " reflections from reading this text where it belongs.")
            End If
            If Not firstRead Then Console(session, 120, 140, 170, "A rereading gives fewer reflections, but the text is not the same text when the reader has changed.")

            CheckReadingContradiction(session, p, entry)
            ApplyReadingConsequences(session, p, entry)
            CheckSeriesCompletion(session, p, entry.Series)
            RefreshReaderArchetype(session, p)
            ReadingMilestones(session, p)
            SaveProfiles()
        End Sub

        Private Sub ShowLibrary(session As Integer, filter As String)
            EnsureContemplationLoaded()
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            Dim items As New List(Of String)()
            For Each e As ReadingEntry In _readingArchive.Values
                If filter <> "" AndAlso e.Category.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0 AndAlso e.Tags.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0 Then Continue For
                Dim gateReason As String = ""
                Dim unlocked As Boolean = CanOpenAdvancedReading(p, e, gateReason)
                items.Add(ReadingRarityPrefix(e) & e.Id & "=" & e.Title &
                          " [" & e.Rarity & "]" &
                          If(HasRead(p, e.Id), " ✓", If(unlocked, "", " 🔒")))
            Next
            items.Sort()
            If items.Count = 0 Then
                Console(session, 140, 130, 170, "LIBRARY | No texts match '" & filter & "'.")
                Return
            End If
            Console(session, 90, 150, 190, "LIBRARY" & If(filter = "", "", " [" & filter & "]") & " | " & String.Join(" | ", items.ToArray()))
        End Sub

        Private Sub RecommendReading(session As Integer)
            EnsureContemplationLoaded()
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            Dim unread As New List(Of ReadingEntry)()
            For Each entry As ReadingEntry In _readingArchive.Values
                If Not HasRead(p, entry.Id) Then unread.Add(entry)
            Next
            Dim pool As List(Of ReadingEntry) = If(unread.Count > 0, unread, New List(Of ReadingEntry)(_readingArchive.Values))
            If pool.Count = 0 Then Return
            Dim recommendation As ReadingEntry = pool(_rng.Next(0, pool.Count))
            Console(session, 100, 170, 210,
                    "LIBRARIAN'S CHOICE | " & recommendation.Id & " — " &
                    recommendation.Title & " [" & recommendation.Category &
                    "] | say: read " & recommendation.Id)
        End Sub

        Private Sub ContinueReading(session As Integer)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            If p.ReadingBookmarks.Count = 0 Then
                Console(session, 130, 130, 170, "READING | You have no unfinished text waiting.")
                Return
            End If
            Dim newest As ReadingBookmark = p.ReadingBookmarks(0)
            For Each b As ReadingBookmark In p.ReadingBookmarks
                If b.UpdatedUtc > newest.UpdatedUtc Then newest = b
            Next
            StartReading(session, newest.BookId, True)
        End Sub

        Private Sub ShowReadingStatus(session As Integer)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            Console(session, 100, 165, 195,
                    "READING STATUS | Skill " & p.ReadingSkill.ToString("0.00") &
                    " | Unique texts " & p.BooksRead.Count.ToString() & "/" & _readingArchive.Count.ToString() &
                    " | Completions " & p.BooksCompleted.ToString() &
                    " | Reflections " & p.ReflectionPoints.ToString() &
                    " | Bookmarks " & p.ReadingBookmarks.Count.ToString())
        End Sub

        Private Sub ShowReadingJournal(session As Integer)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            If p.ReadingJournal.Count = 0 Then
                Console(session, 130, 130, 170, "READING JOURNAL | No completed readings yet.")
                Return
            End If
            Dim parts As New List(Of String)()
            For i As Integer = 0 To Math.Min(5, p.ReadingJournal.Count) - 1
                Dim j As ReadingJournalEntry = p.ReadingJournal(i)
                parts.Add(j.Title & " +" & j.Reflection.ToString())
            Next
            Console(session, 105, 160, 195, "READING JOURNAL | " & String.Join(" | ", parts.ToArray()))
        End Sub

        Private Sub SelectMeditationPoint(session As Integer, sender As AW.Instance, action As String)
            EnsureContemplationLoaded()
            Dim id As String = GetParam(action, "id")
            Dim name As String = GetParam(action, "name")
            If id = "" Then id = "point-" & sender.GetInt(Attributes.ObjectNumber).ToString()
            If name = "" Then name = sender.GetString(Attributes.ObjectDescription)
            If name = "" Then name = "Meditation Point"

            Dim r As MeditationPointRecord = Nothing
            If Not _meditationPoints.TryGetValue(id, r) Then
                r = New MeditationPointRecord With {.Id = id, .Name = name}
                _meditationPoints(id) = r
                SaveMeditationPoints()
            ElseIf name <> "" Then
                r.Name = name
            End If
            _selectedMeditationPoint(session) = id
            Console(session, 95, 165, 180,
                    "MEDITATION POINT | " & r.Name &
                    " | Vitality " & r.Vitality.ToString() &
                    " | Community reflections " & r.CommunityReflection.ToString() &
                    " | Stillness " & FormatStillness(r.TotalStillnessSeconds))
            Console(session, 115, 135, 170, "Say: meditate 30 | meditate 60 | meditate 300")
        End Sub

        Private Function FormatStillness(total As Long) As String
            If total < 60 Then Return total.ToString() & "s"
            If total < 3600 Then Return (total \ 60).ToString() & "m " & (total Mod 60).ToString() & "s"
            Return (total \ 3600).ToString() & "h " & ((total Mod 3600) \ 60).ToString() & "m"
        End Function


        Private ReadOnly _meditationAtmosphere As String() = {
            "The room continues without asking anything of you.",
            "Your first heart slows. A moment later, the second decides to follow.",
            "A thought arrives urgently, notices that you are unavailable, and leaves.",
            "Somewhere beyond ordinary perception, the Vortex seems less like a storm and more like a breath.",
            "For a few seconds, your memories stop arranging themselves into a story.",
            "The silence develops texture.",
            "You notice the exact instant between wanting to move and actually moving.",
            "Nothing dramatic happens. The absence of drama becomes strangely beautiful.",
            "Your attention widens until the room no longer feels divided into important and unimportant things.",
            "A distant sound reaches you without becoming a demand.",
            "The floor feels very certain about being beneath you.",
            "For one impossible heartbeat, you remember this stillness from an incarnation you have not had yet.",
            "Your regeneration energy is quiet, but not absent.",
            "Somewhere in the TARDIS, a corridor chooses not to rearrange itself.",
            "The Cloister Bell does not ring. Somehow, that feels significant.",
            "The universe continues expanding without consulting you.",
            "Your breathing stops feeling like something you are doing and becomes something that is happening.",
            "A tiny discomfort asks to become a crisis. You decline the invitation.",
            "The future remains where it is. You do not have to go there yet.",
            "The past fails to require revision for several consecutive seconds.",
            "Your two hearts briefly find the same rhythm.",
            "For a moment, the TARDIS hum and your pulse seem to occupy the same note.",
            "The world contains problems. None of them are standing inside this second.",
            "A memory surfaces, sees the quiet, and sinks again without explanation.",
            "Time passes. Remarkably, you survive allowing it to do so.",
            "The air seems larger when you stop trying to fill it.",
            "You become aware of how many muscles were waiting for instructions that never came.",
            "The next moment arrives perfectly capable of carrying itself.",
            "Somewhere, a Dalek is probably furious. It can wait.",
            "No prophecy is issued. No alarm sounds. No ancient evil awakens. Excellent.",
            "The universe offers no quest marker.",
            "A sensation passes through you without becoming an identity.",
            "The space behind your eyes feels less crowded.",
            "Your name becomes temporarily unnecessary.",
            "For several seconds, being a Time Lord is merely one fact among many.",
            "You notice that stillness is not empty. It is simply not shouting.",
            "The present moment refuses to explain itself.",
            "A future decision remains safely in the future.",
            "The room has not changed. Your relationship to it has.",
            "Nothing requires you. The sentence lands differently this time."
        }

        Private ReadOnly _meditationRareAtmosphere As String() = {
            "For a single impossible moment, every clock you can imagine seems to agree.",
            "The Vortex opens in your mind like an eye, then politely closes again.",
            "You hear the ghost of a dematerialisation sound from somewhere that has not happened yet.",
            "Every possible version of this moment appears to become still at once.",
            "Your biodata feels briefly weightless, as though history has loosened its grip.",
            "A memory that does not belong to this incarnation brushes past and is gone.",
            "For one heartbeat, you can almost feel Gallifrey turning beneath an orange sky.",
            "The TARDIS seems to notice that you have stopped trying to steer anything.",
            "Something in the universe becomes quieter because you did.",
            "For several seconds, causality feels less like a law and more like a courtesy."
        }

        Private Sub EmitMeditationAtmosphere(session As Integer, st As ActiveMeditationSession)
            If session <= 0 OrElse Not _sessions.ContainsKey(session) Then Return

            st.AtmosphereCount += 1

            ' Roughly one pulse in sixteen becomes a rarer, more mythic moment.
            Dim text As String = ""
            If _rng.Next(0, 16) = 0 Then
                text = _meditationRareAtmosphere(_rng.Next(0, _meditationRareAtmosphere.Length))
                Console(session, 165, 125, 220, text)
                Return
            End If

            Dim index As Integer = _rng.Next(0, _meditationAtmosphere.Length)
            If _meditationAtmosphere.Length > 1 AndAlso index = st.LastAtmosphereIndex Then
                index = (index + 1) Mod _meditationAtmosphere.Length
            End If
            st.LastAtmosphereIndex = index

            ' Alternate the tint a little so the stream feels alive without becoming noisy.
            Select Case st.AtmosphereCount Mod 4
                Case 0
                    Console(session, 95, 150, 175, _meditationAtmosphere(index))
                Case 1
                    Console(session, 115, 95, 160, _meditationAtmosphere(index))
                Case 2
                    Console(session, 80, 135, 155, _meditationAtmosphere(index))
                Case Else
                    Console(session, 125, 115, 175, _meditationAtmosphere(index))
            End Select
        End Sub

        Private Sub StartMeditation(session As Integer, seconds As Integer)
            If Not _sessions.ContainsKey(session) Then Return
            If _activeReadings.ContainsKey(session) Then
                Console(session, 130, 130, 180, "MEDITATION | Finish or pause your reading first.")
                Return
            End If
            If _activeMeditations.ContainsKey(session) Then
                Console(session, 130, 130, 180, "MEDITATION | You are already meditating.")
                Return
            End If
            If seconds <> 30 AndAlso seconds <> 60 AndAlso seconds <> 300 Then seconds = 60

            Dim st As New ActiveMeditationSession()
            st.DurationSeconds = seconds
            st.Reward = If(seconds = 30, 15, If(seconds = 60, 30, 150))
            st.SkillGain = If(seconds = 30, 0.01, If(seconds = 60, 0.02, 0.05))
            st.StartUtc = DateTime.UtcNow
            st.EndUtc = st.StartUtc.AddSeconds(seconds)
            st.NextAtmosphereUtc = st.StartUtc.AddSeconds(5)
            GetCurrentPosition(session, st.StartX, st.StartY, st.StartZ)
            If _selectedMeditationPoint.ContainsKey(session) Then st.PointId = _selectedMeditationPoint(session)
            _activeMeditations(session) = st

            Dim placeName As String = ""
            If st.PointId <> "" AndAlso _meditationPoints.ContainsKey(st.PointId) Then
                placeName = _meditationPoints(st.PointId).Name
            End If

            Console(session, 120, 90, 160,
                    "MEDITATION BEGINS" & If(placeName = "", ".", " at " & placeName & "."))
            Console(session, 100, 85, 125,
                    "Remain here without acting for " & seconds.ToString() &
                    " seconds. The world will keep happening without your assistance.")
            Console(session, 115, 105, 155,
                    "You allow your attention to stop reaching outward.")
        End Sub

        Private Sub CancelMeditation(session As Integer, reason As String)
            If Not _activeMeditations.ContainsKey(session) Then Return
            _activeMeditations.Remove(session)
            Console(session, 150, 90, 110, "The meditation breaks.")
            Console(session, 135, 105, 145, reason)
        End Sub

        Private Sub TickContemplation(now As DateTime)
            EnsureContemplationLoaded()
            If _activeMeditations.Count = 0 Then Return
            Dim sessions() As Integer = New List(Of Integer)(_activeMeditations.Keys).ToArray()
            For Each session As Integer In sessions
                If Not _activeMeditations.ContainsKey(session) Then Continue For
                Dim st As ActiveMeditationSession = _activeMeditations(session)
                If Not IsNearStart(session, st.StartX, st.StartY, st.StartZ, 150) Then
                    CancelMeditation(session, "Movement disturbed the stillness.")
                    Continue For
                End If
                If now >= st.EndUtc Then
                    CompleteMeditation(session, st)
                    Continue For
                End If

                If now >= st.NextAtmosphereUtc Then
                    EmitMeditationAtmosphere(session, st)

                    Dim remaining As Double = (st.EndUtc - now).TotalSeconds
                    Dim spacing As Integer
                    If st.DurationSeconds <= 30 Then
                        spacing = 8
                    ElseIf st.DurationSeconds <= 60 Then
                        spacing = 9
                    Else
                        spacing = 12 + _rng.Next(0, 7)
                    End If

                    If remaining < spacing + 2 Then spacing = Math.Max(3, CInt(remaining) - 2)
                    st.NextAtmosphereUtc = now.AddSeconds(Math.Max(3, spacing))
                End If
            Next
        End Sub

        Private Sub CompleteMeditation(session As Integer, st As ActiveMeditationSession)
            _activeMeditations.Remove(session)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            p.ReflectionPoints += st.Reward
            p.MeditationSkill = Math.Min(100.0, p.MeditationSkill + st.SkillGain)
            p.TotalStillnessSeconds += st.DurationSeconds

            Dim locationText As String = ""
            If st.PointId <> "" AndAlso _meditationPoints.ContainsKey(st.PointId) Then
                Dim r As MeditationPointRecord = _meditationPoints(st.PointId)
                r.CommunityReflection += st.Reward
                r.TotalStillnessSeconds += st.DurationSeconds
                r.Vitality = Math.Min(100, r.Vitality + Math.Max(1, st.DurationSeconds \ 30))
                r.LastMeditatedUtc = DateTime.UtcNow
                If r.Caretaker = "" Then r.Caretaker = p.Name
                locationText = " | " & r.Name & " vitality " & r.Vitality.ToString()
                SaveMeditationPoints()
            End If

            Console(session, 80, 120, 100, "The meditation concludes.")
            Console(session, 125, 100, 165,
                    "For " & FormatStillness(st.DurationSeconds) & ", nothing required you.")
            Console(session, 90, 185, 155,
                    "MEDITATION COMPLETE | Reflections +" & st.Reward.ToString() &
                    " | Meditation " & p.MeditationSkill.ToString("0.00") &
                    " | Total stillness " & FormatStillness(p.TotalStillnessSeconds) & locationText)
            SaveProfiles()
        End Sub

        Private Sub ShowMeditationStatus(session As Integer)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            EnsureContemplationProfile(p)
            Dim point As String = "none selected"
            If _selectedMeditationPoint.ContainsKey(session) AndAlso _meditationPoints.ContainsKey(_selectedMeditationPoint(session)) Then
                point = _meditationPoints(_selectedMeditationPoint(session)).Name
            End If
            Console(session, 95, 165, 185,
                    "MEDITATION STATUS | Skill " & p.MeditationSkill.ToString("0.00") &
                    " | Stillness " & FormatStillness(p.TotalStillnessSeconds) &
                    " | Reflections " & p.ReflectionPoints.ToString() &
                    " | Tokens " & p.MeditationTokens.ToString() &
                    " | Point " & point)
        End Sub

        Private Sub RedeemReflectionToken(session As Integer)
            If Not _sessions.ContainsKey(session) Then Return
            Dim p As PlayerProfile = _sessions(session)
            If p.ReflectionPoints < 25 Then
                Console(session, 140, 120, 160, "REFLECTION | 25 Reflection Points are needed to form one Meditation Token.")
                Return
            End If
            p.ReflectionPoints -= 25
            p.MeditationTokens += 1
            SaveProfiles()
            Console(session, 100, 180, 160, "REFLECTION | 25 reflections coalesce into a Meditation Token. Tokens: " & p.MeditationTokens.ToString())
        End Sub

        Private Function IsContemplationCommand(raw As String) As Boolean
            Dim s As String = raw.Trim().ToLowerInvariant()
            Return s.StartsWith("/read") OrElse s.StartsWith("/library") OrElse
                   s.StartsWith("/reading") OrElse s.StartsWith("/meditat") OrElse
                   s.StartsWith("/reflect") OrElse s.StartsWith("/choose") OrElse
                   s.StartsWith("/favorite") OrElse s.StartsWith("/annotate") OrElse
                   s.StartsWith("/collection") OrElse s.StartsWith("/knowledge") OrElse
                   s.StartsWith("/marginalia") OrElse s.StartsWith("/readaloud") OrElse
                   s = "continue reading" OrElse s.StartsWith("choose ") OrElse
                   s.StartsWith("read ") OrElse s.StartsWith("meditate ")
        End Function

        Private Function HandleContemplationChat(session As Integer, sender As AW.Instance, raw As String) As Boolean
            EnsureContemplationLoaded()
            Dim s As String = raw.Trim()
            Dim lower As String = s.ToLowerInvariant()

            If _activeMeditations.ContainsKey(session) AndAlso Not IsContemplationCommand(raw) Then
                CancelMeditation(session, "Words interrupted the stillness.")
                Return False
            End If
            If _activeReadings.ContainsKey(session) AndAlso Not IsContemplationCommand(raw) Then
                InterruptReading(session, "Conversation pulled your attention away from the page.")
                Return False
            End If

            If lower = "/library" OrElse lower = "library" Then
                ShowLibrary(session, "")
                Return True
            ElseIf lower.StartsWith("/library ") Then
                ShowLibrary(session, s.Substring(9).Trim())
                Return True
            ElseIf lower = "/reading status" OrElse lower = "reading status" Then
                ShowReadingStatus(session)
                Return True
            ElseIf lower = "/reading journal" OrElse lower = "reading journal" Then
                ShowReadingJournal(session)
                Return True
            ElseIf lower = "/reading recommend" OrElse lower = "recommend a reading" Then
                RecommendReading(session)
                Return True
            ElseIf lower = "/reading continue" OrElse lower = "continue reading" Then
                ContinueReading(session)
                Return True
            ElseIf lower.StartsWith("/choose ") OrElse lower.StartsWith("choose ") Then
                Dim choiceText As String = If(lower.StartsWith("/choose "), s.Substring(8).Trim(), s.Substring(7).Trim())
                SetReadingChoice(session, choiceText)
                Return True
            ElseIf lower = "/collection" OrElse lower = "reading collection" OrElse lower = "reader profile" Then
                ShowReadingCollection(session)
                Return True
            ElseIf lower = "/knowledge" OrElse lower = "reading knowledge" Then
                ShowReadingKnowledge(session)
                Return True
            ElseIf lower = "/marginalia" OrElse lower = "reading marginalia" Then
                ShowMarginalia(session)
                Return True
            ElseIf lower.StartsWith("/favorite ") Then
                ToggleFavoriteReading(session, s.Substring(10).Trim())
                Return True
            ElseIf lower.StartsWith("/annotate ") Then
                Dim rest As String = s.Substring(10).Trim()
                Dim spaceAt As Integer = rest.IndexOf(" "c)
                If spaceAt <= 0 Then
                    Console(session, 150, 120, 160, "ANNOTATION | Use: /annotate <book id> <note>")
                Else
                    SaveReadingAnnotation(session, rest.Substring(0, spaceAt), rest.Substring(spaceAt + 1).Trim())
                End If
                Return True
            ElseIf lower.StartsWith("/readaloud ") Then
                StartReading(session, s.Substring(11).Trim(), True, "", True)
                Return True
            ElseIf lower.StartsWith("/read ") Then
                StartReading(session, s.Substring(6).Trim(), True)
                Return True
            ElseIf lower.StartsWith("read ") Then
                StartReading(session, s.Substring(5).Trim(), True)
                Return True
            ElseIf lower = "/meditation" OrElse lower = "/meditation status" OrElse lower = "meditation status" Then
                ShowMeditationStatus(session)
                Return True
            ElseIf lower.StartsWith("/meditate ") Then
                StartMeditation(session, ParseInt(s.Substring(10).Trim(), 60))
                Return True
            ElseIf lower.StartsWith("meditate ") Then
                StartMeditation(session, ParseInt(s.Substring(9).Trim(), 60))
                Return True
            ElseIf lower = "/reflect" OrElse lower = "reflection status" Then
                ShowReadingStatus(session)
                ShowMeditationStatus(session)
                Return True
            ElseIf lower = "/reflect token" OrElse lower = "redeem reflection token" Then
                RedeemReflectionToken(session)
                Return True
            End If

            Return False
        End Function

        Private Function HandleContemplationAction(session As Integer, sender As AW.Instance, action As String) As Boolean
            EnsureContemplationLoaded()
            If action.IndexOf("~readingevent", StringComparison.OrdinalIgnoreCase) >= 0 Then
                StartQuietReadingEvent(session, ParseInt(GetParam(action, "seconds"), 600))
                Return True
            End If

            If action.IndexOf("~reading", StringComparison.OrdinalIgnoreCase) >= 0 Then
                Dim id As String = GetParam(action, "id")
                If id = "" Then
                    Console(session, 160, 90, 90, "READING OBJECT | Add id:<book id> to this object's action.")
                Else
                    Dim place As String = GetParam(action, "place")
                    Dim aloud As Boolean = String.Equals(GetParam(action, "aloud"), "true", StringComparison.OrdinalIgnoreCase)
                    StartReading(session, id, True, place, aloud)
                End If
                Return True
            End If

            If action.IndexOf("~meditation", StringComparison.OrdinalIgnoreCase) >= 0 Then
                SelectMeditationPoint(session, sender, action)
                Return True
            End If

            If _activeMeditations.ContainsKey(session) Then
                CancelMeditation(session, "Your attention moved toward another object.")
                Return True
            End If
            If _activeReadings.ContainsKey(session) Then
                InterruptReading(session, "Your hand left the page for another object.")
                Return True
            End If
            Return False
        End Function

        Private Function HandleContemplationAvatarClick(session As Integer) As Boolean
            If _activeMeditations.ContainsKey(session) Then
                CancelMeditation(session, "Your attention moved toward another person.")
                Return True
            End If
            If _activeReadings.ContainsKey(session) Then
                InterruptReading(session, "Someone else drew your attention away from the page.")
                Return True
            End If
            Return False
        End Function

    End Class
End Namespace
